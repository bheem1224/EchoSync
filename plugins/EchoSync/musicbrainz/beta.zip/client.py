import asyncio
import hashlib
import re
from typing import Any

from rapidfuzz import fuzz

from core.caching.plugin_cache import plugin_cache
from core.db.echo_sync_track import EchosyncTrack
from core.matching_engine.text_utils import normalize_artist, normalize_title
from core.matching_engine.track_parser import TrackParser
from core.nexus_framework.plugin_SDK import (
    MetadataRichness,
    PlaylistSupport,
    PluginBase,
    ProviderCapabilities,
    SearchCapabilities,
)
from core.request_manager import HttpError, RateLimitConfig, RetryConfig
from core.tiered_logger import get_logger

from .models import PluginMusicbrainzCache


def _safe_getattr(obj: Any, attr: str, default: Any = None) -> Any:
    """AST-compliant alternative to getattr()."""
    if hasattr(obj, attr):
        try:
            return obj.__getattribute__(attr)
        except AttributeError:
            return default
    return default


logger = get_logger("provider.musicbrainz")


class MusicBrainzClient(PluginBase):
    """Dedicated metadata provider used by discovery and enrichment flows."""

    name = "EchoSync.musicbrainz"
    supports_isrc_lookup = True
    metadata_quality_score = 95
    service_type = "metadata"

    capabilities = ProviderCapabilities(
        name="EchoSync.musicbrainz",
        supports_playlists=PlaylistSupport.NONE,
        search=SearchCapabilities(
            tracks=True, artists=True, albums=True, playlists=False
        ),
        metadata=MetadataRichness.HIGH,
        supports_cover_art=True,
        supports_lyrics=False,
        supports_user_auth=True,
        supports_library_scan=False,
        supports_streaming=False,
        supports_downloads=False,
        supports_metadata_fetch=True,
        supports_isrc_lookup=True,
        supports_batching=True,
    )

    def __init__(self):
        super().__init__()
        self.http.rate = RateLimitConfig(requests_per_second=1.0)
        self.http.retry = RetryConfig(
            max_retries=4,
            base_backoff=1.5,
            max_backoff=15.0,
            jitter=0.2,
        )
        self.http._session.headers.update(
            {
                "User-Agent": "Echosync/0.1.0 ( https://github.com/echosync/echosync )",
                "Accept": "application/json",
            }
        )
        self.api_base = (
            self.config.get("api_base_url") or "https://musicbrainz.org/ws/2"
        )
        self._search_queue = []
        self._batch_task = None
        self._lock = asyncio.Lock()

    @plugin_cache(ttl_seconds=2592000)
    def _fetch_artist_track_dicts(self, artist_name: str) -> list[dict[str, Any]]:
        """Cached paginated recording fetch returning JSON-serialisable dicts.

        Separating the API calls from EchosyncTrack construction keeps the
        plugin_cache round-trip (JSON → SQLite → JSON) lossless.  Called
        exclusively by get_artist_tracks.
        """
        artist_name = str(artist_name or "").strip()
        if not artist_name:
            return []

        raw: list[dict[str, Any]] = []
        offset = 0
        limit = 100
        max_records = 500

        try:
            while len(raw) < max_records:
                if re.fullmatch(r"[0-9a-fA-F-]{36}", artist_name):
                    query = f"arid:{artist_name}"
                else:
                    query = f'artist:"{artist_name}"'
                try:
                    response = self.http.get(
                        f"{self.api_base}/recording",
                        params={
                            "fmt": "json",
                            "query": query,
                            "limit": limit,
                            "offset": offset,
                        },
                    )
                except HttpError as http_err:
                    if http_err.status in (429, 503):
                        logger.warning(
                            "MusicBrainz service unavailable or rate limited (%s) for artist '%s' (offset %d). Returning %d accumulated tracks.",
                            http_err.status,
                            artist_name,
                            offset,
                            len(raw),
                        )
                        break
                    raise

                if response.status_code != 200:
                    logger.warning(
                        "MusicBrainz get_artist_tracks failed for '%s' (status=%s)",
                        artist_name,
                        response.status_code,
                    )
                    break

                payload = response.json() or {}
                recordings = payload.get("recordings", []) or []
                if not recordings:
                    break

                for recording in recordings:
                    title = str(recording.get("title") or "").strip()
                    if not title:
                        continue

                    artist_credit = recording.get("artist-credit") or []
                    provider_artist = ""
                    for entry in artist_credit:
                        if isinstance(entry, dict):
                            provider_artist += str(entry.get("name") or "")
                            provider_artist += str(entry.get("joinphrase") or "")
                    provider_artist = provider_artist.strip() or artist_name

                    releases = recording.get("releases") or []
                    album_title = ""
                    release_year = None
                    if releases:
                        first_release = releases[0] or {}
                        album_title = str(first_release.get("title") or "")
                        date_value = str(first_release.get("date") or "")
                        if len(date_value) >= 4 and date_value[:4].isdigit():
                            release_year = int(date_value[:4])

                    recording_mbid = str(recording.get("id") or "").strip() or None
                    isrc = None
                    isrc_list = recording.get("isrcs") or []
                    if isrc_list:
                        isrc = str(isrc_list[0] or "").strip() or None

                    raw.append(
                        {
                            "title": title,
                            "artist": provider_artist,
                            "album": album_title or "Unknown Album",
                            "mbid": recording_mbid,
                            "isrc": isrc,
                            "year": release_year,
                        }
                    )
                    if len(raw) >= max_records:
                        break

                if len(recordings) < limit:
                    break
                offset += limit

        except HttpError as exc:
            logger.warning(
                "MusicBrainz HTTP error while fetching tracks for '%s': %s",
                artist_name,
                exc,
            )
        except Exception as exc:
            logger.error(
                "Failed to fetch artist tracks for '%s': %s",
                artist_name,
                exc,
                exc_info=True,
            )

        # Deduplicate by artist+title to keep discovery diff deterministic.
        deduped: dict[str, dict[str, Any]] = {}
        for d in raw:
            key = f"{d['artist']}|{d['title']}"
            if key not in deduped:
                deduped[key] = d
        return list(deduped.values())

    @plugin_cache(ttl_seconds=2592000)
    def get_artist_ensemble_relationship(
        self, artist_mbid: str
    ) -> dict[str, str] | None:
        """Look up band/group membership for an artist via MusicBrainz artist-rels."""
        artist_mbid = str(artist_mbid or "").strip()
        if not artist_mbid:
            return None

        try:
            response = self.http.get(
                f"{self.api_base}/artist/{artist_mbid}",
                params={
                    "fmt": "json",
                    "inc": "artist-rels",
                },
            )
            if response.status_code != 200:
                return None

            payload = response.json() or {}
            relations = payload.get("relations", []) or []
            for rel in relations:
                if rel.get("type") == "member of band":
                    target = rel.get("artist") or {}
                    band_name = target.get("name")
                    band_mbid = target.get("id")
                    if band_name and band_mbid:
                        return {
                            "parent_ensemble_name": str(band_name).strip(),
                            "parent_ensemble_mbid": str(band_mbid).strip(),
                        }
        except Exception as exc:
            logger.debug(
                "Failed to resolve artist ensemble relationship for %s: %s",
                artist_mbid,
                exc,
            )

        return None

    def resolve_canonical_studio_release(
        self, releases: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """
        Traverse releases attached to a recording to find the earliest non-compilation
        canonical studio album/EP.
        """
        if not releases:
            return None

        candidates = []
        for r in releases:
            if not isinstance(r, dict):
                continue
            title = (r.get("title") or "").strip()
            if not title:
                continue

            rg = r.get("release-group") or {}
            p_type = (rg.get("primary-type") or "").strip().lower()
            s_types = [
                str(st).strip().lower() for st in (rg.get("secondary-types") or [])
            ]

            is_compilation = (
                "compilation" in s_types
                or "various artists" in str(r.get("artist-credit") or []).lower()
            )
            if is_compilation:
                continue

            date_str = str(r.get("date") or "").strip()
            year_val = None
            if len(date_str) >= 4 and date_str[:4].isdigit():
                try:
                    year_val = int(date_str[:4])
                except ValueError:
                    pass

            is_studio_type = p_type in ("album", "ep") or not p_type
            if is_studio_type:
                candidates.append(
                    {
                        "canonical_studio_album": title,
                        "canonical_studio_release_mbid": r.get("id"),
                        "canonical_studio_release_group_mbid": rg.get("id"),
                        "canonical_year": year_val,
                        "date": date_str,
                    }
                )

        if not candidates:
            return None

        candidates.sort(key=lambda c: c.get("date") or "9999")
        return candidates[0]

    def get_artist_tracks(self, artist_name: str) -> list[EchosyncTrack]:
        """Fetch a full-ish artist tracklist from MusicBrainz recordings search.

        The discovery engine uses EchosyncTrack.sync_id to diff these results
        against local libraries, so tracks must be created through the standard
        factory path to ensure deterministic IDs.
        """
        tracks: list[EchosyncTrack] = []
        for d in self._fetch_artist_track_dicts(artist_name):
            track_obj = self.create_echo_sync_track(
                title=d["title"],
                artist=d["artist"],
                album=d["album"],
                musicbrainz_id=d["mbid"],
                isrc=d["isrc"],
                year=d["year"],
                provider_id=d["mbid"],
                source=self.name,
            )
            if track_obj:
                tracks.append(track_obj)
        return tracks

    @plugin_cache(ttl_seconds=604800)
    def _search_metadata_query(
        self, query: str, limit: int = 5
    ) -> list[dict[str, Any]]:
        """Cached helper for string queries to maintain legacy query caching."""
        query = str(query or "").strip()
        if not query:
            return []

        safe_limit = max(1, min(int(limit or 5), 100))
        try:
            logger.debug(
                f"[MusicBrainz Client] Sending search query to MusicBrainz: query='{query}', limit={safe_limit}"
            )
            response = self.http.get(
                f"{self.api_base}/recording",
                params={
                    "fmt": "json",
                    "query": query,
                    "limit": safe_limit,
                },
            )
            logger.debug(
                f"[MusicBrainz Client] Received response: status={response.status_code}"
            )
            if response.status_code != 200:
                logger.warning(
                    "MusicBrainz search_metadata failed (status=%s, query=%s)",
                    response.status_code,
                    query,
                )
                return []

            payload = response.json() or {}
            recordings = payload.get("recordings", []) or []
            logger.debug(
                f"[MusicBrainz Client] Found {len(recordings)} recordings in response payload"
            )
            results: list[dict[str, Any]] = []

            for recording in recordings:
                mbid = str(recording.get("id") or "").strip()
                if not mbid:
                    continue

                artist_credit = recording.get("artist-credit") or []
                artist_parts: list[str] = []
                for entry in artist_credit:
                    if isinstance(entry, dict):
                        artist_parts.append(str(entry.get("name") or ""))
                        artist_parts.append(str(entry.get("joinphrase") or ""))
                artist_name = "".join(artist_parts).strip()

                releases = recording.get("releases") or []
                album_title = ""
                if releases:
                    album_title = str((releases[0] or {}).get("title") or "").strip()

                isrc_values = recording.get("isrcs") or []
                duration_ms = recording.get("length")
                try:
                    duration_ms = int(duration_ms) if duration_ms is not None else None
                except Exception:
                    duration_ms = None

                results.append(
                    {
                        "title": str(recording.get("title") or "").strip(),
                        "artist": artist_name,
                        "album": album_title,
                        "duration": duration_ms,
                        "isrc": str(isrc_values[0]).strip() if isrc_values else None,
                        "mbid": mbid,
                    }
                )

            return results
        except Exception as exc:
            logger.warning(
                f"MusicBrainz search_metadata exception for '{query}': {exc}"
            )
            return []

    def search_metadata(self, track: Any, limit: int = 10) -> Any:
        """Centralized metadata search. Supports both new EchosyncTrack contract and legacy string queries."""
        logger.debug(f"[MusicBrainz Client] search_metadata called with track={track}")
        if isinstance(track, str):
            logger.debug(
                f"[MusicBrainz Client] track is a string, calling _search_metadata_query('{track}')"
            )
            return self._search_metadata_query(track, limit=limit)

        if isinstance(track, dict) or hasattr(track, "get"):
            artist = track.get("artist_name") or track.get("artist") or ""
            title = track.get("title") or track.get("raw_title") or ""
            album = track.get("album_title") or track.get("album") or ""
            duration = track.get("duration_ms") or track.get("duration")
        else:
            artist = (
                track.artist_name
                if hasattr(track, "artist_name")
                else (track.artist if hasattr(track, "artist") else "")
            )
            title = (
                track.title
                if hasattr(track, "title")
                else (track.raw_title if hasattr(track, "raw_title") else "")
            )
            album = (
                track.album_title
                if hasattr(track, "album_title")
                else (track.album if hasattr(track, "album") else "")
            )
            duration = (
                track.duration_ms
                if hasattr(track, "duration_ms")
                else (track.duration if hasattr(track, "duration") else None)
            )

        duration_ms = None
        try:
            if duration is not None:
                parsed_dur = int(duration)
                if parsed_dur > 0 and parsed_dur < 10000:
                    duration_ms = parsed_dur * 1000
                elif parsed_dur > 0:
                    duration_ms = parsed_dur
        except ValueError:
            pass

        # 1. Sanitize track number prefixes from title
        import re

        track_num_match = re.match(
            r"^(?:(?P<disc>\d+)[.-])?(?P<track>\d{1,2})[\s.-]+", title
        )
        if track_num_match:
            title = title[track_num_match.end() :].strip()

        # 2. Check if title contains filename-like structures, parse it structurally if so
        if " - " in title or re.search(
            r"\.(mp3|flac|m4a|aac|ogg|wav|wma)$", title, re.IGNORECASE
        ):
            parser = TrackParser()
            parsed = parser.parse_filename(title)
            if parsed:
                title = parsed.title or title
                if (
                    parsed.artist_name
                    and not parsed.artist_name.isdigit()
                    and parsed.artist_name != "Unknown Artist"
                ):
                    artist = parsed.artist_name

        # 3. Clean and sanitize strings through core text normalizers
        cleaned_artist_str = self._clean_query_artist(artist)
        clean_title = normalize_title(title)
        clean_artist = normalize_artist(cleaned_artist_str or artist)

        # 3b. Check if track has an AcoustID ID to query MusicBrainz directly
        acoustid_val = getattr(track, "acoustid_id", None)
        if not acoustid_val and isinstance(getattr(track, "identifiers", None), dict):
            acoustid_val = track.identifiers.get(
                "acoustid_id"
            ) or track.identifiers.get("acoustid")

        if acoustid_val and isinstance(acoustid_val, str) and len(acoustid_val) > 10:
            logger.debug(
                f"[MusicBrainz Client] Trying AcoustID query on MusicBrainz: acoustid:{acoustid_val}"
            )
            results = self._search_metadata_query(
                query=f"acoustid:{acoustid_val}", limit=5
            )
            if results:
                top = results[0]
                mbid = top.get("recording_id") or top.get("mbid")
                if mbid:
                    fetched = self.get_track(mbid)
                    if isinstance(fetched, EchosyncTrack):
                        return fetched

        safe_title = self._escape_lucene(clean_title)
        safe_artist = self._escape_lucene(clean_artist)

        is_numeric_artist = clean_artist.isdigit()

        # Clean leading year from album name (e.g. "2018 - Album Name" -> "Album Name")
        clean_album_str = (
            re.sub(r"^\d{4}\s*[-_]\s*", "", album.strip()) if album else ""
        )
        safe_album = self._escape_lucene(clean_album_str) if clean_album_str else ""

        # Extract primary artist if multi-artist separators or featuring tags exist
        raw_artist = (
            getattr(track, "artist_name", None)
            or getattr(track, "artist", None)
            or artist
            or ""
        )
        primary_artist = (
            re.split(
                r"[,/;]|\s+(?:feat\.?|ft\.?|&)\s+", raw_artist, flags=re.IGNORECASE
            )[0].strip()
            if raw_artist
            else ""
        )
        clean_primary = (
            normalize_artist(self._clean_query_artist(primary_artist))
            if primary_artist
            else ""
        )
        safe_primary = (
            self._escape_lucene(clean_primary) if clean_primary else safe_artist
        )

        # Strip non-alphanumeric noise and extract individual clean tokens for unquoted token queries
        tokens = [t for t in re.split(r"\W+", clean_primary or primary_artist) if t]
        token_query = " ".join(tokens)

        results = []

        if not is_numeric_artist and safe_primary:
            # Attempt 1 (Strict Exact with release / duration):
            if safe_album:
                strict_query = f'artist:"{safe_primary}" AND recording:"{safe_title}" AND release:"{safe_album}"'
                if duration_ms:
                    min_ms = max(0, duration_ms - 5000)
                    max_ms = duration_ms + 5000
                    logger.debug(
                        f"[MusicBrainz Client] Attempt 1 (Strict with duration): '{strict_query} AND dur:[{min_ms} TO {max_ms}]'"
                    )
                    results = self._search_metadata_query(
                        query=f"{strict_query} AND dur:[{min_ms} TO {max_ms}]", limit=5
                    )

                if not results:
                    logger.debug(
                        f"[MusicBrainz Client] Attempt 1 (Strict Exact): '{strict_query}'"
                    )
                    results = self._search_metadata_query(query=strict_query, limit=5)

            # Attempt 2 (Primary Artist Exact + Title Exact):
            if not results:
                attempt2_query = f'artist:"{safe_primary}" AND recording:"{safe_title}"'
                logger.debug(
                    f"[MusicBrainz Client] Attempt 2 (Primary Artist Exact + Title Exact): '{attempt2_query}'"
                )
                results = self._search_metadata_query(query=attempt2_query, limit=5)

            # Attempt 3 (Unquoted Artist Tokens + Title Exact - Matches collaborations like "Madison Mars feat. ..."):
            if not results and token_query:
                attempt3_query = f'artist:({token_query}) AND recording:"{safe_title}"'
                logger.debug(
                    f"[MusicBrainz Client] Attempt 3 (Unquoted Artist Tokens + Title Exact): '{attempt3_query}'"
                )
                results = self._search_metadata_query(query=attempt3_query, limit=5)

            # Attempt 4 (Artist Wildcard + Title Exact):
            if not results:
                attempt4_query = (
                    f'artist:"{safe_primary}"* AND recording:"{safe_title}"'
                )
                logger.debug(
                    f"[MusicBrainz Client] Attempt 4 (Artist Wildcard + Title Exact): '{attempt4_query}'"
                )
                results = self._search_metadata_query(query=attempt4_query, limit=5)

            # Legacy Fallback 1: Strip parenthetical/bracketed phrases from the title and search again
            if not results:
                fallback_title = re.sub(r"[\(\[\{].*?[\)\]\}]", "", clean_title).strip()
                fallback_title = re.sub(r"\s+", " ", fallback_title)
                if fallback_title and fallback_title != clean_title:
                    safe_fallback_title = self._escape_lucene(fallback_title)
                    logger.debug(
                        f"[MusicBrainz Client] Bracket Stripping Fallback: title='{fallback_title}'"
                    )
                    legacy_query = (
                        f'artist:"{safe_primary}" AND recording:"{safe_fallback_title}"'
                    )
                    results = self._search_metadata_query(query=legacy_query, limit=5)

        # Fallback without artist / Recording Only (Attempt 5)
        if not results and safe_title:
            if safe_album:
                logger.debug(
                    f"[MusicBrainz Client] Trying Release + Recording fallback: recording='{safe_title}', release='{safe_album}'"
                )
                results = self._search_metadata_query(
                    query=f'recording:"{safe_title}" AND release:"{safe_album}"',
                    limit=5,
                )
            if not results:
                attempt5_query = f'recording:"{safe_title}"'
                logger.debug(
                    f"[MusicBrainz Client] Attempt 5 (Recording Only Fallback with limit=15): '{attempt5_query}'"
                )
                results = self._search_metadata_query(query=attempt5_query, limit=15)

        if results:
            # Multi-Candidate Evaluation using MatchingEngine
            from core.matching_engine.matching_engine import WeightedMatchingEngine
            from core.matching_engine.scoring_profile import PROFILE_EXACT_SYNC

            source_artist_raw = (
                getattr(track, "artist_name", None)
                or getattr(track, "artist", None)
                or artist
                or ""
            )
            source_track = EchosyncTrack(
                raw_title=clean_title
                or (track.raw_title if isinstance(track, EchosyncTrack) else title),
                artist_name=clean_primary or clean_artist or source_artist_raw,
                album_title=clean_album_str
                or (track.album_title if isinstance(track, EchosyncTrack) else album),
                duration=(
                    getattr(track, "duration", None)
                    or getattr(track, "duration_ms", None)
                    or duration_ms
                ),
                isrc=(
                    getattr(track, "isrc", None)
                    if isinstance(track, EchosyncTrack)
                    else None
                ),
            )

            engine = WeightedMatchingEngine(PROFILE_EXACT_SYNC)
            best_candidate: EchosyncTrack | None = None
            best_score: float = -1.0

            seen_mbids = set()
            for cand in results:
                if not isinstance(cand, dict):
                    continue
                mbid = cand.get("recording_id") or cand.get("mbid")
                if not mbid or mbid in seen_mbids:
                    continue
                seen_mbids.add(mbid)

                fetched = self.get_track(mbid)
                if not isinstance(fetched, EchosyncTrack):
                    continue

                if source_track:
                    # Create normalized comparison candidate stripping feat/collaborations so
                    # collaborative credits like "Madison Mars feat. Feldz" match "Madison Mars, Feldz" cleanly
                    cand_raw_artist = fetched.artist_name or ""
                    cand_primary = (
                        re.split(
                            r"[,/;]|\s+(?:feat\.?|ft\.?|&)\s+",
                            cand_raw_artist,
                            flags=re.IGNORECASE,
                        )[0].strip()
                        if cand_raw_artist
                        else ""
                    )
                    clean_cand_primary = (
                        normalize_artist(self._clean_query_artist(cand_primary))
                        if cand_primary
                        else ""
                    )

                    eval_candidate = EchosyncTrack(
                        raw_title=fetched.raw_title,
                        artist_name=clean_cand_primary or fetched.artist_name,
                        album_title=fetched.album_title,
                        duration=fetched.duration,
                        isrc=fetched.isrc,
                        musicbrainz_id=fetched.musicbrainz_id,
                    )

                    match_result_raw = engine.calculate_match(source_track, fetched)
                    match_result_eval = engine.calculate_match(
                        source_track, eval_candidate
                    )

                    match_result = (
                        match_result_eval
                        if (
                            match_result_eval
                            and (
                                not match_result_raw
                                or match_result_eval.confidence_score
                                >= match_result_raw.confidence_score
                            )
                        )
                        else match_result_raw
                    )

                    score = match_result.confidence_score if match_result else 0.0
                    passed_version = (
                        match_result.passed_version_check if match_result else False
                    )
                    logger.debug(
                        f"[MusicBrainz Client] Candidate '{fetched.title}' by '{fetched.artist_name}' "
                        f"(MBID: {mbid}) scored {score:.1f}% (version_pass={passed_version})"
                    )

                    # Filter by match_result.passed_version_check and score >= 85.0
                    if passed_version and score >= 85.0 and score > best_score:
                        best_score = score
                        best_candidate = fetched
                else:
                    best_candidate = fetched
                    break

            if best_candidate:
                logger.debug(
                    f"[MusicBrainz Client] Winner selected: {best_candidate.title} by {best_candidate.artist_name} (score: {best_score:.1f}%)"
                )
                return best_candidate
        else:
            logger.debug(
                "[MusicBrainz Client] No search results returned from _search_metadata_query after all fallback attempts"
            )
        return None

    def _clean_query_artist(self, artist_str: str) -> str:
        """Strip featuring patterns cleanly without leaving trailing punctuation."""
        if not artist_str:
            return ""
        import re

        # Strip feat./ft./featuring/with/vs. and trailing periods/ampersands
        cleaned = re.sub(
            r"(?i)\s+(?:feat\.?|ft\.?|featuring|with|vs\.?)\s+.*$", "", artist_str
        ).strip()
        cleaned = re.sub(
            r"[\(\[]\s*(?:feat\.?|ft\.?|featuring|with)\s+[^()\[\]]*?[\)\]]",
            "",
            cleaned,
            flags=re.IGNORECASE,
        )
        cleaned = re.sub(r"[\s&.,\-]+$", "", cleaned).strip()
        return cleaned or artist_str.strip()

    def _escape_lucene(self, term: str) -> str:
        r"""Escape Lucene special characters: + - && || ! ( ) { } [ ] ^ " ~ * ? : \ /
        Do NOT escape punctuation inside double-quoted string literals.
        """
        if not term:
            return ""
        import re

        def _escape_unquoted(s: str) -> str:
            s = re.sub(r'([+\-!(){}\[\]^"~*?:\\/])', r"\\\1", s)
            s = re.sub(r"(?<!\\)&&", r"\&&", s)
            s = re.sub(r"(?<!\\)\|\|", r"\|\|", s)
            return s

        parts = re.split(r'("[^"]*")', term)
        escaped_parts = []
        for part in parts:
            if part.startswith('"') and part.endswith('"') and len(part) >= 2:
                inner = part[1:-1].replace("\\", "\\\\").replace('"', '\\"')
                escaped_parts.append(f'"{inner}"')
            else:
                escaped_parts.append(_escape_unquoted(part))

        return "".join(escaped_parts).strip()

    async def search_recording_strict(
        self, artist: str, title: str, immediate: bool = False
    ) -> list[EchosyncTrack]:
        if not artist or not title:
            return []

        # 1. Check Cache
        lookup_str = f"{artist}||{title}".lower()
        lookup_hash = hashlib.sha256(lookup_str.encode("utf-8")).hexdigest()

        with self.sdk.db.get_plugin_session() as session:
            cached = (
                session.query(PluginMusicbrainzCache)
                .filter_by(lookup_hash=lookup_hash)
                .first()
            )
            if cached:
                # Convert back to EchosyncTrack objects
                try:
                    metadata_list = cached.metadata_json
                    return [EchosyncTrack(**m) for m in metadata_list]
                except Exception as e:
                    logger.warning(f"Failed to parse cached MusicBrainz data: {e}")

        # 2. Immediate Bypass
        if immediate:
            safe_artist = self._escape_lucene(artist)
            safe_title = self._escape_lucene(title)
            query = f'artist:"{safe_artist}" AND recording:"{safe_title}"'
            try:
                loop = asyncio.get_running_loop()
                import functools

                get_func = functools.partial(
                    self.http.get,
                    f"{self.api_base}/recording",
                    params={
                        "fmt": "json",
                        "query": query,
                        "inc": "releases+artists",
                        "limit": 3,
                    },
                )
                response = await loop.run_in_executor(None, get_func)

                if response.status_code != 200:
                    logger.warning(
                        "MusicBrainz immediate search failed (status=%s, query=%s)",
                        response.status_code,
                        query,
                    )
                    return []

                payload = response.json() or {}
                recordings = payload.get("recordings", []) or []
                results = []

                for recording in recordings:
                    rec_title = str(recording.get("title") or "").strip()
                    if not rec_title:
                        continue

                    # Extract artist
                    artist_credit = recording.get("artist-credit") or []
                    artist_parts = []
                    for entry in artist_credit:
                        if isinstance(entry, dict) and "artist" in entry:
                            artist_parts.append(str(entry.get("name") or ""))
                            artist_parts.append(str(entry.get("joinphrase") or ""))
                    rec_artist = "".join(artist_parts).strip()

                    mbid = str(recording.get("id"))
                    releases = recording.get("releases") or []
                    first_release = releases[0] if releases else {}
                    album = str(first_release.get("title") or "Unknown Album")

                    duration_ms = None
                    dur = recording.get("length")
                    if dur and str(dur).isdigit():
                        duration_ms = int(dur)

                    track = self.create_echo_sync_track(
                        title=rec_title,
                        artist=rec_artist or "Unknown Artist",
                        album=album,
                        musicbrainz_id=mbid,
                        duration_ms=duration_ms,
                        provider_id=mbid,
                        source=self.name,
                    )

                    isrcs = recording.get("isrcs") or []
                    if isrcs:
                        track.isrc = str(isrcs[0])

                    results.append(track)
                    if len(results) >= 3:
                        break

                # Cache successful results
                if results:
                    try:
                        with self.sdk.db.get_plugin_session() as session:
                            if (
                                not session.query(PluginMusicbrainzCache)
                                .filter_by(lookup_hash=lookup_hash)
                                .first()
                            ):
                                metadata_json = [t.model_dump() for t in results]
                                cached_entry = PluginMusicbrainzCache(
                                    id=lookup_hash,
                                    lookup_hash=lookup_hash,
                                    mbid=results[0].musicbrainz_id,
                                    metadata_json=metadata_json,
                                )
                                session.add(cached_entry)
                    except Exception as e:
                        logger.error(
                            f"Failed to cache immediate MusicBrainz result: {e}"
                        )

            except HttpError as exc:
                logger.warning(f"MusicBrainz immediate search HTTP error: {exc}")
                return []
            except Exception as e:
                logger.error(f"Exception during immediate MusicBrainz search: {e}")
                return []

        # 3. Queue for Micro-batching
        loop = asyncio.get_running_loop()
        future = loop.create_future()

        async with self._lock:
            self._search_queue.append((artist, title, lookup_hash, future))
            if self._batch_task is None or self._batch_task.done():
                self._batch_task = asyncio.create_task(self._process_batch())

        # 4. Await batched result
        try:
            return await future
        except Exception as e:
            logger.error(f"Error awaiting batched result: {e}")
            return []

    async def search_recording(
        self, artist: str, title: str, immediate: bool = False
    ) -> list[EchosyncTrack]:
        """Search recordings matching artist and title (alias to search_recording_strict)."""
        return await self.search_recording_strict(artist, title, immediate=immediate)

    async def _process_batch(self):
        await asyncio.sleep(0.1)  # 100ms debounce

        async with self._lock:
            if not self._search_queue:
                return
            batch = self._search_queue[:]
            self._search_queue.clear()

        # Construct Lucene OR query
        query_parts = []
        for artist, title, _, _ in batch:
            safe_artist = self._escape_lucene(artist)
            safe_title = self._escape_lucene(title)
            query_parts.append(f'(artist:"{safe_artist}" AND recording:"{safe_title}")')

        full_query = " OR ".join(query_parts)

        # Max items per page is 100
        try:
            # We run the synchronous http.get in an executor to avoid blocking the event loop
            loop = asyncio.get_running_loop()
            import functools

            get_func = functools.partial(
                self.http.get,
                f"{self.api_base}/recording",
                params={
                    "fmt": "json",
                    "query": full_query,
                    "inc": "releases+artists",
                    "limit": len(batch) * 3,  # up to 3 per request
                },
            )
            response = await loop.run_in_executor(None, get_func)

            if response.status_code != 200:
                logger.warning(
                    f"MusicBrainz batch search failed (status={response.status_code})"
                )
                for _, _, _, future in batch:
                    if not future.done():
                        future.set_result([])
                return

            payload = response.json() or {}
            recordings = payload.get("recordings", []) or []

            # Map results to original queries
            for artist, title, lookup_hash, future in batch:
                best_matches = []
                for recording in recordings:
                    rec_title = str(recording.get("title") or "").strip()
                    if not rec_title:
                        continue

                    # Extract artist
                    artist_credit = recording.get("artist-credit") or []
                    artist_parts = []
                    for entry in artist_credit:
                        if isinstance(entry, dict) and "artist" in entry:
                            artist_parts.append(str(entry.get("name") or ""))
                            artist_parts.append(str(entry.get("joinphrase") or ""))
                    rec_artist = "".join(artist_parts).strip()

                    # Simple matching
                    title_score = fuzz.ratio(title.lower(), rec_title.lower())
                    artist_score = fuzz.ratio(artist.lower(), rec_artist.lower())

                    if title_score > 80 and artist_score > 80:
                        mbid = str(recording.get("id"))
                        releases = recording.get("releases") or []
                        first_release = releases[0] if releases else {}
                        album = str(first_release.get("title") or "Unknown Album")

                        duration_ms = None
                        dur = recording.get("length")
                        if dur and str(dur).isdigit():
                            duration_ms = int(dur)

                        track = self.create_echo_sync_track(
                            title=rec_title,
                            artist=rec_artist or "Unknown Artist",
                            album=album,
                            musicbrainz_id=mbid,
                            duration_ms=duration_ms,
                            provider_id=mbid,
                            source=self.name,
                        )

                        isrcs = recording.get("isrcs") or []
                        if isrcs:
                            track.isrc = str(isrcs[0])

                        best_matches.append(track)
                        if len(best_matches) >= 3:
                            break

                # Resolve future
                if not future.done():
                    future.set_result(best_matches)

                # Cache successful results
                if best_matches:
                    try:
                        with self.sdk.db.get_plugin_session() as session:
                            # Avoid duplicates
                            if (
                                not session.query(PluginMusicbrainzCache)
                                .filter_by(lookup_hash=lookup_hash)
                                .first()
                            ):
                                metadata_json = [t.model_dump() for t in best_matches]
                                cached_entry = PluginMusicbrainzCache(
                                    id=lookup_hash,
                                    lookup_hash=lookup_hash,
                                    mbid=best_matches[0].musicbrainz_id,
                                    metadata_json=metadata_json,
                                )
                                session.add(cached_entry)
                    except Exception as e:
                        logger.error(f"Failed to cache MusicBrainz batch result: {e}")

        except HttpError as exc:
            logger.warning(f"MusicBrainz batch search HTTP error: {exc}")
            for _, _, _, future in batch:
                if not future.done():
                    future.set_result([])
        except Exception as e:
            logger.error(f"Exception during MusicBrainz batch processing: {e}")
            for _, _, _, future in batch:
                if not future.done():
                    future.set_result([])

    def search_by_isrc(self, isrc: str) -> EchosyncTrack | None:
        """Implement PluginBase.search_by_isrc via the MusicBrainz ISRC endpoint."""
        isrc = str(isrc or "").strip().upper()
        if not isrc:
            return None
        try:
            response = self.http.get(
                f"{self.api_base}/isrc/{isrc}",
                params={"fmt": "json", "inc": "artists+releases"},
            )
            if response.status_code == 404:
                return None
            response.raise_for_status()
            data = response.json() or {}
            recordings = data.get("recordings") or []
            if not recordings:
                return None

            recording = recordings[0]
            artist_credit = recording.get("artist-credit") or []
            artist_parts: list[str] = []
            for entry in artist_credit:
                if isinstance(entry, dict) and "artist" in entry:
                    artist_parts.append(str(entry.get("name") or ""))
                    artist_parts.append(str(entry.get("joinphrase") or ""))
            artist_str = "".join(artist_parts).strip() or ""

            releases = recording.get("releases") or []
            first_release = releases[0] if releases else {}
            release_date = str(
                first_release.get("date") or recording.get("first-release-date") or ""
            )
            release_year = (
                int(release_date[:4])
                if len(release_date) >= 4 and release_date[:4].isdigit()
                else None
            )

            duration_ms = recording.get("length")
            try:
                duration_ms = int(duration_ms) if duration_ms is not None else None
            except (TypeError, ValueError):
                duration_ms = None

            return self.create_echo_sync_track(
                title=str(recording.get("title") or ""),
                artist=artist_str,
                album=str(first_release.get("title") or "") or None,
                musicbrainz_id=str(recording.get("id") or "") or None,
                isrc=isrc,
                year=release_year,
                duration_ms=duration_ms,
                source=self.name,
            )
        except Exception as exc:
            logger.warning("MusicBrainz search_by_isrc(%s) failed: %s", isrc, exc)
            return None

    def get_metadata(self, mbid: str) -> dict[str, Any] | None:
        """Fetch detailed metadata for a recording MBID."""
        mbid = str(mbid or "").strip()
        if not mbid:
            return None

        try:
            logger.debug(
                f"[MusicBrainz Client] Fetching detailed metadata for mbid='{mbid}' via GET {self.api_base}/recording/{mbid}"
            )
            response = self.http.get(
                f"{self.api_base}/recording/{mbid}",
                params={"fmt": "json", "inc": "artists+releases+release-groups+isrcs+media"},
            )
            logger.debug(
                f"[MusicBrainz Client] get_metadata response: status={response.status_code}"
            )
            if response.status_code != 200:
                logger.warning(
                    f"MusicBrainz get_metadata failed for mbid={mbid}: status={response.status_code}"
                )
                return None

            data = response.json() or {}
            logger.debug(f"[MusicBrainz Client] get_metadata response JSON: {data}")
            releases = data.get("releases") or []
            result = {
                "title": data.get("title"),
                "disambiguation": data.get("disambiguation") or "",
                "recording_id": data.get("id"),
                "artist": "",
                "artist_id": "",
                "album": "",
                "release_id": "",
                "release_group_id": "",
                "date": "",
                "track_number": None,
                "disc_number": None,
                "cover_art_url": None,
                "isrc": None,
                "duration_ms": int(data.get("length"))
                if data.get("length") and str(data.get("length")).isdigit()
                else None,
                "length": int(data.get("length"))
                if data.get("length") and str(data.get("length")).isdigit()
                else None,
                "releases": releases,
            }

            credits = data.get("artist-credit") or []
            if credits:
                name_parts = []
                for credit in credits:
                    if isinstance(credit, dict):
                        name_parts.append(str(credit.get("name") or ""))
                        name_parts.append(str(credit.get("joinphrase") or ""))
                result["artist"] = "".join(name_parts).strip()
                if isinstance(credits[0], dict) and isinstance(
                    credits[0].get("artist"), dict
                ):
                    result["artist_id"] = credits[0]["artist"].get("id") or ""

            canonical_release = self.resolve_canonical_studio_release(releases)
            if canonical_release:
                result["album"] = canonical_release.get("canonical_studio_album") or ""
                result["release_id"] = canonical_release.get("canonical_studio_release_mbid") or ""
                result["release_group_id"] = canonical_release.get("canonical_studio_release_group_mbid") or ""
                result["date"] = canonical_release.get("date") or ""
            elif releases:
                release = releases[0] or {}
                result["album"] = release.get("title") or ""
                result["release_id"] = release.get("id") or ""
                result["release_group_id"] = (release.get("release-group") or {}).get("id") or ""
                result["date"] = release.get("date") or ""

            isrcs = data.get("isrcs") or []
            if isrcs:
                result["isrc"] = isrcs[0]

            return result

        except HttpError as exc:
            logger.warning(f"MusicBrainz get_metadata HTTP error for {mbid}: {exc}")
            return None
        except Exception as exc:
            logger.error(f"Failed to fetch metadata for {mbid}: {exc}")
            return None

    def get_metadata_batch(self, mbids: list[str]) -> dict[str, dict[str, Any]]:
        """Fetch full metadata for multiple recording MBIDs in batches up to 50."""
        mbids = [str(m).strip() for m in mbids if str(m).strip()]
        if not mbids:
            return {}

        results = {}
        # Max limit for search API is 100, we'll chunk by 50 to be safe
        chunk_size = 50
        for i in range(0, len(mbids), chunk_size):
            chunk = mbids[i : i + chunk_size]
            query_parts = [f"reid:{mbid}" for mbid in chunk]
            full_query = " OR ".join(query_parts)

            try:
                response = self.http.get(
                    f"{self.api_base}/recording",
                    params={
                        "fmt": "json",
                        "query": full_query,
                        "inc": "artists+releases+release-groups+isrcs+media",
                        "limit": len(chunk),
                    },
                )
                if response.status_code != 200:
                    logger.warning(
                        f"Batch metadata fetch failed: {response.status_code}"
                    )
                    continue

                data = response.json() or {}
                for recording in data.get("recordings", []) or []:
                    rec_id = str(recording.get("id") or "").strip()
                    if not rec_id or rec_id not in chunk:
                        continue

                    rec_releases = recording.get("releases") or []
                    result = {
                        "title": recording.get("title"),
                        "disambiguation": recording.get("disambiguation") or "",
                        "recording_id": rec_id,
                        "artist": "",
                        "artist_id": "",
                        "album": "",
                        "release_id": "",
                        "release_group_id": "",
                        "date": "",
                        "track_number": None,
                        "disc_number": None,
                        "cover_art_url": None,
                        "isrc": None,
                        "duration_ms": int(recording.get("length"))
                        if recording.get("length")
                        and str(recording.get("length")).isdigit()
                        else None,
                        "length": int(recording.get("length"))
                        if recording.get("length")
                        and str(recording.get("length")).isdigit()
                        else None,
                        "releases": rec_releases,
                    }

                    credits = recording.get("artist-credit") or []
                    if credits:
                        name_parts = []
                        for credit in credits:
                            if isinstance(credit, dict):
                                name_parts.append(str(credit.get("name") or ""))
                                name_parts.append(str(credit.get("joinphrase") or ""))
                        result["artist"] = "".join(name_parts).strip()
                        if isinstance(credits[0], dict) and isinstance(
                            credits[0].get("artist"), dict
                        ):
                            result["artist_id"] = credits[0]["artist"].get("id") or ""

                    canonical_release = self.resolve_canonical_studio_release(rec_releases)
                    if canonical_release:
                        result["album"] = canonical_release.get("canonical_studio_album") or ""
                        result["release_id"] = canonical_release.get("canonical_studio_release_mbid") or ""
                        result["release_group_id"] = canonical_release.get("canonical_studio_release_group_mbid") or ""
                        result["date"] = canonical_release.get("date") or ""
                    elif rec_releases:
                        release = rec_releases[0] or {}
                        result["album"] = release.get("title") or ""
                        result["release_id"] = release.get("id") or ""
                        result["release_group_id"] = (release.get("release-group") or {}).get("id") or ""
                        result["date"] = release.get("date") or ""

                    isrcs = recording.get("isrcs") or []
                    if isrcs:
                        result["isrc"] = isrcs[0]

                    results[rec_id] = result

            except HttpError as exc:
                logger.warning(f"MusicBrainz batch metadata HTTP error: {exc}")
                continue
            except Exception as exc:
                logger.error(f"Failed to fetch batch metadata: {exc}")
                continue

        return results

    @plugin_cache(ttl_seconds=2592000)
    def get_release(self, release_id: str) -> dict[str, Any] | None:
        """Fetch full release data for the album memory cache in MetadataEnhancerService.

        Returns a dict with:
          - ``album``: release title
          - ``cover_art_url``: front cover URL from the Cover Art Archive (or None)
          - ``tracks``: list of track dicts, each carrying title, artist,
            track_number, disc_number, recording_id, release_id, isrc,
            duration_ms, date, cover_art_url

        Called at most once per release per 30-day cache window, eliminating
        N−1 redundant AcoustID / MusicBrainz calls when an entire album lands
        in the download directory at once.
        """
        release_id = str(release_id or "").strip()
        if not release_id:
            return None

        try:
            response = self.http.get(
                f"{self.api_base}/release/{release_id}",
                params={"fmt": "json", "inc": "recordings+artist-credits"},
            )
            if response.status_code != 200:
                return None

            data = response.json() or {}
            album_title = str(data.get("title") or "").strip()
            release_date = str(data.get("date") or "").strip()
            cover_art_url = None

            tracks: list[dict[str, Any]] = []
            for medium in data.get("media", []) or []:
                disc_number = int(medium.get("position") or 1)
                for track_entry in medium.get("tracks", []) or []:
                    recording = track_entry.get("recording") or {}
                    raw_pos = track_entry.get("number") or track_entry.get("position")
                    try:
                        track_number: int | None = int(
                            str(raw_pos).split("/")[0].strip()
                        )
                    except (TypeError, ValueError):
                        track_number = None

                    artist_credit = recording.get("artist-credit") or []
                    artist_parts: list[str] = []
                    for entry in artist_credit:
                        if isinstance(entry, dict):
                            artist_parts.append(str(entry.get("name") or ""))
                            artist_parts.append(str(entry.get("joinphrase") or ""))
                    artist_str = "".join(artist_parts).strip()
                    if not artist_str:
                        for entry in data.get("artist-credit", []) or []:
                            if isinstance(entry, dict):
                                artist_str += str(entry.get("name") or "")
                                artist_str += str(entry.get("joinphrase") or "")
                        artist_str = artist_str.strip()

                    recording_id = str(recording.get("id") or "").strip() or None
                    title = str(
                        recording.get("title") or track_entry.get("title") or ""
                    ).strip()
                    duration_ms = recording.get("length")
                    try:
                        duration_ms = (
                            int(duration_ms) if duration_ms is not None else None
                        )
                    except (TypeError, ValueError):
                        duration_ms = None

                    isrc_list = recording.get("isrcs") or []
                    isrc = str(isrc_list[0]).strip() if isrc_list else None

                    tracks.append(
                        {
                            "title": title,
                            "artist": artist_str,
                            "album": album_title,
                            "track_number": track_number,
                            "disc_number": disc_number,
                            "recording_id": recording_id,
                            "release_id": release_id,
                            "isrc": isrc,
                            "duration_ms": duration_ms,
                            "date": release_date,
                            "cover_art_url": cover_art_url,
                        }
                    )

            return {
                "album": album_title,
                "cover_art_url": cover_art_url,
                "tracks": tracks,
            }
        except Exception as exc:
            logger.warning(
                "MusicBrainzClient.get_release(%s) failed: %s", release_id, exc
            )
            return None

    def _get_cover_art(self, release_id: str) -> str | None:
        # Cover art is sourced from the media server (Plex/Jellyfin) during library
        # sync. We never query coverartarchive.org so that the enhancer stays fast
        # and does not consume bandwidth on redirected image HEAD requests.
        return None

    # PluginBase abstract methods
    def authenticate(self, **kwargs) -> bool:
        return True

    def search(
        self,
        query: str,
        type: str = "track",
        limit: int = 10,
        quality_profile: dict[str, Any] | None = None,
    ) -> list[EchosyncTrack]:
        if type != "track":
            return []
        query_clean = str(query or "").strip()
        if not query_clean:
            return []
        safe_query = self._escape_lucene(query_clean)
        try:
            results = self._search_metadata_query(
                f'recording:"{safe_query}"', limit=limit
            )
            tracks: list[EchosyncTrack] = []
            for r in results:
                mbid = r.get("mbid")
                track_obj = self.create_echo_sync_track(
                    title=r.get("title") or "",
                    artist=r.get("artist") or "",
                    album=r.get("album") or "Unknown Album",
                    musicbrainz_id=mbid,
                    isrc=r.get("isrc"),
                    duration_ms=r.get("duration"),
                    provider_id=mbid,
                    source=self.name,
                )
                if track_obj:
                    tracks.append(track_obj)
            return tracks
        except Exception as exc:
            logger.warning("MusicBrainzClient.search failed: %s", exc)
            return []

    def get_track(self, track_id: str) -> EchosyncTrack | None:
        logger.debug(f"[MusicBrainz Client] get_track called for track_id={track_id}")
        metadata = self.get_metadata(track_id)
        if not metadata:
            logger.debug(
                f"[MusicBrainz Client] No metadata returned for track_id={track_id}"
            )
            return None
        track_obj = self.create_echo_sync_track(
            title=metadata.get("title") or "",
            artist=metadata.get("artist") or "",
            album=metadata.get("album") or "Unknown Album",
            musicbrainz_id=metadata.get("recording_id"),
            isrc=metadata.get("isrc"),
            provider_id=metadata.get("recording_id"),
            source=self.name,
        )
        logger.debug(
            f"[MusicBrainz Client] Created EchosyncTrack object: {track_obj.to_dict() if track_obj else None}"
        )
        return track_obj

    def get_album(self, album_id: str) -> dict[str, Any] | None:
        return None

    def get_artist(self, artist_id: str) -> dict[str, Any] | None:
        tracks = self.get_artist_tracks(artist_id)
        return {"id": artist_id, "tracks": tracks}

    def get_user_playlists(self, user_id: str | None = None) -> list[dict[str, Any]]:
        return []

    def get_playlist_tracks(self, playlist_id: str) -> list[EchosyncTrack]:
        return []

    def get_active_access_token(self, account_id: int | None = None) -> str | None:
        """Return a decrypted access token for the first (or specified) authenticated account.

        Returns None when no authenticated account is available, which means the
        client falls back to anonymous / read-only API access.
        """
        try:
            accounts = self.accounts.get_all()
            if not accounts:
                return None

            if account_id is not None:
                target = next((a for a in accounts if a.get("id") == account_id), None)
            else:
                # Prefer active + authenticated, fall back to first authenticated
                target = next(
                    (
                        a
                        for a in accounts
                        if a.get("is_authenticated") and a.get("is_active")
                    ),
                    next((a for a in accounts if a.get("is_authenticated")), None),
                )

            if not target:
                return None

            return self.accounts.get_token(target.get("id"))

            # get_account_token in StorageService handles database access safely
            token_row = storage.get_account_token(target["id"])
            if not token_row:
                return None

            if token_row and token_row.get("access_token"):
                # StorageService.get_account_token should return decrypted token
                return token_row["access_token"]
            return None
        except Exception as e:
            logger.debug(f"Could not load MusicBrainz access token: {e}")
            return None

    def submit_isrc(self, mbid: str, isrc: str, account_id: int | None = None) -> bool:
        """Submit an ISRC–recording association to MusicBrainz.

        Requires the user to have authenticated with the ``submit_isrc`` scope.
        Returns True on success, False otherwise.

        Args:
            mbid: MusicBrainz recording MBID (UUID).
            isrc: ISRC code to associate with the recording (e.g. "USRC17607839").
            account_id: Specific account ID to use; defaults to the active authenticated account.
        """
        mbid = str(mbid or "").strip()
        isrc = str(isrc or "").strip()
        if not mbid or not isrc:
            logger.warning("submit_isrc called with empty mbid or isrc")
            return False

        # Opt-in check: only submit if auto_contribute is enabled in settings
        try:
            from core.nexus_framework.plugin_SDK import sdk

            auto_contribute = sdk.config.get("auto_contribute")
            if not (auto_contribute == "true" or auto_contribute is True):
                logger.debug(
                    "Skipping MusicBrainz ISRC submission: auto_contribute is disabled"
                )
                return False
        except Exception as e:
            logger.debug(f"Could not verify MusicBrainz auto_contribute flag: {e}")
            return False

        access_token = self.get_active_access_token(account_id)
        if not access_token:
            logger.warning(
                "MusicBrainz submit_isrc: no authenticated account available"
            )
            return False

        xml_body = (
            '<?xml version="1.0" encoding="UTF-8"?>'
            '<metadata xmlns="http://musicbrainz.org/ns/mmd-2.0#">'
            f'<recording id="{mbid}">'
            '<isrc-list><isrc id="' + isrc + '"/></isrc-list>'
            "</recording>"
            "</metadata>"
        )
        try:
            resp = self.http.post(
                f"{self.api_base}/recording/{mbid}",
                params={
                    "client": "Echosync-0.1.0-https://github.com/echosync/echosync"
                },
                data=xml_body,
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "Content-Type": "application/xml; charset=UTF-8",
                },
            )
            if resp.status_code in (200, 204):
                logger.info(f"ISRC {isrc} submitted for MBID {mbid}")
                return True
            logger.warning(
                f"MusicBrainz ISRC submission returned {resp.status_code}: {resp.text[:200]}"
            )
            return False
        except Exception as e:
            logger.error(f"MusicBrainz submit_isrc failed: {e}")
            return False

    def is_configured(self) -> bool:
        return True

    def get_logo_url(self) -> str:
        return "https://musicbrainz.org/static/images/entity/musicbrainz_logo.svg"


# Backward compatibility alias for older imports.
MusicBrainzProvider = MusicBrainzClient

# Ensure plugin loader/runtime registry can resolve this provider class.
