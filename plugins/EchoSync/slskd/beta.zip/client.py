import asyncio
import re
from typing import List, Optional, Dict, Any, Union, Tuple
from dataclasses import dataclass
import time
from pathlib import Path
from core.tiered_logger import get_logger

from core.nexus_framework.plugin_SDK import DownloaderProvider, ProviderCapabilities, PlaylistSupport, SearchCapabilities, MetadataRichness

from core.nexus_framework.plugin_loader import PluginRegistry, ServiceRegistry
from core.db.echo_sync_track import EchosyncTrack
from core.matching_engine.track_parser import TrackParser
from core.request_manager import RequestManager, RateLimitConfig, HttpError

logger = get_logger("slskd_provider")


def _sanitize_peer_filename(filename: str) -> str:
    """Collapse any peer-supplied path to a safe local filename."""
    normalized = (filename or "").replace('\\', '/')
    basename = Path(normalized).name
    return basename or "downloaded_file"

@dataclass
class SearchResult:
    """Base class for search results"""
    username: str
    filename: str
    size: int
    bitrate: Optional[int]
    duration: Optional[int]
    quality: str
    free_upload_slots: int
    upload_speed: int
    queue_length: int
    result_type: str = "track"  # "track" or "album"

@dataclass
class TrackResult(SearchResult):
    """Individual track search result"""
    artist: Optional[str] = None
    title: Optional[str] = None
    album: str = ""  # Default to empty string instead of None for consistency
    track_number: Optional[int] = None
    bit_depth: Optional[int] = None
    sample_rate: Optional[int] = None

    def __post_init__(self):
        self.result_type = "track"
        # Try to extract metadata from filename if not provided
        self._parse_filename_metadata()

    def _parse_filename_metadata(self):
        """Extract artist, title, album, bit depth, sample rate from filename patterns"""

        # Normalize path separators (handle both / and \ from Soulseek)
        normalized_path = self.filename.replace('\\', '/')
        
        # Split path into components for heuristic extraction
        path_parts = normalized_path.split('/')
        
        # Get just the filename (last component) without extension
        file_with_ext = path_parts[-1] if path_parts else self.filename
        clean_filename = Path(file_with_ext).stem

        # 1. Parse Technical Metadata (Bit Depth / Sample Rate)
        # Look for patterns like "24bit", "24-bit", "24b", "96kHz", "44.1kHz", "44100Hz"
        # Search in the full filename/path in case metadata is in directory structure

        # Bit Depth
        bit_depth_match = re.search(r'(\d+)\s*[-_]?(?:bit|b)(?![a-zA-Z])', self.filename, re.IGNORECASE)
        if bit_depth_match:
            try:
                self.bit_depth = int(bit_depth_match.group(1))
            except ValueError:
                pass

        # Sample Rate
        sample_rate_match = re.search(r'(\d+(?:\.\d+)?)\s*(?:k?hz)', self.filename, re.IGNORECASE)
        if sample_rate_match:
            try:
                val_str = sample_rate_match.group(1)
                unit_str = sample_rate_match.group(0).lower()
                val = float(val_str)
                if 'khz' in unit_str:
                    self.sample_rate = int(val * 1000)
                else:
                    self.sample_rate = int(val)
            except ValueError:
                pass

        # 2. Parse Artist/Title/Album if missing
        if not self.title or not self.artist:
            # Common patterns for track naming (in order of specificity)
            # Strategy: Try to extract only when confident
            # Pattern 1: Track number + full title (e.g., "01 - All Remaining Content Here")
            # Pattern 2: Artist - Title split (e.g., "Artist Name - Song Title")
            patterns = [
                (r'^(\d+)\s*[-\.]\s*(.+)$', 'track_and_title'),     # "01 - Title" (keep everything after number)
                (r'^(.+?)\s*[-–]\s*(.+)$', 'artist_and_title'),      # "Artist - Title"
            ]

            for pattern, pattern_type in patterns:
                match = re.match(pattern, clean_filename)
                if match:
                    groups = match.groups()
                    if pattern_type == 'track_and_title':
                        # Pattern 1: Track number followed by everything else is the title
                        try:
                            self.track_number = int(groups[0])
                            self.title = self.title or groups[1].strip()
                        except (ValueError, IndexError):
                            pass
                    elif pattern_type == 'artist_and_title':
                        # Pattern 2: Split by first dash - artist and title
                        # Only set if we don't have either artist or title
                        if len(groups) == 2:
                            self.artist = self.artist or groups[0].strip()
                            self.title = self.title or groups[1].strip()
                    break

        # Fallback: use the clean filename (not full path) as title if nothing was extracted
        if not self.title:
            self.title = clean_filename

        # Heuristic Path Extraction: Extract artist/album from directory structure
        if len(path_parts) > 1:  # Has directory structure
            # Get meaningful directory parts (skip filename which is last)
            dir_parts = [p for p in path_parts[:-1] if p and not p.startswith('@')]
            
            # Skip generic/system folder patterns
            generic_folders_pattern = r'^(music|downloads?|library|media|my music|users?|documents?|desktop|lossless|flac|mp3|high.*quality|lossy|\d{4}|\d{2,})$'
            meaningful_dirs = [
                d for d in dir_parts
                if d and not re.match(generic_folders_pattern, d, re.IGNORECASE)
            ]
            
            # Extract artist and album from remaining folder hierarchy
            # If we have at least 2 meaningful directories: Artist/Album structure
            # If we have at least 1: likely Album
            if meaningful_dirs:
                # Parent folder (closest to file) is likely the album
                parent_folder = meaningful_dirs[-1] if meaningful_dirs else None
                # Grandparent folder (one level up) is likely the artist
                grandparent_folder = meaningful_dirs[-2] if len(meaningful_dirs) >= 2 else None
                
                # Use heuristic extraction ONLY if parsed values are missing or "Unknown"
                if not self.artist or self.artist.lower() in ["unknown artist", "unknown", ""]:
                    if grandparent_folder:
                        self.artist = grandparent_folder
                
                if not self.album or self.album.lower() in ["unknown album", "unknown", ""]:
                    if parent_folder:
                        self.album = parent_folder

class SlskdProvider(DownloaderProvider):
    """
    Stateless, high-efficiency API wrapper for Slskd.
    Follows "Dumb Executor" pattern - no orchestration logic.
    """
    name = "EchoSync.slskd"
    supports_downloads = True
    supports_pre_filtering = True
    rate_limit = 5.0 # High throughput allowed
    capabilities = ProviderCapabilities(
        name='slskd',
        supports_playlists=PlaylistSupport.NONE,
        search=SearchCapabilities(tracks=False, artists=False, albums=False, playlists=False),
        metadata=MetadataRichness.LOW,
        supports_cover_art=False,
        supports_lyrics=False,
        supports_user_auth=True,
        supports_library_scan=False,
        supports_streaming=False,
        supports_downloads=True,
        supports_pre_filtering=True,
    )

    def __init__(self):
        super().__init__() # Initialize rate-limited http client
        self.base_url: Optional[str] = None
        self.api_key: Optional[str] = None
        self.download_path: Path = Path("./downloads")
        # Concurrency limiter: Slskd can only handle 3 concurrent searches (IP ban protection)
        self._search_semaphore = asyncio.Semaphore(3)
        self._setup_client()
        self._register_health_check()
    
    def _register_health_check(self):
        """Register periodic health check for Slskd API."""
        if not self.is_configured():
            return
        
        from core.health_check import HealthCheckResult
        
        def slskd_health_check() -> HealthCheckResult:
            try:
                # Try a lightweight API call to check connectivity
                try:
                    import requests
                    response = requests.get(
                        f"{self.base_url}/api/v0/session",
                        headers={"X-API-Key": self.api_key},
                        timeout=5
                    )
                    if response.status_code == 200:
                        return HealthCheckResult(
                            service_name="slskd",
                            status="healthy",
                            message="Slskd API is reachable"
                        )
                    else:
                        return HealthCheckResult(
                            service_name="slskd",
                            status="degraded",
                            message=f"Slskd API returned status {response.status_code}"
                        )
                except Exception as api_err:
                    return HealthCheckResult(
                        service_name="slskd",
                        status="unhealthy",
                        message=f"Slskd API error: {str(api_err)}"
                    )
            except Exception as e:
                return HealthCheckResult(
                    service_name="slskd",
                    status="unhealthy",
                    message=f"Slskd health check error: {str(e)}"
                )
        
        self.sdk.health.register(slskd_health_check, interval_seconds=300)

    def _setup_client(self):
        # Retrieve Slskd connection details from namespaced config facade
        slskd_url = self.config.get('slskd_url') or self.config.get('server_url')
        api_key = self.config.get('api_key') or ''

        # Fallback: if URL isn't stored in namespaced config DB, check global config
        if not slskd_url:
            try:
                slskd_url = self.sdk.config.get('soulseek.slskd_url', '')
                if slskd_url:
                    logger.debug("Using slskd_url from global config as fallback")
            except Exception:
                slskd_url = None

        if not slskd_url:
            logger.warning("Slskd URL not configured")
            return

        # Apply Docker URL resolution if running in container
        if self.sdk.config.get('IS_DOCKER') and 'localhost' in slskd_url:
            slskd_url = slskd_url.replace('localhost', 'host.docker.internal')
            logger.info(f"Docker detected, using {slskd_url} for slskd connection")

        self.base_url = slskd_url.rstrip('/')
        self.api_key = api_key

        # Prefer global storage settings (from config manager) but fall back to per-provider values
        try:
            storage_cfg = self.sdk.config.get_all().get('storage', {}) or {}
        except Exception:
            storage_cfg = {}

        # Handle download path with Docker translation
        download_path_str = storage_cfg.get('download_dir') or './downloads'
        if self.sdk.config.get('IS_DOCKER') and len(download_path_str) >= 3 and download_path_str[1] == ':' and download_path_str[0].isalpha():
            # Convert Windows path (E:/path) to WSL mount path (/mnt/e/path)
            drive_letter = download_path_str[0].lower()
            rest_of_path = download_path_str[2:].replace('\\', '/')  # Remove E: and convert backslashes
            download_path_str = f"/host/mnt/{drive_letter}{rest_of_path}"
            logger.info(f"Docker detected, using {download_path_str} for downloads")

        self.download_path = Path(download_path_str)
        try:
            self.download_path.mkdir(parents=True, exist_ok=True)
        except Exception:
            # best-effort directory creation; continue even if it fails
            pass

        logger.info(f"Slskd provider configured at {self.base_url}")

    def _get_headers(self) -> Dict[str, str]:
        headers = {'Content-Type': 'application/json'}
        if self.api_key:
            headers['X-API-Key'] = self.api_key
        return headers

    async def _make_request(self, method: str, endpoint: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Unified request handler using self.http (RequestManager)"""
        if not self.base_url:
            logger.error("Slskd client not configured")
            return None

        url = f"{self.base_url}/api/v0/{endpoint}"

        try:
            headers = self._get_headers()

            logger.debug(f"Slskd API Request: {method} {url}")
            if kwargs.get('json'):
                logger.debug(f"Payload: {kwargs.get('json')}")

            # RequestManager.request is synchronous, so run in executor to avoid blocking
            # This respects the PluginBase rate limit configuration
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.http.request(method, url, headers=headers, **kwargs)
            )

            if response.status_code in [200, 201, 204]:
                if not response.content:
                    return {}
                return response.json()
            # Fallback for any non-raising 2xx-adjacent path
            return None

        except HttpError as e:
            # RequestManager raises HttpError for 4xx/5xx responses.
            # 404 on a search DELETE is expected (search already expired on the slskd side).
            if e.status == 404 and 'searches/' in url and method == 'DELETE':
                logger.debug(f"Search not found for deletion (already expired on slskd): {url}")
            elif e.status == 409 and 'searches' in url and method == 'POST':
                # 409 = search slots full; caller handles cleanup + retry.
                raise
            else:
                logger.error(f"API request failed: {e}")
            return None

        except Exception as e:
            logger.error(f"Error making API request: {e}")
            return None

    def _convert_to_echosync_track(self, result: TrackResult) -> EchosyncTrack:
        """Convert TrackResult to EchosyncTrack with injected technical stats"""
        safe_filename = _sanitize_peer_filename(result.filename)

        # Parse filename / path using TrackParser for structured metadata
        if not hasattr(self, '_track_parser') or self._track_parser is None:
            self._track_parser = TrackParser()
        parsed = self._track_parser.parse_filename(result.filename)

        parsed_title = (parsed.raw_title or parsed.title) if parsed else None
        parsed_artist = parsed.artist_name if parsed else None
        parsed_album = parsed.album_title if parsed else None
        parsed_year = parsed.release_year if parsed else None
        parsed_track_num = parsed.track_number if parsed else None
        parsed_disc_num = parsed.disc_number if parsed else None

        title = result.title or parsed_title or safe_filename
        artist = result.artist or parsed_artist or "Unknown Artist"
        album = result.album or parsed_album or ""
        track_number = result.track_number or parsed_track_num
        disc_number = parsed_disc_num

        # Create base track
        # result.duration is stored as milliseconds by the JSON parser
        echo_track = self.create_echo_sync_track(
            title=title,
            artist=artist,
            album=album,
            duration_ms=result.duration if result.duration else None,
            year=parsed_year,
            track_number=track_number,
            disc_number=disc_number,
            bitrate=result.bitrate,
            file_format=result.quality,
            file_path=str(self.download_path / safe_filename),
            source="slskd",
            provider_id=result.filename, # Use filename as unique ID for Soulseek
        )

        # Manually inject metadata into identifiers for Matching Engine
        if echo_track:
             echo_track.identifiers['username'] = result.username
             echo_track.identifiers['size'] = result.size
             echo_track.identifiers['free_upload_slots'] = result.free_upload_slots
             echo_track.identifiers['upload_speed'] = result.upload_speed
             echo_track.identifiers['queue_length'] = result.queue_length
             echo_track.identifiers['provider_item_id'] = result.filename
             echo_track.identifiers['local_filename'] = safe_filename
             echo_track.identifiers['bitrate'] = result.bitrate

             # Technical metadata
             if result.bit_depth:
                echo_track.bit_depth = result.bit_depth
                echo_track.identifiers['bit_depth'] = result.bit_depth
             if result.sample_rate:
                echo_track.sample_rate = result.sample_rate
                echo_track.identifiers['sample_rate'] = result.sample_rate
             if result.size:
                echo_track.file_size_bytes = result.size

        return echo_track

    def _process_search_responses(
        self,
        responses_data: List[Dict[str, Any]],
        quality_profile: Optional[Dict[str, Any]] = None,
        cancel_event: Optional[Any] = None,
    ) -> List[TrackResult]:
        """Process search responses into TrackResult objects with provider-side pre-filtering.

        Provider-side pre-filtering is intentionally coarse and cheap. It rejects obviously
        bad candidates (for example fake/transcoded FLACs) before they reach the Download
        Manager and Matching Engine, reducing scoring overhead without moving orchestration
        logic into the provider.
        """
        all_tracks = []

        # Audio file extensions to filter for
        audio_extensions = {'.mp3', '.flac', '.ogg', '.aac', '.wma', '.wav', '.m4a', '.dsf', '.dff'}

        advanced_filters = (quality_profile or {}).get('advanced_filters', {}) if quality_profile else {}
        fake_flac_min_bytes_per_second = int(advanced_filters.get('fake_flac_min_bytes_per_second', 70000))
        fake_flac_min_kbps = int(advanced_filters.get('fake_flac_min_kbps', 500))

        index = 0
        for response_data in responses_data:
            if cancel_event and cancel_event.is_set():
                return []
            username = response_data.get('username', '')
            files = response_data.get('files', [])

            for file_data in files:
                index += 1
                if cancel_event and cancel_event.is_set():
                    return []
                if index % 500 == 0:
                    time.sleep(0.005)  # Yield GIL

                filename = file_data.get('filename', '')
                size = file_data.get('size', 0)

                file_ext = Path(filename).suffix.lower().lstrip('.')

                # Only process audio files
                if f'.{file_ext}' not in audio_extensions:
                    continue

                # Normalize DSD extensions
                if file_ext in ['dsf', 'dff']:
                    quality = 'dsd'
                elif file_ext in ['flac', 'mp3', 'ogg', 'aac', 'wma', 'wav']:
                    quality = file_ext
                else:
                    quality = 'unknown'

                # Safely extract length (seconds) and convert to milliseconds
                length_val = file_data.get('length')
                duration_ms = None
                try:
                    if length_val is not None and length_val != '':
                        # Allow strings or numeric values (e.g. "245", 245.0)
                        duration_seconds = int(float(length_val))
                        duration_ms = duration_seconds * 1000
                except Exception:
                    duration_ms = None

                # Provider-side FLAC authenticity heuristic:
                # Use simple size/duration bitrate math to reject likely fake transcodes.
                if quality == 'flac' and duration_ms and duration_ms > 0 and size and size > 0:
                    duration_seconds = duration_ms / 1000.0
                    approx_bytes_per_second = size / duration_seconds
                    approx_kbps = (size * 8.0) / (duration_seconds * 1000.0)
                    if approx_bytes_per_second < fake_flac_min_bytes_per_second or approx_kbps < fake_flac_min_kbps:
                        logger.debug(
                            "Pre-filter rejected suspicious FLAC (likely transcode): %s "
                            "bytes_per_second=%.0f threshold=%d approx_kbps=%.0f threshold=%d",
                            filename,
                            approx_bytes_per_second,
                            fake_flac_min_bytes_per_second,
                            approx_kbps,
                            fake_flac_min_kbps,
                        )
                        continue

                # Create TrackResult (duration stored in milliseconds)
                track = TrackResult(
                    username=username,
                    filename=filename,
                    size=size,
                    bitrate=file_data.get('bitRate'),
                    duration=duration_ms,
                    quality=quality,
                    free_upload_slots=response_data.get('freeUploadSlots', 0),
                    upload_speed=response_data.get('uploadSpeed', 0),
                    queue_length=response_data.get('queueLength', 0)
                )
                all_tracks.append(track)

        return all_tracks

    async def _async_search(
        self,
        query: str,
        basic_filters: Dict[str, Any] = None,
        timeout: int = 180,
        quality_profile: Optional[Dict[str, Any]] = None,
        includes: Optional[List[str]] = None,
        excludes: Optional[List[str]] = None,
        cancel_event: Optional[Any] = None,
    ) -> List[EchosyncTrack]:
        """
        Atomic Search: Post -> Poll -> Parse -> Delete.
        Applies coarse filtering (basic_filters) before returning.
        
        Concurrency: Limited to 5 concurrent searches (Slskd/Soulseek IP ban protection).
        
        Smart polling:
        - Phase 1 (0-45s): Poll every 5s for quick responsiveness
        - Phase 2 (45s+): Poll every 30s to minimize API calls
        - Exit immediately upon terminal state (completed, timedout, failed, etc.)

        Concurrency: Limited to 3 concurrent searches (Soulseek IP ban protection).
        Default timeout: 180 seconds (3 minutes) to allow extended waiting for slskd responses.
        """
        # Acquire semaphore slot (max 3 concurrent searches — Soulseek IP ban protection)
        async with self._search_semaphore:
            return await self._do_async_search(
                query, basic_filters, timeout, quality_profile,
                includes=includes, excludes=excludes,
                cancel_event=cancel_event,
            )

    async def _check_soulseek_connected(self) -> bool:
        """Return True only if slskd reports it is connected and logged in to the Soulseek network."""
        try:
            app_state = await self._make_request('GET', 'application')
            if not app_state:
                return False
            server_state = (app_state.get('server') or {}).get('state', '')
            connected = 'loggedin' in server_state.lower() or (
                'connected' in server_state.lower() and 'disconnected' not in server_state.lower()
            )
            if not connected:
                logger.warning(f"slskd is not connected to the Soulseek network (state='{server_state}')")
            return connected
        except Exception as e:
            logger.warning(f"Could not determine slskd network state: {e}")
            return False

    async def _cleanup_all_searches(self) -> int:
        """DELETE every active search on slskd to free search slots. Returns number deleted."""
        try:
            searches = await self._make_request('GET', 'searches')
            if not searches or not isinstance(searches, list):
                return 0
            deleted = 0
            for s in searches:
                sid = s.get('id') if isinstance(s, dict) else None
                if not sid:
                    continue
                try:
                    await self._make_request('DELETE', f'searches/{sid}')
                    deleted += 1
                except Exception:
                    pass
            if deleted:
                logger.info(f"Cleaned up {deleted} stale search(es) from slskd")
            return deleted
        except Exception as e:
            logger.warning(f"Failed to clean up stale searches: {e}")
            return 0

    async def _do_async_search(
        self,
        query: str,
        basic_filters: Dict[str, Any] = None,
        timeout: int = 180,
        quality_profile: Optional[Dict[str, Any]] = None,
        includes: Optional[List[str]] = None,
        excludes: Optional[List[str]] = None,
        cancel_event: Optional[Any] = None,
    ) -> List[EchosyncTrack]:
        """Internal async search implementation (called under semaphore lock)."""
        if not self.base_url:
            logger.error("Slskd client not configured")
            return []

        search_id = None
        try:
            if cancel_event and cancel_event.is_set():
                return []

            logger.info(f"Starting atomic search for: '{query}'")

            # Guard: slskd must be connected to the Soulseek network.
            if not await self._check_soulseek_connected():
                logger.warning("Aborting search — slskd is not connected to the Soulseek network")
                return []

            search_data = {
                'searchText': query,
                'timeout': timeout * 1000,
                'filterResponses': True,
                'minimumResponseFileCount': 1,
                'minimumPeerUploadSpeed': 0
            }

            # 1. Post Search (with one 409 recovery attempt)
            async def _post_search():
                return await self._make_request('POST', 'searches', json=search_data)

            try:
                response = await _post_search()
            except HttpError as exc:
                if exc.status == 409:
                    logger.warning("Search slots full (HTTP 409) — clearing stale searches and retrying once")
                    await self._cleanup_all_searches()
                    await asyncio.sleep(1)
                    response = await self._make_request('POST', 'searches', json=search_data)
                else:
                    raise
            if not response:
                return []

            if isinstance(response, dict):
                search_id = response.get('id')
            elif isinstance(response, list) and len(response) > 0:
                search_id = response[0].get('id') if isinstance(response[0], dict) else None

            if not search_id:
                logger.error("No search ID returned")
                return []

            # 2. Poll for search completion and results
            # Smart polling strategy:
            # - Phase 1 (0-45s): Poll every 5s for quick responsiveness
            # - Phase 2 (45s+): Poll every 30s to minimize API calls
            initial_phase_duration = 45.0  # First 45 seconds
            initial_phase_interval = 5.0   # Poll every 5s during initial phase
            main_phase_interval = 30.0     # Poll every 30s after initial phase
            
            all_responses = []
            terminal_state = False
            elapsed_time = 0.0

            logger.info(f"Polling for search completion (5s intervals for 45s, then 30s intervals, timeout: {timeout}s)...")
            
            for poll_count in range(int(timeout / main_phase_interval) + 10):  # Safety upper bound
                if cancel_event and cancel_event.is_set():
                    logger.info("Search aborted by cancellation request")
                    if search_id:
                        try:
                            await self._make_request('DELETE', f'searches/{search_id}')
                            logger.debug(f"Atomic cleanup: Deleted search {search_id}")
                            search_id = None
                        except Exception as e:
                            logger.warning(f"Failed to delete search {search_id} on cancellation: {e}")
                    return []

                # Determine polling interval based on elapsed time
                if elapsed_time < initial_phase_duration:
                    poll_interval = initial_phase_interval
                    phase_name = "initial"
                else:
                    poll_interval = main_phase_interval
                    phase_name = "main"
                
                # Check search state to see if it's complete
                search_state = await self._make_request('GET', f'searches/{search_id}')
                if search_state:
                    state = search_state.get('state', '').lower()
                    logger.debug(f"Poll {poll_count + 1} ({phase_name} phase, {elapsed_time:.0f}s): Search state = '{state}'")
                    
                    # Check for terminal states (handle comma-separated states like "completed, timedout")
                    terminal_states = {'completed', 'complete', 'done', 'finished', 'timedout', 'cancelled', 'errored', 'failed'}
                    # Check if any terminal state appears in the state string
                    if any(ts in state for ts in terminal_states):
                        terminal_state = True
                        logger.info(f"Search reached terminal state: {state} (after {elapsed_time:.0f}s)")

                # Get current responses
                responses_data = await self._make_request('GET', f'searches/{search_id}/responses')
                if responses_data and isinstance(responses_data, list):
                    all_responses = responses_data
                    response_count = len(all_responses)
                    logger.debug(f"Poll {poll_count + 1} ({phase_name} phase, {elapsed_time:.0f}s): Got {response_count} responses")
                    
                    # Exit early if we have a LOT of responses (prevent excessive waiting)
                    if response_count >= 150:
                        logger.info(f"Got {response_count} responses (threshold reached), stopping")
                        break
                else:
                    logger.debug(f"Poll {poll_count + 1} ({phase_name} phase, {elapsed_time:.0f}s): No responses yet")
                
                # Exit immediately on terminal state (don't continue polling)
                if terminal_state:
                    logger.info(f"Exiting polling loop due to terminal state")
                    break
                
                # Exit if overall timeout exceeded
                if elapsed_time >= timeout:
                    logger.warning(f"Polling timeout exceeded ({elapsed_time:.0f}s >= {timeout}s)")
                    break
                
                # Wait before next poll
                await asyncio.sleep(poll_interval)
                elapsed_time += poll_interval

            if not all_responses:
                logger.info(f"Search complete but no responses received")
                
            # 3. Parse Results
            track_results = self._process_search_responses(all_responses, quality_profile=quality_profile, cancel_event=cancel_event)
            logger.info(f"Search yielded {len(track_results)} raw candidates")

            if cancel_event and cancel_event.is_set():
                return []

            # 4. Apply Coarse Filters (Extensions, Min Bitrate, Duration)
            valid_tracks = []
            allowed_extensions = basic_filters.get('allowed_extensions') if basic_filters else None
            min_bitrate = basic_filters.get('min_bitrate', 0) if basic_filters else 0
            for idx, tr in enumerate(track_results):
                if cancel_event and cancel_event.is_set():
                    return []
                if idx > 0 and idx % 500 == 0:
                    time.sleep(0.005)  # Yield GIL

                # Extension Check
                if allowed_extensions:
                    ext = Path(tr.filename).suffix.lower().lstrip('.')
                    if ext not in allowed_extensions:
                        continue

                # Bitrate Check (skip if None, assume okay or let MatchingEngine decide)
                if min_bitrate > 0 and tr.bitrate and tr.bitrate < min_bitrate:
                    continue
                
                # Convert to EchosyncTrack
                echo_track = self._convert_to_echosync_track(tr)
                if echo_track:
                    valid_tracks.append(echo_track)

            logger.info(f"After coarse filtering: {len(valid_tracks)} candidates")

            # Apply client-side includes / excludes text filter (for broad searches).
            # 'includes' terms must ALL appear in the filename (AND semantics).
            # 'excludes' terms cause the result to be dropped if ANY match (OR semantics).
            if includes:
                includes_lower = [t.lower() for t in includes if isinstance(t, str) and t.strip()]
                if includes_lower:
                    valid_tracks = [
                        t for t in valid_tracks
                        if all(
                            inc in (t.filename or "").lower()
                            for inc in includes_lower
                        )
                    ]
                    logger.info(
                        f"After includes filter {includes_lower!r}: {len(valid_tracks)} candidates"
                    )
            if excludes:
                excludes_lower = [t.lower() for t in excludes if isinstance(t, str) and t.strip()]
                if excludes_lower:
                    valid_tracks = [
                        t for t in valid_tracks
                        if not any(
                            exc in (t.filename or "").lower()
                            for exc in excludes_lower
                        )
                    ]
                    logger.info(
                        f"After excludes filter {excludes_lower!r}: {len(valid_tracks)} candidates"
                    )

            return valid_tracks

        except Exception as e:
            logger.error(f"Error in atomic search: {e}")
            return []
        finally:
            # 5. DELETE Search (Atomic cleanup)
            if search_id:
                try:
                    await self._make_request('DELETE', f'searches/{search_id}')
                    logger.debug(f"Atomic cleanup: Deleted search {search_id}")
                except Exception as e:
                    logger.warning(f"Failed to delete search {search_id}: {e}")

    async def _async_download(self, username: str, filename: str, file_size: int = 0) -> Optional[str]:
        if not self.base_url:
            return None

        try:
            logger.info(f"Initiating download: '{filename}' from user '{username}' (size: {file_size})")
            
            # Slskd API format: POST /transfers/downloads/{username}
            # Body: Array of file objects with filename and size
            download_data = [
                {
                    "filename": filename,  # Remote file path on peer's system
                    "size": file_size
                }
            ]

            # Username goes in the URL path, not the payload
            endpoint = f'transfers/downloads/{username}'
            response = await self._make_request('POST', endpoint, json=download_data)

            if response is not None:
                # Slskd returns the download information
                # The download "ID" for tracking is typically the filename
                # But we need to return something that can be used to check status later
                logger.info(f"Download initiated successfully for {filename}")
                # Return the username and filename as a compound ID
                # Format: username|filename
                return f"{username}|{filename}"

            logger.error(f"Download request failed for {filename} from {username}")
            return None

        except Exception as e:
            logger.error(f"Error starting download: {e}")
            return None

    async def _async_get_download_status(self, download_id: str) -> Optional[Dict[str, Any]]:
        """
        Get status for a specific download.
        download_id format: \"username|filename\"
        """
        if not self.base_url:
            return None

        try:
            # Parse compound ID
            if '|' not in download_id:
                # Legacy download entry from before compound ID format was implemented
                # Skip silently - these will eventually be cleaned up by periodic cleanup task
                logger.debug(f"Skipping legacy download_id without username prefix: {download_id[:80]}")
                return None
            
            username, filename = download_id.split('|', 1)
            safe_filename = _sanitize_peer_filename(filename)
            
            # Query the transfers endpoint to find this download
            # GET /api/v0/transfers/downloads returns all downloads grouped by username
            all_downloads = await self._make_request('GET', 'transfers/downloads')
            
            if all_downloads and isinstance(all_downloads, dict):
                # Response format: {\"username\": {\"directories\": [{\"directory\": \"...\", \"files\": [...]}]}}
                user_data = all_downloads.get(username, {})
                if isinstance(user_data, dict):
                    directories = user_data.get('directories', [])
                    for directory in directories:
                        if isinstance(directory, dict):
                            files = directory.get('files', [])
                            for file_data in files:
                                if isinstance(file_data, dict):
                                    file_filename = file_data.get('filename', '')
                                    # Match by filename
                                    if file_filename == filename:
                                        # Map slskd status to our status
                                        state = file_data.get('state', '').lower()
                                        status = "unknown"
                                        if state in ['completed', 'succeeded', 'finished']:
                                            status = "complete"
                                        elif state in ['queued', 'initializing']:
                                            status = "queued"
                                        elif state in ['downloading', 'transferring']:
                                            status = "downloading"
                                        elif state in ['failed', 'error', 'aborted', 'cancelled']:
                                            status = "failed"
                                        
                                        return {
                                            'id': download_id,
                                            'status': status,
                                            'filename': safe_filename,
                                            'remote_filename': filename,
                                            'local_path': str(self.download_path / safe_filename),
                                            'username': username,
                                            'progress': file_data.get('percentComplete', 0),
                                            'size': file_data.get('size', 0)
                                        }
            
            # Not found - might be completed and removed
            logger.debug(f"Download not found in active transfers: {download_id}")
            return None

        except Exception as e:
            logger.error(f"Error getting download status: {e}")
            return None

    # Public Sync Wrappers for Provider Interface

    def search(
        self,
        query: str,
        type: Optional[str] = "track",
        cancel_event: Optional[Any] = None,
        **kwargs,
    ) -> List[EchosyncTrack]:
        """Synchronous wrapper for atomic search"""
        if cancel_event is None:
            cancel_event = kwargs.get("cancel_event")
        limit = kwargs.get("limit", 10)
        basic_filters = kwargs.get("basic_filters")
        quality_profile = kwargs.get("quality_profile")
        includes = kwargs.get("includes")
        excludes = kwargs.get("excludes")
        try:
            loop = asyncio.new_event_loop()
            try:
                results = loop.run_until_complete(
                    self._async_search(
                        query, basic_filters,
                        quality_profile=quality_profile,
                        includes=includes,
                        excludes=excludes,
                        cancel_event=cancel_event,
                    )
                )
                return results[:limit]
            finally:
                loop.close()
        except Exception as e:
            logger.error(f"Error in synchronous search: {e}")
            return []

    def download(self, username: str, filename: str, file_size: int = 0) -> Optional[str]:
        """Synchronous wrapper for download"""
        try:
            loop = asyncio.new_event_loop()
            try:
                return loop.run_until_complete(self._async_download(username, filename, file_size))
            finally:
                loop.close()
        except Exception as e:
            logger.error(f"Error in synchronous download: {e}")
            return None

    def get_download_status(self, download_id: str) -> Optional[Dict[str, Any]]:
        """Synchronous wrapper for status"""
        try:
            loop = asyncio.new_event_loop()
            try:
                return loop.run_until_complete(self._async_get_download_status(download_id))
            finally:
                loop.close()
        except Exception as e:
            logger.error(f"Error in synchronous get_download_status: {e}")
            return None

    # Required Abstract Methods Stubs

    def search_tracks(self, query: str) -> List[EchosyncTrack]:
        return self.search(query)

    def get_track_by_id(self, item_id: str) -> Optional[EchosyncTrack]:
        return None

    def get_artist_details(self, artist_id: str) -> Dict[str, Any]:
        return {}

    def get_logo_url(self) -> str:
        return "/assets/slskd-logo.png"

    def authenticate(self, **kwargs) -> bool:
        # Simple health check
        try:
            loop = asyncio.new_event_loop()
            try:
                res = loop.run_until_complete(self._make_request('GET', 'session'))
                return res is not None
            finally:
                loop.close()
        except Exception as e:
            logger.debug(f"Slskd authenticate check failed: {e}")
            return False

    def is_configured(self) -> bool:
        return bool(self.base_url)

    # Legacy stubs (not used but required by abstract base class if not careful)
    def get_track(self, track_id: str) -> Optional[EchosyncTrack]: return None
    def get_album(self, album_id: str) -> Optional[Dict[str, Any]]: return None
    def get_artist(self, artist_id: str) -> Optional[Dict[str, Any]]: return None
    def get_user_playlists(self, user_id: Optional[str] = None) -> List[Dict[str, Any]]: return []
    def get_playlist_tracks(self, playlist_id: str) -> List[EchosyncTrack]: return []


# Register the provider
PluginRegistry.register(SlskdProvider)
