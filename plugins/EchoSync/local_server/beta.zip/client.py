import urllib.parse
from collections.abc import Generator
from datetime import datetime
from pathlib import Path
from typing import Any

from core.db.echo_sync_track import EchosyncTrack
from core.nexus_framework.plugin_SDK import (
    MetadataRichness,
    PlaylistSupport,
    PluginBase,
    ProviderCapabilities,
    SearchCapabilities,
)

SUPPORTED_AUDIO_EXTENSIONS = {
    ".mp3",
    ".flac",
    ".ogg",
    ".m4a",
    ".aac",
    ".alac",
    ".ape",
    ".wav",
    ".dsd",
    ".dsf",
    ".dff",
}


def inspect_audio_file(path: Path):
    import echosync_core

    meta = echosync_core.extract_metadata(str(path))

    class AudioResult:
        def __init__(self, m):
            self.title = m.get("title") or path.stem
            self.artist = m.get("artist_name") or m.get("artist") or "Unknown Artist"
            self.artist_source = "lofty"
            self.album_artist = m.get("album_artist")
            self.album = m.get("album_title") or m.get("album")
            self.duration_ms = m.get("duration_ms")
            self.isrc = m.get("isrc")
            self.musicbrainz_id = m.get("mbid")
            self.release_id = None
            self.acoustid_id = None
            self.year = m.get("year")
            self.track_number = m.get("track_number") or m.get("track_no")
            self.disc_number = m.get("disc_number") or m.get("disc_no")
            self.bitrate_kbps = m.get("bitrate")
            self.sample_rate_hz = m.get("sample_rate")
            self.bit_depth = m.get("bit_depth")
            self.file_format = m.get("codec") or path.suffix.lstrip(".")
            self.file_size_bytes = m.get("file_size_bytes")

    return AudioResult(meta)


from core.plugins.sdk import compute_plugin_crc32
from core.task_manager.supervisor import supervisor
from core.tiered_logger import get_logger

PLUGIN_NAMESPACE = "EchoSync.local_server"
PLUGIN_CRC32 = compute_plugin_crc32(PLUGIN_NAMESPACE)
logger = get_logger("local_server_provider", plugin_id=PLUGIN_CRC32)


class LocalServerProvider(PluginBase):
    name = "EchoSync.Local Server"
    category = "provider"
    supports_downloads = False
    enabled = True

    capabilities = ProviderCapabilities(
        name="EchoSync.Local Server",
        supports_playlists=PlaylistSupport.NONE,
        search=SearchCapabilities(tracks=False),
        metadata=MetadataRichness.LOW,
        supports_library_scan=True,
        supports_streaming=True,
    )

    def get_all_tracks(self) -> Generator[EchosyncTrack, None, None]:
        """
        Yields EchosyncTrack objects by crawling the local library.
        Extracts duration, isrc, title, and artist via local tags.
        """
        library_dir_str = self.sdk.config.get("library_dir")
        if not library_dir_str:
            from core.settings import config_manager

            library_dir_str = config_manager.get("storage.library_dir") or config_manager.get("library_dir")

        if not library_dir_str:
            logger.warning("Library directory not configured globally or locally.")
            return

        library_dir = Path(library_dir_str)
        if not library_dir.exists():
            logger.warning(f"Library directory does not exist: {library_dir}")
            return

        def process_file(path: Path) -> EchosyncTrack | None:
            try:
                result = inspect_audio_file(path)

                if result.artist_source != "tpe1":
                    logger.debug(
                        "Singer-First fallback: '%s' artist='%s' (source=%s)",
                        path.name,
                        result.artist,
                        result.artist_source,
                    )

                return self.create_echo_sync_track(
                    title=result.title,
                    artist=result.artist,
                    album_artist=result.album_artist,
                    album=result.album,
                    duration_ms=result.duration_ms,
                    isrc=result.isrc,
                    musicbrainz_id=result.musicbrainz_id,
                    mb_release_id=result.release_id,
                    acoustid_id=result.acoustid_id,
                    year=result.year,
                    track_number=result.track_number,
                    disc_number=result.disc_number,
                    bitrate=result.bitrate_kbps,
                    sample_rate=result.sample_rate_hz,
                    bit_depth=result.bit_depth,
                    file_format=result.file_format,
                    file_size_bytes=result.file_size_bytes,
                    added_at=datetime.fromtimestamp(path.stat().st_ctime) if path.exists() else None,
                    file_path=str(path),
                    source=self.name,
                    # No provider_id to prevent writing an external identifier
                )
            except Exception as e:
                logger.warning("Failed to process '%s', falling back to filename: %s", path.name, e)
                try:
                    file_stat = path.stat()
                    file_size_bytes = file_stat.st_size
                    added_at = datetime.fromtimestamp(file_stat.st_ctime)
                except Exception:
                    file_size_bytes = None
                    added_at = None
                return self.create_echo_sync_track(
                    title=path.stem,
                    artist="Various Artists",
                    file_path=str(path),
                    source=self.name,
                    file_size_bytes=file_size_bytes,
                    added_at=added_at,
                )

        import concurrent.futures

        def _iter_audio_files(root: Path) -> Generator[Path, None, None]:
            """Walk the directory tree, yielding audio files while tolerating
            per-directory PermissionError/OSError."""
            try:
                for entry in root.iterdir():
                    if entry.name == ".zfs":
                        logger.debug(f"Skipping ZFS directory: {entry}")
                        continue
                    try:
                        if entry.is_symlink():
                            try:
                                resolved = entry.resolve(strict=True)
                                if not resolved.exists():
                                    continue
                            except (OSError, RuntimeError):
                                continue

                        if entry.is_dir():
                            yield from _iter_audio_files(entry)
                        elif entry.is_file() and entry.suffix.lower() in SUPPORTED_AUDIO_EXTENSIONS:
                            yield entry
                    except PermissionError:
                        logger.warning(f"Permission denied, skipping: {entry}")
                    except OSError as e:
                        logger.warning(f"OS error scanning {entry}: {e}")
            except PermissionError:
                logger.warning(f"Permission denied, skipping directory: {root}")
            except OSError as e:
                logger.warning(f"OS error scanning directory {root}: {e}")

        # Collect all valid files first using the safe generator
        files = list(_iter_audio_files(library_dir))
        logger.info(f"Local crawler discovered {len(files)} audio files under {library_dir}")

        # Process sequentially to avoid unmanaged ThreadPoolExecutor saturation and GIL contention
        for path in files:
            if supervisor.is_current_task_cancelled():
                logger.info("Local crawler cancelled during extraction.")
                break
            try:
                track = process_file(path)
                if track:
                    yield track
            except Exception as e:
                logger.warning(f"Failed to process {path}: {e}")

    def get_stream_url(self, track_id_or_path: str) -> str:
        """
        Returns a formatted internal API route string for streaming.
        All characters including '/' are percent-encoded so the value is
        unambiguous as a query parameter and safe through reverse proxies.
        """
        encoded_path = urllib.parse.quote(track_id_or_path, safe="")
        return f"/api/local_server/stream?path={encoded_path}"

    def authenticate(self, **kwargs) -> bool:
        return True

    def search(
        self,
        query: str,
        type: str = "track",
        limit: int = 10,
        quality_profile: dict[str, Any] | None = None,
    ) -> list[EchosyncTrack]:
        return []

    def get_track(self, track_id: str) -> EchosyncTrack | None:
        return None

    def get_album(self, album_id: str) -> dict[str, Any] | None:
        return None

    def get_artist(self, artist_id: str) -> dict[str, Any] | None:
        return None

    def get_user_playlists(self, user_id: str | None = None) -> list[dict[str, Any]]:
        return []

    def get_playlist_tracks(self, playlist_id: str) -> list[EchosyncTrack]:
        return []

    def is_configured(self) -> bool:
        return True

    def get_logo_url(self) -> str:
        return ""
