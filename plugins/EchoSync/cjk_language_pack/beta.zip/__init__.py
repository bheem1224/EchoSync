"""
CJK Language Pack Plugin — v2.4.0
===================================
Solves the "Anime/Drama OST Problem" via a three-stage Expand → Score → Restore
pipeline that works entirely offline (no cloud ASR, no paid APIs).

Expand  (pre_provider_search)
    Detects CJK characters in a search query and generates a targeted set of
    search strings:
      • Original CJK query
      • Simplified / Traditional Chinese script variants   (opencc)
      • Tone-stripped Pinyin / Hepburn Romaji / Revised Romanization  (pypinyin / pykakasi / hangul_romanize)
      • Anime or drama series names discovered from VGMdb.info
        → e.g. "YOASOBI Idol" becomes ["YOASOBI Idol", "晴天", "yoasobi idol", "Oshi no Ko Idol"]

Score   (pre_normalize_text)
    Intercepts every string that flows through the WeightedMatchingEngine:
      • CJK strings are flattened to pure-Latin phonetics so edit-distance
        scoring works across scripts ("アイドル" → "aidoru" vs "idol").
      • Strings matching a known anime / drama series name (populated by the
        VGMdb lookup above) are remapped to the canonical artist name so
        "Oshi no Ko" scores as "yoasobi" — a near-perfect artist match.

Restore (post_metadata_enrichment)
    After the MetadataEnhancerService pipeline completes:
      • Writes TrackAlias rows for Simplified, Traditional, and Latin
        (Pinyin / Romaji) forms of the track title.
      • Writes ArtistAlias rows for the same variants of the artist name.
    Both use the SQLAlchemy ORM session already attached to the track object —
    no new session or raw database connection is ever created (Zero-Trust).

Zero-Trust sandbox compliance
    • No direct file I/O.
    • No os / sys / subprocess / importlib imports at module level.
    • Database access exclusively via object_session() on the passed ORM object.
    • VGMdb HTTP calls use only stdlib urllib with a hard timeout and hardcoded
      base URL — user input is URL-encoded and never used to construct the host.
"""

from __future__ import annotations

import re
from typing import Any, List

from core.hook_manager import hook_manager
from core.tiered_logger import get_logger

from .noise_filter import get_noise_filter
from .transliterator import get_transliterator
from .vgmdb_proxy import get_proxy

logger = get_logger("plugin.cjk")

# Fast CJK tripwire — same ranges covered by transliterator._CJK_RE
_CJK_RE = re.compile(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\uac00-\ud7af\u1100-\u11ff]")

# All CJK paired brackets: capture content between each pair.
# Groups: 《》 「」 『』 〈〉 【】 （） 《》
_CJK_BRACKET_RE = re.compile(
    r"\u300a([^\u300b]*)\u300b"  # 《》 double-angle / title mark
    r"|\u300c([^\u300d]*)\u300d"  # 「」 corner brackets
    r"|\u300e([^\u300f]*)\u300f"  # 『』 white corner brackets
    r"|\u3008([^\u3009]*)\u3009"  # 〈〉 angle brackets
    r"|\u3010([^\u3011]*)\u3011"  # 【】 lenticular brackets
    r"|\uff08([^\uff09]*)\uff09"  # （） full-width parentheses
)

# ASCII bracket pairs: capture content from [bracket] or (parens) labels such
# as "[Jiang Cheng] Hen Bie" or "Hold On (Wang Zhe Rong Yao version)".
# Used to extract romanised drama/series context from purely-Latin titles.
_ASCII_BRACKET_RE = re.compile(r"\[([^\]]+)\]|\(([^)]+)\)")

# OST keyword anchor — used in the fallback drama-extraction path.
# When a title lacks 《》 guillemets, Echosync looks for these keywords inside
# standard bracket pairs and treats the text BEFORE the keyword as the drama
# name.  Examples:
#   （苍兰诀 吟唱版）          → drama = '苍兰诀'  (keyword: 吟唱版)
#   (点燃我温暖你 插曲)         → drama = '点燃我温暖你' (keyword: 插曲)
#   （莲花楼 片尾曲）           → drama = '莲花楼'
_OST_KEYWORD_RE = re.compile(
    r"(?:"
    r"主题曲|主題曲"
    r"|插曲"
    r"|片头曲|片頭曲"
    r"|片尾曲"
    r"|推广曲"
    r"|人物曲"
    r"|同行曲"
    r"|时光曲|時光曲"
    r"|吟唱版"  # variant lyric / chant version marker
    r"|原声版"  # original-sound version marker
    r"|剧情版"  # drama-cut version marker
    r"|原声带|原聲帶"
    r")",
    re.UNICODE,
)


def _has_cjk(text: str) -> bool:
    return isinstance(text, str) and bool(_CJK_RE.search(text))


# kept for callers that still use the old name
def contains_cjk(text: str) -> bool:
    return _has_cjk(text)


def _safe_getattr(obj: Any, attr: str, default: Any = None) -> Any:
    """AST-compliant alternative to getattr()."""
    if hasattr(obj, attr):
        try:
            return obj.__getattribute__(attr)
        except AttributeError:
            return default
    return default


# ── Hook 0: register_metadata_requirements ────────────────────────────────────


def _on_register_metadata_requirements(requirements: list[str]) -> list[str]:
    """Register the metadata_status key that this plugin writes to metadata_status upon enrichment.

    ``cjk_restored`` is set to True on CJK tracks and False on non-CJK tracks so the
    retroactive enhancer knows a track has already been processed and won't requeue it.
    """
    extra = ["cjk_restored"]
    existing = set(requirements)
    return requirements + [f for f in extra if f not in existing]


# ── Hook 1: pre_provider_search (Expand) ──────────────────────────────────────


def _expand_query(query: str, artist_name: str = "", title: str = "") -> list[str]:
    """
    Return a priority-ordered list of search strings for a CJK-containing query.

    Sniper priority matrix (highest → lowest hit-rate on slskd):
        1. ``<VGMdb series name> <CJK title>``       — files tagged by show name
        2. ``<original combined query>``              — pass-through / exact tags
        3. ``<romaji/pinyin artist> <romaji/pinyin title>``  — Latin-phonetic files
        4. Simplified Chinese variant
        5. Traditional Chinese variant
    """
    tr = get_transliterator()

    # Prefer explicit per-field kwargs over parsing the combined query string.
    if artist_name and title:
        cjk_artist = artist_name
        cjk_title = title
        latin_artist = tr.flatten_to_romaji(artist_name)
        latin_title = tr.flatten_to_romaji(title)
    elif " - " in query:
        raw_artist, raw_title = query.split(" - ", 1)
        cjk_artist = raw_artist.strip()
        cjk_title = raw_title.strip()
        latin_artist = tr.flatten_to_romaji(cjk_artist)
        latin_title = tr.flatten_to_romaji(cjk_title)
    else:
        cjk_artist = ""
        cjk_title = query
        latin_artist = ""
        latin_title = tr.flatten_to_romaji(query)

    # ------------------------------------------------------------------
    # 1. VGMdb series look-up — use Latin forms for better API match quality
    # ------------------------------------------------------------------
    proxy = get_proxy()
    series_hits = proxy.lookup_series(
        (latin_artist or cjk_artist).strip(),
        (latin_title or cjk_title).strip(),
    )

    result: list[str] = []
    seen: set[str] = set()

    def _add(candidate: str) -> None:
        s = candidate.strip()
        if s and s not in seen:
            seen.add(s)
            result.append(s)

    # Priority 1 (a/b/c): VGMdb series queries — highest hit-rate on slskd P2P.
    # Covers files tagged by show/game name rather than by artist name.
    for hit in series_hits:
        native = hit.get("native", "")
        english = hit.get("english", "")
        # (a) "<native series> OST" — e.g. "葬送のフリーレン OST"
        if native:
            _add(f"{native} OST")
        # (b) "<english series> Soundtrack" — e.g. "Frieren Soundtrack"
        if english:
            _add(f"{english} Soundtrack")
        # (c) "<english series> <original CJK title>" — e.g. "Frieren Frieren"
        #     (catches releases labelled by series name with the track title)
        if english and cjk_title:
            _add(f"{english} {cjk_title}")

    # Priority 2: original combined query (pass-through / exact tags)
    _add(query)

    # Priority 3: fully Latin — covers files tagged in Romaji / Pinyin
    if cjk_artist:
        _add(f"{latin_artist} {latin_title}".strip())
    else:
        _add(latin_title)

    # Priority 4 & 5: Simplified / Traditional Chinese script variants
    # (only emitted for Chinese; detect_language guards are inside script_variants)
    from .transliterator import detect_language

    lang = detect_language(cjk_title or query)
    if lang == "zh":
        if cjk_artist:
            _add(f"{tr.to_simplified(cjk_artist)} {tr.to_simplified(cjk_title)}".strip())
            _add(f"{tr.to_traditional(cjk_artist)} {tr.to_traditional(cjk_title)}".strip())
        else:
            _add(tr.to_simplified(cjk_title))
            _add(tr.to_traditional(cjk_title))

    return result


def _on_pre_provider_search(
    query: Any,
    strategy_name: str = "",
    artist_name: str = "",
    title: str = "",
    **kwargs: Any,
) -> Any:
    """
    Expand a CJK query into a prioritised list of search strings.

    * Returns ``[]`` immediately for the ``album+title`` strategy — CJK tracks
      on slskd are almost never tagged by CJK album name, so this strategy
      produces only noise while burning an extra HTTP round-trip.
    * Passes ``artist_name`` / ``title`` down to ``_expand_query`` so the
      sniper priority matrix can use precise per-field metadata rather than
      parsing the combined query string.
    """
    # ── Album+title pruning for CJK queries ──────────────────────────────
    _probe = query if isinstance(query, str) else " ".join(str(q) for q in (query or []))
    if strategy_name == "album+title" and _has_cjk(_probe):
        logger.debug(
            "Pruning album+title strategy for CJK query %r (slskd files are not tagged by CJK album name).",
            query,
        )
        return []

    if isinstance(query, list):
        out: list[str] = []
        seen: set[str] = set()
        for q in query:
            for v in _expand_query(q, artist_name=artist_name, title=title) if _has_cjk(q) else [q]:
                if v not in seen:
                    seen.add(v)
                    out.append(v)
        return out

    if not _has_cjk(query):
        return query

    logger.info("CJK detected in search query %r — expanding sniper variants", query)
    expanded = _expand_query(query, artist_name=artist_name, title=title)
    logger.debug("Expanded to %d variants: %s", len(expanded), expanded)
    return expanded


# ── Hook 2: pre_normalize_text (Score / Reduce) ────────────────────────────────


def _is_ingestion_or_sync() -> bool:
    """Return True if the current call stack is within database_update, bulk_import, or PlexClient syncing."""
    try:
        import traceback

        stack = traceback.extract_stack()
        for frame in reversed(stack):
            filename = frame.filename.replace("\\", "/")
            if "bulk_operations" in filename or "database_update_worker" in filename or "plex/client" in filename:
                return True
    except Exception:
        pass
    return False


def _on_pre_normalize_text(text: str) -> str:
    """
    Pre-process *text* for the WeightedMatchingEngine's comparison pipeline.

    **Fast gatekeeper** (first line):
        If *text* contains no CJK or full-width characters, return it unchanged
        immediately.  This guarantees zero overhead for English / Latin tracks
        — the core normalizer handles those natively.

    When CJK is detected, three steps run in strict order:

    1. **Series → artist remapping**
           If *text* matches a VGMdb-resolved series name, return the
           canonical artist name (e.g. "Oshi no Ko" → "yoasobi").

    2. **CJK noise stripping** (NoiseFilter.strip_cjk_noise)
           Remove OST markers, theme-song labels, full-width brackets, and
           full-width Latin tokens (ｆｅａｔ, ＯＳＴ) that are exclusive to
           CJK text.  Standard English noise (feat., OST, …) is left in place
           so the core normalizer can strip it during its own downstream pass.

    3. **Script normalization** (Traditional → Simplified)
           Unify Traditional and Simplified Chinese to a common form so that
           "長風謠" and "长风谣" produce identical comparison strings.  The
           result is still native Hanzi — NO Latin transliteration is performed
           here.  Pinyin / Romaji / Romanization are generated exclusively by
           the ``search_expansion`` and ``pre_provider_search`` hooks, which
           serve candidate *retrieval* — not scoring.
    """
    if not isinstance(text, str):
        return text

    if _is_ingestion_or_sync():
        return text

    # ── Step 1: series → canonical artist remap ───────────────────────────
    # Applies to all strings (CJK and Latin) because a VGMdb series name may
    # itself be in Romaji (e.g. "Shan He Ling" → canonical artist).
    proxy = get_proxy()
    canonical_artist = proxy.resolve_artist_for_series(text)
    if canonical_artist:
        logger.debug("Series alias remap: %r → %r", text, canonical_artist)
        return canonical_artist

    # ── Step 2: strip CJK-exclusive structural noise ──────────────────────
    # strip_cjk_noise is CJK-pattern-specific; pure-Latin strings pass through
    # unchanged with negligible overhead (all patterns fail to match early).
    cleaned = get_noise_filter().strip_cjk_noise(text)
    if cleaned != text:
        logger.debug("CJK noise strip: %r → %r", text, cleaned)

    # ── Step 3: script normalization (Traditional → Simplified, CJK only) ─
    if _has_cjk(cleaned):
        result = get_transliterator().to_simplified(cleaned)
        if result != cleaned:
            logger.debug("CJK T→S normalize: %r → %r", cleaned, result)
        return result

    return cleaned


# ── Hook 3: post_metadata_enrichment (Restore) ────────────────────────────────


def _build_track_alias_entries(track_obj: Any) -> list[dict]:
    """
    Return a list of alias dicts for every script variant of the track title.

    Priority order:
      1. Explicit ``cjk_aliases`` list in ``track_obj.metadata_status``
         (set by a provider that fetched MusicBrainz aliases directly).
      2. Synthesised from the title using CJKTransliterator:
         • Simplified Chinese  (locale="zh", script="Hans")
         • Traditional Chinese (locale="zh", script="Hant")
         • Latin phonetics     (locale="en", script="Latn") ← primary
    """
    status = track_obj.metadata_status or {}
    declared = status.get("cjk_aliases")
    if declared and isinstance(declared, list):
        return declared

    title = _safe_getattr(track_obj, "title", "") or ""
    if not _has_cjk(title):
        return []

    tr = get_transliterator()
    entries: list[dict] = []
    seen: set[str] = set()

    def _add(name: str, locale: str, script: str, primary: bool) -> None:
        if name and name not in seen and name != title:
            seen.add(name)
            entries.append(
                {
                    "name": name,
                    "locale": locale,
                    "script": script,
                    "is_primary_for_locale": primary,
                }
            )

    _add(tr.to_simplified(title), "zh", "Hans", False)
    _add(tr.to_traditional(title), "zh", "Hant", False)
    _add(tr.flatten_to_romaji(title), "en", "Latn", True)  # Pinyin/Romaji
    return entries


def _build_artist_alias_entries(artist_name: str) -> list[dict]:
    """Return alias dicts for every script variant of *artist_name*."""
    if not _has_cjk(artist_name):
        return []

    tr = get_transliterator()
    entries: list[dict] = []
    seen: set[str] = set()

    def _add(name: str, locale: str, script: str, primary: bool) -> None:
        if name and name not in seen and name != artist_name:
            seen.add(name)
            entries.append(
                {
                    "name": name,
                    "locale": locale,
                    "script": script,
                    "is_primary_for_locale": primary,
                }
            )

    _add(tr.to_simplified(artist_name), "zh", "Hans", False)
    _add(tr.to_traditional(artist_name), "zh", "Hant", False)
    _add(tr.flatten_to_romaji(artist_name), "en", "Latn", True)
    return entries


def _persist_track_aliases(track_obj: Any, alias_entries: list[dict]) -> None:
    """
    Append TrackAlias rows via the ORM session that already owns *track_obj*.

    Routes through the governed sdk.aliases broker so that plugin provenance,
    deduplication, and validation are strictly enforced.
    """
    if not alias_entries:
        return
    try:
        from sqlalchemy.orm import object_session

        from core.nexus_framework.plugin_SDK import sdk

        session = object_session(track_obj)
        if session is None:
            logger.warning(
                "No ORM session on track_obj (ID %s) — TrackAlias write skipped.",
                _safe_getattr(track_obj, "id", "?"),
            )
            return

        proposals = [
            {
                "entity_type": "track",
                "entity_id": track_obj.id,
                "name": entry.get("name"),
                "locale": entry.get("locale"),
                "script": entry.get("script"),
                "alias_type": "cjk_variant",
            }
            for entry in alias_entries
            if entry.get("name")
        ]
        if proposals:
            sdk.aliases.upsert(
                entity_type="track",
                entity_id=track_obj.id,
                proposals=proposals,
                sync_id=getattr(track_obj, "sync_id", None),
                session=session,
            )
            sdk.attributes.set("track", track_obj.id, "cjk_restored", True, session=session)
            logger.debug(
                "Queued %d TrackAlias row(s) for Track ID %s via sdk.aliases.",
                len(proposals),
                track_obj.id,
            )
    except Exception as exc:
        logger.warning(
            "TrackAlias persistence failed for Track ID %s: %s",
            _safe_getattr(track_obj, "id", "?"),
            exc,
        )


def _persist_artist_aliases(track_obj: Any, alias_entries: list[dict]) -> None:
    """
    Append ArtistAlias rows for the artist attached to *track_obj*.

    Routes through the governed sdk.aliases broker so that plugin provenance,
    deduplication, and validation are strictly enforced.
    """
    if not alias_entries:
        return
    try:
        from sqlalchemy.orm import object_session

        from core.nexus_framework.plugin_SDK import sdk

        session = object_session(track_obj)
        if session is None:
            return

        artist_obj = _safe_getattr(track_obj, "artist", None)
        if artist_obj is None:
            return

        proposals = [
            {
                "entity_type": "artist",
                "entity_id": artist_obj.id,
                "name": entry.get("name"),
                "locale": entry.get("locale"),
                "script": entry.get("script"),
                "alias_type": "cjk_variant",
            }
            for entry in alias_entries
            if entry.get("name")
        ]
        if proposals:
            sdk.aliases.upsert(
                entity_type="artist",
                entity_id=artist_obj.id,
                proposals=proposals,
                session=session,
            )
            logger.debug(
                "Queued %d ArtistAlias row(s) for Artist ID %s via sdk.aliases.",
                len(proposals),
                artist_obj.id,
            )
    except Exception as exc:
        logger.warning(
            "ArtistAlias persistence failed for Track ID %s: %s",
            _safe_getattr(track_obj, "id", "?"),
            exc,
        )


# ── Hook 4: pre_normalize_title (drama/series context extraction) ─────────────


def _on_pre_normalize_title(raw_title: str, **kwargs: Any) -> str:
    """
    Filter registered on the ``pre_normalize_title`` hook.

    Fires BEFORE ``normalize_text`` strips CJK brackets from a title string.
    Extracts the first bracketed CJK sequence (typically the drama or anime
    series name, e.g. ``태양의 후예`` from ``晴天 - MBC 드라마《太陽의 後裔》OST``)
    and stores it in ``plugin_context['cjk_drama']`` for later use by the
    ``scoring_modifier`` hook.

    The title string is returned **unchanged** — this hook is purely additive.
    """
    plugin_context = kwargs.get("plugin_context")
    if plugin_context is None:
        return raw_title
    if not isinstance(raw_title, str):
        return raw_title

    if _is_ingestion_or_sync():
        return raw_title

    # ── CJK bracket extraction (《》 【】 etc.) ─────────────────────────────
    # Only attempted when native CJK characters are present.
    if _has_cjk(raw_title):
        # Priority 1: look for a 《series name》 guillemet pair — the most
        # unambiguous marker. Use the first captured group that isn't empty.
        match = _CJK_BRACKET_RE.search(raw_title)
        guillemet_content = None
        if match:
            # Only treat 《》 content as drama context; skip other bracket types
            # here because they are handled by the fallback path below.
            guillemet_content = match.group(1)  # group 1 = 《》 content

        if guillemet_content and guillemet_content.strip():
            plugin_context["cjk_drama"] = guillemet_content.strip()
            return raw_title

        # Priority 2 (fallback): no 《》 guillemets — scan （）or () brackets for
        # an OST-role keyword (插曲, 主题曲, 吟唱版, …).  When found, extract the
        # text that *precedes* the keyword inside the same bracket as the drama
        # name. Example: （苍兰诀 吟唱版） → drama = '苍兰诀'.
        # Also handles inverted order where the media-type word comes first and
        # the keyword is the whole bracket content, e.g. '电视剧《苍兰诀》片头曲'
        # is already covered by priority 1, but '（苍兰诀 插曲附词版）' is not.
        for bracket_re, open_ch, close_ch in (
            (re.compile(r"（([^）]*)）"), "（", "）"),  # full-width parens
            (re.compile(r"\(([^)]*)\)"), "(", ")"),  # ASCII parens
        ):
            for bracket_match in bracket_re.finditer(raw_title):
                inner = bracket_match.group(1)
                kw_match = _OST_KEYWORD_RE.search(inner)
                if kw_match:
                    # Text before the keyword is the drama/series name.
                    candidate_drama = inner[: kw_match.start()].strip()
                    # Strip common separators left after splitting.
                    candidate_drama = re.sub(r"^[\s\-–—·,，、]+|[\s\-–—·,，、]+$", "", candidate_drama)
                    if candidate_drama and _has_cjk(candidate_drama):
                        plugin_context["cjk_drama"] = candidate_drama
                        return raw_title

        # Priority 3: any other CJK bracket type (【】 「」 etc.) — original behaviour.
        match = _CJK_BRACKET_RE.search(raw_title)
        if match:
            drama = next((g for g in match.groups() if g is not None), None)
            if drama and drama.strip():
                plugin_context["cjk_drama"] = drama.strip()
                return raw_title

    # ── ASCII bracket extraction ([bracket] / (parens)) ────────────────────
    # Fires for titles such as "[Jiang Cheng] Hen Bie" or "(苍兰诀 OST)" so the
    # scoring_modifier hook receives drama context even when the Spotify title
    # carries no native CJK guillemets.
    #
    # Guard: only treat bracket content as drama context when it contains at
    # least one CJK character OR an explicit OST keyword.  This prevents
    # pure-English descriptors like "(Are Made of This)" or "(Remastered 2013)"
    # from being misclassified as drama names.
    match = _ASCII_BRACKET_RE.search(raw_title)
    if match:
        drama = next((g for g in match.groups() if g is not None), None)
        if drama and drama.strip() and (_has_cjk(drama) or _OST_KEYWORD_RE.search(drama)):
            plugin_context["cjk_drama"] = drama.strip()

    return raw_title


# ── Hook 5: scoring_modifier (drama-context score boost) ─────────────────────


def _on_scoring_modifier(modifier: Any, **kwargs: Any) -> Any:
    """
    Filter registered on the ``scoring_modifier`` hook.

    Compares the ``cjk_drama`` values stored in each track's ``plugin_context``
    by the ``pre_normalize_title`` hook.  When both tracks carry drama context
    and the two drama names fuzzy-match at ≥ 90 %, this returns:

    * ``boost = +15.0`` — added to the final normalised score to reward the
      verified drama match even when artist/title romanisation differs or the
      artist field reads "Various Artists".
    * ``duration_override = 7000`` (ms) — prevents a strict duration gate from
      killing an otherwise correct OST match; TV-edit, trailer, and full-album
      versions of the same song routinely differ by 3–7 s.

    Returns ``{"boost": 0, "duration_override": 0}`` when drama context is
    absent from either track or when the similarity is below the threshold, so
    the calling engine always receives a well-typed dict regardless of outcome.
    """
    source = kwargs.get("source")
    candidate = kwargs.get("candidate")

    if source is None or candidate is None:
        return {"boost": 0, "duration_override": 0}

    local_drama: str = _safe_getattr(source, "plugin_context", {}).get("cjk_drama", "") or ""
    remote_drama: str = _safe_getattr(candidate, "plugin_context", {}).get("cjk_drama", "") or ""

    if not local_drama or not remote_drama:
        return {"boost": 0, "duration_override": 0}

    # Normalise both drama strings before comparison so that
    # Traditional/Simplified variants, full-width vs half-width punctuation,
    # and decorative spacing don't cause spurious mismatches.
    # Step 1: Traditional → Simplified (so 點燃我 == 点燃我)
    try:
        _t = get_transliterator()
        local_drama = _t.to_simplified(local_drama)
        remote_drama = _t.to_simplified(remote_drama)
    except Exception:
        pass
    # Step 2: strip everything that isn't a letter / Han character / digit so
    # full-width commas, spaces, hyphens, etc. are ignored entirely.
    # '点燃我，温暖你' → '点燃我温暖你'   '点燃我, 温暖你' → '点燃我温暖你'
    _strip_punct = lambda s: re.sub(r"[^\w]", "", s, flags=re.UNICODE)
    local_cmp = _strip_punct(local_drama)
    remote_cmp = _strip_punct(remote_drama)

    from difflib import SequenceMatcher

    ratio = SequenceMatcher(None, local_cmp, remote_cmp).ratio()

    if ratio >= 0.90:
        logger.debug(
            "scoring_modifier: drama match %r ≈ %r (normalised: %r vs %r, ratio=%.2f) "
            "→ force_artist_score_to_100=True, boost=+15, duration_override=15000ms",
            local_drama,
            remote_drama,
            local_cmp,
            remote_cmp,
            ratio,
        )
        return {
            "boost": 15.0,
            "force_artist_score_to_100": True,
            "duration_override": 15000,
        }

    logger.debug(
        "scoring_modifier: drama context present but ratio %.2f < 0.90 "
        "(%r vs %r, normalised: %r vs %r) — no boost applied",
        ratio,
        local_drama,
        remote_drama,
        local_cmp,
        remote_cmp,
    )
    return {"boost": 0, "duration_override": 0}


# ── Hook 6: search_expansion (local-DB query expansion) ─────────────────────


def _on_search_expansion(terms: Any, **kwargs: Any) -> list[str]:
    """
    Filter registered on the ``search_expansion`` hook.

    Called during local-library candidate retrieval in the playlist sync
    pipeline.  When the source track title or artist contains CJK characters,
    returns Latin-phonetic forms (Pinyin / Romaji / Revised Romanization) and
    Script variants (Simplified / Traditional Chinese) so the database query
    also hits alias rows written by the CJK plugin's ``post_metadata_enrichment``
    handler — without requiring the local file to have been tagged in Chinese.

    Also emits the bare content of any CJK bracket group (e.g. the drama name
    inside 《莲花楼》) as a standalone search term so tracks stored only under
    the series name are found even when the full bracketed title yields no hit.

    Returns the input ``terms`` list unchanged for non-CJK strings so there is
    zero overhead for standard Latin / English libraries.
    """
    result: list[str] = list(terms) if isinstance(terms, list) else []
    title: str = kwargs.get("title", "") or ""
    artist: str = kwargs.get("artist", "") or ""

    tr = get_transliterator()
    seen = {t.lower() for t in result}

    def _add(s: str) -> None:
        s = (s or "").strip()
        if s and s.lower() not in seen:
            seen.add(s.lower())
            result.append(s)

    if _has_cjk(title):
        # Native CJK title — emit Romaji/Pinyin and both script variants so
        # the DB query hits alias rows regardless of how the file was tagged.
        _add(tr.flatten_to_romaji(title))
        _add(tr.to_simplified(title))
        _add(tr.to_traditional(title))
        m = _CJK_BRACKET_RE.search(title)
        if m:
            drama = next((g for g in m.groups() if g is not None), None)
            if drama and drama.strip():
                _add(drama.strip())
                _add(tr.flatten_to_romaji(drama.strip()))
    else:
        # Pure-Latin / Pinyin title (e.g. "[Jiang Cheng] Hen Bie").
        # Emit the title itself as an explicit search term so the SQL query
        # hits track_aliases.name rows written for romanised forms.
        # Also emit any content inside ASCII brackets as a standalone term —
        # e.g. "[Jiang Cheng]" emits "Jiang Cheng" for tracks stored under
        # just the character/series name.
        _add(title)
        m = _ASCII_BRACKET_RE.search(title)
        if m:
            bracket_content = next((g for g in m.groups() if g is not None), None)
            if bracket_content and bracket_content.strip():
                _add(bracket_content.strip())

    if _has_cjk(artist):
        _add(tr.flatten_to_romaji(artist))

    added = len(result) - (len(list(terms)) if isinstance(terms, list) else 0)
    if added:
        logger.debug(
            "search_expansion: added %d alternative term(s) for %r",
            added,
            title or artist,
        )
    return result


def _on_post_metadata_enrichment(track_obj: Any) -> Any:
    """
    After the MetadataEnhancerService pipeline:

    1. Stamp ``cjk_restored`` on ``track_obj.metadata_status`` (True for CJK tracks,
       False for non-CJK tracks so the enhancer won't requeue them on the next pass).
    2. Persist all script-variant TrackAlias rows for the track title (CJK only).
    3. Persist all script-variant ArtistAlias rows for the artist name (CJK only).

    Design invariant: ``track_obj.metadata_status`` is always written BEFORE any
    relationship lazy-load or alias-persistence work.  This prevents a silent
    ``DetachedInstanceError`` (or any other ORM error thrown while accessing
    ``track_obj.artist``) from propagating up to ``apply_filters`` and aborting
    the hook before the stamp is persisted.
    """
    if not hasattr(track_obj, "metadata_status") or not hasattr(track_obj, "id"):
        return track_obj

    title = _safe_getattr(track_obj, "title", "") or ""

    # Guard the artist relationship lazy-load with an explicit try/except so that a
    # DetachedInstanceError or any other SQLAlchemy session error can never prevent
    # the metadata_status stamp from being written below.
    # (Python's built-in getattr(obj, attr, default) only catches AttributeError —
    # it does NOT suppress DetachedInstanceError or other SQLAlchemy exceptions.)
    artist_name = ""
    try:
        artist_obj = _safe_getattr(track_obj, "artist", None)
        artist_name = (_safe_getattr(artist_obj, "name", "") or "") if artist_obj else ""
    except Exception as _exc:
        logger.debug(
            "CJK plugin: could not load artist for Track ID %s (%s) — CJK detection falls back to title-only.",
            _safe_getattr(track_obj, "id", "?"),
            _exc,
        )

    status = dict(track_obj.metadata_status or {})
    is_cjk = _has_cjk(title) or _has_cjk(artist_name)

    # ── STAMP FIRST, before any further lazy-loads or alias persistence ───────
    # Writing cjk_restored here guarantees the value reaches the DB even if the
    # alias work below raises — the enhancer's flag_modified + session.commit()
    # will capture whatever is currently assigned to track_obj.metadata_status.
    if "cjk_restored" not in status:
        status["cjk_restored"] = is_cjk
        if is_cjk:
            status["cjk_script_applied"] = status.get("release_script", "Latn")
            logger.debug("Stamped cjk_restored for Track ID %s", track_obj.id)
        track_obj.metadata_status = status

    if not is_cjk:
        return track_obj

    # ── CJK-only: persist script-variant aliases ──────────────────────────────
    if _has_cjk(title):
        _persist_track_aliases(track_obj, _build_track_alias_entries(track_obj))

    if _has_cjk(artist_name):
        _persist_artist_aliases(track_obj, _build_artist_alias_entries(artist_name))

    return track_obj


# ── Plugin Initialization ──────────────────────────────────────────────────────


def initialize_plugin() -> None:
    """Wire all hooks into the system. Called automatically on first import."""
    logger.info("CJK Language Pack: initializing hooks...")
    hook_manager.add_filter("register_metadata_requirements", _on_register_metadata_requirements)
    hook_manager.add_filter("pre_provider_search", _on_pre_provider_search)
    hook_manager.add_filter("pre_normalize_text", _on_pre_normalize_text)
    hook_manager.add_filter("pre_normalize_title", _on_pre_normalize_title)
    hook_manager.add_filter("scoring_modifier", _on_scoring_modifier)
    hook_manager.add_filter("search_expansion", _on_search_expansion)
    hook_manager.add_filter("post_metadata_enrichment", _on_post_metadata_enrichment)
    logger.info(
        "CJK Language Pack: registered hooks "
        "(register_metadata_requirements / pre_provider_search / "
        "pre_normalize_text / pre_normalize_title / "
        "scoring_modifier / search_expansion / post_metadata_enrichment)"
    )


initialize_plugin()


# ── Registry Override (WeightedMatchingEngine subclass) ───────────────────────
from core.matching_engine.matching_engine import WeightedMatchingEngine
from core.nexus_framework.plugin_loader import PluginRegistry, ServiceRegistry


class CJKMatchingEngine(WeightedMatchingEngine):
    """
    Subclass reserved for future CJK-specific scoring overrides.
    Currently delegates all scoring to WeightedMatchingEngine unchanged;
    the pre_normalize_text hook above is sufficient for correct CJK matching.
    """


ServiceRegistry.register_override("com.echosync.cjk-pack", CJKMatchingEngine)
