from core.nexus_framework.plugin_SDK import sdk
"""Plex provider routes."""

import threading
import uuid
import logging
from fastapi import APIRouter, Request, HTTPException, Depends
from fastapi.responses import JSONResponse
from core.tiered_logger import get_logger


logger = get_logger("plex_routes")

# Create a single blueprint for all Plex routes
router = APIRouter()

# --- Settings Logic (from web/routes/plex_settings.py) ---

@router.get('/settings')
def get_settings():
    """Get Plex server settings (base_url, token status)."""
    from core.nexus_framework.plugin_loader import PluginRegistry, ServiceRegistry
    if PluginRegistry.is_plugin_disabled('plex'):
        return JSONResponse(content={'settings': {}}, status_code=200)
    try:
        base_url = sdk.config.get('plex.base_url', '')
        server_name = sdk.config.get('plex.server_name', '')
        
        # Retrieve token from Singleton Account
        # Using global SDK singleton
        from core.security import decrypt_string
        
        accounts = sdk.accounts.get_all()

        token = ''
        if accounts:
            account_id = accounts[0].get('id')
            token_data = sdk.accounts.get_token(account_id)
            if token_data and token_data.get('access_token'):
                token = decrypt_string(token_data.get('access_token'))

        # Check if this is the active media server
        active_media_server = sdk.config.get('active_media_server', 'plex')
        is_active = (active_media_server == 'plex')
        
        # Check connection status
        connected = False
        if base_url and token:
            try:
                from plexapi.server import PlexServer
                server = PlexServer(base_url, token, timeout=5)
                # If we can get server identity, we're connected
                _ = server.machineIdentifier
                connected = True
            except Exception as e:
                logger.debug(f"Plex connection check failed: {e}")
        
        return JSONResponse(content={
            'settings': {
                'base_url': base_url,
                'server_name': server_name,
                'has_token': bool(token),
                'connected': connected,
                'is_active': is_active
            }
        })
    except Exception as e:
        logger.error(f"Error getting Plex settings: {e}", exc_info=True)
        return JSONResponse(content={"error": str(e) if logger.isEnabledFor(logging.DEBUG) else "Internal server error"}, status_code=500)


@router.post('/settings')
async def save_settings(request: Request):
    """Save Plex server settings."""
    try:
        from core.nexus_framework.plugin_loader import PluginRegistry, ServiceRegistry
        data = await request.json() or {}
        
        if 'base_url' in data:
            base_url = data['base_url'].strip()
            sdk.config.set('plex.base_url', base_url)
            logger.info(f"Plex base_url saved: {base_url}")
        
        if 'server_name' in data:
            server_name = data['server_name'].strip()
            sdk.config.set('plex.server_name', server_name)
            logger.info(f"Plex server_name saved: {server_name}")
        
        if 'token' in data:
            # We don't save tokens to config_manager anymore. We save them to account_tokens
            token = data['token'].strip()
            # Using global SDK singleton
            from core.security import encrypt_string
            from .client import PlexClient
            import time
            

            accounts = sdk.accounts.get_all()
            if accounts:
                account_id = accounts[0].get('id')
            else:
                account_id = sdk.accounts.ensure_account(account_name=f"plex_user_{int(time.time())}")

            sdk.accounts.save_token(
                account_id=account_id, access_token=token, refresh_token=None, expires_at=None)
            logger.info(f"Plex token saved to SQLite account {account_id}")

            try:
                PlexClient(account_id=account_id).import_managed_users()
            except Exception as e:
                logger.warning(f"Failed to import Plex managed users after saving settings: {e}")
        
        return {'success': True}
    except Exception as e:
        logger.error(f"Error saving Plex settings: {e}", exc_info=True)
        return JSONResponse(content={"error": str(e) if logger.isEnabledFor(logging.DEBUG) else "Internal server error"}, status_code=500)


@router.post('/activate')
def activate_server():
    """Set Plex as the active media server."""
    try:
        sdk.config.set('active_media_server', 'plex')
        logger.info("Plex set as active media server")
        return JSONResponse(content={
            'success': True,
            'message': 'Plex is now the active media server'
        })
    except Exception as e:
        logger.error(f"Error activating Plex: {e}", exc_info=True)
        return JSONResponse(content={"error": str(e) if logger.isEnabledFor(logging.DEBUG) else "Internal server error"}, status_code=500)


@router.post('/test-connection')
async def test_connection(request: Request):
    """Test connection to Plex server."""
    try:
        payload = await request.json() or {}

        base_url = str(
            payload.get('base_url')
            or sdk.config.get('plex.base_url', '')
        ).strip()

        # Using global SDK singleton
        from core.security import decrypt_string

        
        accounts = sdk.accounts.get_all()

        token = ''
        if accounts:
            account_id = accounts[0].get('id')
            token_data = sdk.accounts.get_token(account_id)
            if token_data and token_data.get('access_token'):
                token = decrypt_string(token_data.get('access_token'))
        
        if not base_url:
            return JSONResponse(content={'error': 'Server URL is required'}, status_code=400)
        if not token:
            return JSONResponse(content={'error': 'Authentication token is required. Please log in first.'}, status_code=400)
        
        from plexapi.server import PlexServer
        server = PlexServer(base_url, token, timeout=10)
        
        # Get server info
        machine_id = server.machineIdentifier
        friendly_name = server.friendlyName
        version = server.version
        
        logger.info(f"Plex connection successful: {friendly_name} ({version})")
        
        return JSONResponse(content={
            'connected': True,
            'server_name': friendly_name,
            'version': version,
            'machine_id': machine_id
        })
    except ImportError:
        return JSONResponse(content={'error': 'Plex library not available'}, status_code=500)
    except Exception as e:
        logger.error(f"Plex connection test failed: {e}", exc_info=True)
        return JSONResponse(content={"connected": False, "error": str(e) if logger.isEnabledFor(logging.DEBUG) else "Connection test failed"}, status_code=400)


# --- OAuth Logic (from providers/plex/oauth_routes.py) ---

plex_oauth_sessions = {}
plex_oauth_lock = threading.Lock()

@router.post('/auth/start')
async def start_oauth(request: Request):
    """
    Start Plex OAuth flow using PIN-based authentication.
    Returns: {session_id, oauth_url, poll_url}
    """
    try:
        from plexapi.myplex import MyPlexPinLogin
        from database.config_database import get_config_database

        pin_login = MyPlexPinLogin(oauth=True)
        session_id = str(uuid.uuid4())

        # We don't want to use pin_login.run() because it blocks the thread
        # and starts an internal polling loop. Instead we initialize the code
        # and let the frontend do the polling.
        pin_login._getCode()

        # We need a dummy forward URL to satisfy OAuth, even though Plex uses PINs
        origin = request.headers.get('Origin')
        forward_url = f"{origin}/settings/music-services" if origin else "http://127.0.0.1:5173/settings/music-services"
        oauth_url = pin_login.oauthUrl(forward_url)

        pin_id = str(pin_login._id)
        client_id = pin_login._headers().get('X-Plex-Client-Identifier', 'Echosync')

        with plex_oauth_lock:
            plex_oauth_sessions[session_id] = pin_login

        # Persist session to database so polling survives worker recycling / reloads
        try:
            db = get_config_database()
            db.store_pkce_session(
                pkce_id=session_id,
                service='plex',
                account_id=0,
                code_verifier=pin_id,
                code_challenge='',
                redirect_uri=forward_url,
                client_id=client_id,
                ttl_seconds=900
            )
        except Exception as db_err:
            logger.warning(f"Failed to persist Plex OAuth session to DB: {db_err}")

        logger.info(f"Plex OAuth session started: {session_id} with pin id: {pin_id}")

        # Register a one-shot cleanup job with the central scheduler so the session
        # is expired after 15 minutes without spawning a raw background thread.
        _session_id = session_id  # capture for closure
        def _cleanup_oauth_session():
            with plex_oauth_lock:
                if _session_id in plex_oauth_sessions:
                    plex_oauth_sessions.pop(_session_id, None)
                    logger.info(f"Plex OAuth session cleaned up: {_session_id}")
            try:
                get_config_database().delete_pkce_session(_session_id)
            except Exception:
                pass

        from core.job_queue import job_queue
        job_queue.register_job(
            name=f"plex_oauth_cleanup_{session_id}",
            func=_cleanup_oauth_session,
            interval_seconds=None,  # one-shot
            start_after=900.0,      # 15 minutes
            enabled=True,
            tags=["plex", "oauth", "cleanup"],
        )

        return JSONResponse(content={
            'session_id': session_id,
            'oauth_url': oauth_url,
            'poll_url': f'/api/v1/plugins/3021005569/auth/poll/{session_id}'
        })
    except ImportError:
        logger.error("plexapi library not installed")
        return JSONResponse(content={'error': 'Plex library not available'}, status_code=500)
    except Exception as e:
        logger.error(f"Error starting Plex OAuth: {e}", exc_info=True)
        return JSONResponse(content={"error": str(e) if logger.isEnabledFor(logging.DEBUG) else "Internal server error"}, status_code=500)


@router.get('/auth/poll/{session_id}')
def poll_oauth(session_id: str):
    """
    Poll for Plex OAuth authorization completion.
    Returns: {completed, token?, error?}
    """
    try:
        from database.config_database import get_config_database
        
        pin_login = None
        with plex_oauth_lock:
            pin_login = plex_oauth_sessions.get(session_id)

        pin_id = None
        client_id = 'Echosync'

        if pin_login:
            pin_id = str(pin_login._id)
            client_id = pin_login._headers().get('X-Plex-Client-Identifier', 'Echosync')
        else:
            # Fallback to persistent DB session
            try:
                db_session = get_config_database().get_pkce_session(session_id)
                if db_session:
                    pin_id = db_session.get('code_verifier')
                    client_id = db_session.get('client_id') or 'Echosync'
            except Exception as e:
                logger.debug(f"DB session lookup failed: {e}")

        if not pin_id:
            return JSONResponse(content={'error': 'Session not found or expired'}, status_code=404)

        # We manually query the Plex PIN API to check if the user authorized it.
        import requests
        is_logged_in = False
        auth_token = None

        try:
            headers = {
                'Accept': 'application/json',
                'X-Plex-Client-Identifier': client_id
            }
            # Explicitly request the PIN status from Plex
            resp = requests.get(f"https://plex.tv/api/v2/pins/{pin_id}", headers=headers, timeout=5)
            resp_data = resp.json()
            logger.debug(f"Plex PIN status response: {resp_data}")

            if resp_data.get('authToken'):
                is_logged_in = True
                auth_token = resp_data.get('authToken')
        except requests.exceptions.RequestException as e:
            # Network-level failure (DNS, timeout, connection refused). Return 503 so the
            # frontend applies backoff rather than hammering a potentially unreachable endpoint.
            logger.warning(f"Plex PIN API unreachable: {e}")
            return JSONResponse(content={'completed': False, 'error': 'Plex authorization service temporarily unavailable'}, status_code=503)
        except Exception as e:
            logger.debug(f"Plex poll API check failed: {e}")

        if is_logged_in and auth_token:
            # Using global SDK singleton
            from core.security import encrypt_string
            from .client import PlexClient
            

            # Plex follows a Singleton Account Pattern. Look for an existing account first.
            accounts = sdk.accounts.get_all()

            if accounts:
                # Upsert existing account
                account_id = accounts[0].get('id')
                account_name = accounts[0].get('account_name', 'Default Plex Server')
                logger.info(f"Plex Singleton: Found existing account {account_id}, updating token.")
            else:
                # Fallback to fetching user details if we create a new one
                account_name = sdk.config.get('base_url') or sdk.config.get('server_url') or "Default Plex Server"
                try:
                    from plexapi.myplex import MyPlexAccount
                    myplex_acc = MyPlexAccount(token=auth_token)
                    account_name = myplex_acc.username or myplex_acc.email or account_name
                except Exception as e:
                    logger.warning(f"Failed to fetch Plex username: {e}")

                # Ensure the new singleton account exists
                account_id = sdk.accounts.ensure_account(account_name=account_name)
                logger.info(f"Plex Singleton: Created new account {account_id} ({account_name}).")

            # Encrypt and save token to account_tokens
            try:
                sdk.accounts.save_token(
                    account_id=account_id, access_token=auth_token, refresh_token=None, expires_at=None)
                sdk.accounts.mark_account_authenticated(account_id)
                sdk.accounts.toggle_account_active(account_id, True)
                logger.info(f"Plex OAuth completed and token securely saved for account: {account_name}")
                try:
                    PlexClient(account_id=account_id).import_managed_users()
                except Exception as import_err:
                    logger.warning(f"Failed to import Plex managed users after OAuth: {import_err}")
            except Exception as e:
                logger.error(f"Failed to securely save Plex token: {e}")
                return JSONResponse(content={'error': 'Failed to securely save token'}, status_code=500)

            with plex_oauth_lock:
                plex_oauth_sessions.pop(session_id, None)

            return JSONResponse(content={
                'completed': True,
                'token': auth_token  # For backwards compatibility in UI until UI is updated
            })
        else:
            return JSONResponse(content={
                'completed': False
            })

    except Exception as e:
        logger.error(f"Error polling Plex OAuth: {e}", exc_info=True)
        return JSONResponse(content={"error": str(e) if logger.isEnabledFor(logging.DEBUG) else "Internal server error"}, status_code=500)


@router.delete('/auth/cancel/{session_id}')
def cancel_oauth(session_id: str):
    """Cancel an ongoing OAuth session."""
    try:
        with plex_oauth_lock:
            pin_login = plex_oauth_sessions.pop(session_id, None)
            if pin_login:
                logger.info(f"Plex OAuth session cancelled: {session_id}")

        return {'success': True}
    except Exception as e:
        logger.error(f"Error cancelling Plex OAuth: {e}", exc_info=True)
        return JSONResponse(content={"error": str(e) if logger.isEnabledFor(logging.DEBUG) else "Internal server error"}, status_code=500)

from web.auth import require_auth

@router.post("/sync_users", dependencies=[Depends(require_auth)])
def sync_plex_users():
    """Sync Plex admin and managed users into settings database and return the updated list."""
    try:
        from .client import PlexClient
        # Using global SDK singleton

        client = PlexClient()
        client.import_managed_users()

        
        accounts = sdk.accounts.get_all()
        return JSONResponse(content={
            'service': 'plex',
            'accounts': accounts,
            'total': len(accounts),
            'success': True,
        }), 200
    except Exception as e:
        logger.error(f"Error syncing Plex users: {e}", exc_info=True)
        return JSONResponse(content={"error": str(e) if logger.isEnabledFor(logging.DEBUG) else "Internal server error"}, status_code=500)
