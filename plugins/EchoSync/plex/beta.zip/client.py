"""
Plex Music Provider - Refactored
Simplified implementation using EchosyncTrack and new core features.
"""

import re
import time
from datetime import UTC, datetime
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

from plexapi.audio import Track as PlexTrack
from plexapi.exceptions import NotFound
from plexapi.library import MusicSection
from plexapi.server import PlexServer

from core.db.echo_sync_track import EchosyncTrack
from core.task_manager.health import HealthCheckResult
from core.nexus_framework.plugin_SDK import (
    MediaServerProvider,
    MetadataRichness,
    PlaylistSupport,
    ProviderCapabilities,
    SearchCapabilities,
)
from core.tiered_logger import get_logger
from core.user_history import UserTrackInteraction
from core.utils import PathMapper

logger = get_logger("plex_client")
from core.settings import config_manager


def _safe_getattr(obj: Any, attr: str, default: Any = None) -> Any:
    """AST-compliant alternative to _safe_getattr()."""
    if obj is None:
        return default
    if hasattr(obj, attr):
        try:
            return obj.__getattribute__(attr)
        except AttributeError:
            return default
    return default


def verify_plex_candidate(plex_item: Any, local_meta: EchosyncTrack | None) -> float:
    """Evaluate a Plex search candidate against local track metadata using a disambiguation matrix.

    Uses the shared polynomial duration decay curve (`calculate_duration_score`, k=6) from
    `core.matching_engine.matching_engine` so Plex recovery aligns with ExactSyncProfile.
    Returns a composite score from 0.0 to 100.0.
    """
    if not plex_item or not local_meta:
        return 0.0

    from core.matching_engine.matching_engine import calculate_duration_score

    # 1. File Basename Check: Compare filename of local track with Plex media parts
    local_path = getattr(local_meta, "file_path", None) or ""
    basename_matched = False
    if local_path:
        local_filename = Path(local_path).name.lower()
        for media in getattr(plex_item, "media", []):
            for part in getattr(media, "parts", []):
                part_file = getattr(part, "file", "") or ""
                if part_file and Path(part_file).name.lower() == local_filename:
                    basename_matched = True
                    break

    # 2. Artist Similarity Check
    plex_artist = getattr(plex_item, "grandparentTitle", "") or getattr(plex_item, "originalTitle", "") or ""
    if not plex_artist and hasattr(plex_item, "artist"):
        try:
            art_obj = plex_item.artist()
            plex_artist = _safe_getattr(art_obj, "title", "") or ""
        except Exception:
            pass

    local_artist = getattr(local_meta, "artist", "") or getattr(local_meta, "artist_name", "") or ""
    artist_bonus = 0.0
    artist_sim = 0.0
    if plex_artist and local_artist:
        artist_sim = SequenceMatcher(None, plex_artist.lower().strip(), local_artist.lower().strip()).ratio()
        if artist_sim >= 0.85:
            artist_bonus = 30.0
        elif artist_sim >= 0.70:
            artist_bonus = 15.0
    elif not local_artist:
        artist_bonus = 15.0

    # 3. Shared Variable Duration Decay Curve (k=6, aligned with ExactSyncProfile)
    plex_dur = getattr(plex_item, "duration", 0) or 0
    local_dur = getattr(local_meta, "duration_ms", None) or getattr(local_meta, "duration", 0) or 0
    if basename_matched:
        t_base_ms, t_limit_ms = 5500, 8000
    elif artist_sim >= 0.85:
        t_base_ms, t_limit_ms = 4500, 6000
    else:
        t_base_ms, t_limit_ms = 3000, 4000

    dur_score = 1.0
    if local_dur and plex_dur:
        dur_score = calculate_duration_score(
            abs(int(plex_dur) - int(local_dur)),
            t_base_ms=t_base_ms,
            t_limit_ms=t_limit_ms,
        )
        if dur_score <= 0.0:
            return 0.0

    score = (20.0 * dur_score) + (50.0 if basename_matched else 0.0) + artist_bonus
    return score


class PlexClient(MediaServerProvider):
    """Plex music provider - streams music from Plex media server."""

    name = "EchoSync.plex"
    category = "provider"
    supports_downloads = False
    capabilities = ProviderCapabilities(
        name="EchoSync.plex",
        supports_playlists=PlaylistSupport.READ_WRITE,
        search=SearchCapabilities(tracks=True, artists=True, albums=True, playlists=False),
        metadata=MetadataRichness.HIGH,
        supports_cover_art=True,
        supports_lyrics=False,
        supports_user_auth=True,
        supports_library_scan=True,
        supports_streaming=False,
        supports_downloads=False,
        supports_metrics=True,
    )

    def __init__(self, account_id: int | None = None):
        """Initialize Plex provider."""
        super().__init__()

        # Provision the high-speed relational cache using the isolated db
        try:
            from sqlalchemy import text

            engine = self.get_database_connection()
            with engine.begin() as conn:
                conn.execute(
                    text("""
                    CREATE TABLE IF NOT EXISTS plex_media (
                        id INTEGER PRIMARY KEY,
                        rating_key TEXT UNIQUE NOT NULL,
                        title TEXT,
                        artist TEXT,
                        album TEXT,
                        duration INTEGER,
                        last_synced TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                )
        except Exception as e:
            logger.error(f"Failed to provision Plex cache table: {e}")

        self.server: PlexServer | None = None

        self.music_library: MusicSection | None = None
        self.path_mapper: PathMapper | None = None
        self._connection_attempted = False
        self._is_connecting = False
        self._last_connection_attempt = 0
        self._connection_check_interval = 30

        # Auto-detect active account if not provided
        if account_id is None:
            try:
                accounts = self.accounts.get_all()
                if accounts:
                    token_backed_account = next(
                        (
                            account
                            for account in accounts
                            if account.get("id") and self.accounts.get_token(account.get("id"))
                        ),
                        None,
                    )
                    account_id = (token_backed_account or accounts[0]).get("id")
                    logger.debug(f"[system] - Plex account resolved to: {account_id}")
            except Exception as e:
                logger.warning(f"Failed to auto-detect Plex account: {e}")

        self.account_id = account_id
        self._register_health_check()

    def _register_health_check(self):
        """Register periodic health check for Plex server."""
        if not self.is_configured():
            return

        def plex_health_check() -> HealthCheckResult:
            try:
                connected = self.ensure_connection()
                status = "healthy" if connected else "unhealthy"
                message = "Plex server is reachable" if connected else "Plex server connection failed"
                return HealthCheckResult(
                    service_name="plex",
                    status=status,
                    message=message,
                )
            except Exception as e:
                return HealthCheckResult(
                    service_name="plex",
                    status="unhealthy",
                    message=f"Plex connection error: {e!s}",
                )

        self.sdk.health.register(plex_health_check, interval_seconds=300)

    def authenticate(self, **kwargs) -> bool:
        """Authenticate with Plex server."""
        return self.ensure_connection()

    def is_configured(self) -> bool:
        """Check if Plex is configured (has credentials)."""
        # A Plex account requires an associated access token and a server base_url
        if not self.account_id:
            return False

        # Check token existence via SDK facade
        token_data = self.accounts.get_token(self.account_id)
        token = token_data.get("access_token") if token_data else None

        # Check base_url existence from config facade
        base_url = self.config.get("base_url") or self.config.get("server_url")

        return bool(base_url and token)

    def get_logo_url(self) -> str:
        """Return Plex logo URL."""
        return "/static/img/plex_logo.png"

    def is_connected(self) -> bool:
        """Compatibility method used by sync service."""
        return self.ensure_connection()

    def search_tracks(self, query: str, limit: int = 10) -> list[EchosyncTrack]:
        """Compatibility wrapper for services expecting search_tracks()."""
        return self.search(query=query, type="track", limit=limit)

    def update_playlist(self, name: str, tracks: list[Any]) -> bool:
        """Create or replace a Plex playlist with provided native Plex track items.

        Expects `tracks` to be native Plex Track objects with ratingKey attributes.

        DEPRECATED: Use add_tracks_to_playlist(playlist_id, provider_track_ids) instead.
        """
        if not self.ensure_connection() or not self.server:
            return False
        try:
            # Try to remove existing playlist with same name (if exists)
            try:
                existing = self.server.playlist(name)
                try:
                    existing.delete()
                except Exception:
                    # Fallback: remove items if delete not permitted
                    try:
                        items = list(existing.items())
                        if items:
                            existing.removeItems(items)
                    except Exception:
                        pass
            except Exception:
                pass

            # Create new playlist with provided tracks
            from plexapi.playlist import Playlist

            Playlist.create(self.server, name, tracks, playlistType="audio")
            logger.info(f"Updated Plex playlist: {name} with {len(tracks)} tracks")
            return True
        except Exception as e:
            logger.error(f"Error updating Plex playlist '{name}': {e}")
            return False

    def add_tracks_to_playlist(self, playlist_id: str, provider_track_ids: list[str]) -> bool:
        """Add tracks to a Plex playlist using ratingKeys (provider-specific track IDs).

        NEW INTERFACE: Accepts only track IDs (ratingKeys), not full track objects.
        This is provider-agnostic and more efficient than passing full objects.

        Args:
            playlist_id: Plex playlist ID or name
            provider_track_ids: List of Plex ratingKeys as strings (e.g., ['123', '456'])

        Returns:
            True if successful, False otherwise
        """
        if not self.ensure_connection() or not self.server:
            logger.error("Plex not connected for add_tracks_to_playlist")
            return False

        try:
            # Find the playlist by ID or name
            try:
                # Try as ratingKey first (numeric ID)
                try:
                    playlist_id_int = int(playlist_id)
                    playlist = self.server.fetchItem(playlist_id_int)
                except (ValueError, TypeError):
                    # Try as name
                    playlist = self.server.playlist(playlist_id)
            except Exception as e:
                logger.error(f"Failed to find Plex playlist '{playlist_id}': {e}")
                return False

            if not playlist:
                logger.error(f"Playlist '{playlist_id}' not found on Plex server")
                return False

            # Convert string ratingKeys to actual track objects
            items = []
            for rk in provider_track_ids:
                try:
                    rk_int = int(rk)
                    item = self.server.fetchItem(rk_int)
                    if item:
                        items.append(item)
                    else:
                        logger.warning(f"Track with ratingKey {rk} not found on Plex server")
                except (ValueError, TypeError):
                    logger.warning(f"Invalid ratingKey format: {rk}")
                except Exception as e:
                    logger.warning(f"Error fetching track {rk}: {e}")

            if not items:
                logger.error(f"No valid Plex items found for ratingKeys: {provider_track_ids}")
                return False

            # Add items to playlist
            try:
                playlist.addItems(items)
                logger.info(f"Successfully added {len(items)} tracks to Plex playlist '{playlist_id}'")
                return True
            except Exception as e:
                logger.error(f"Error adding items to Plex playlist '{playlist_id}': {e}")
                return False

        except Exception as e:
            logger.error(
                f"Error in add_tracks_to_playlist for '{playlist_id}': {e}",
                exc_info=True,
            )
            return False

    def remove_tracks_from_playlist(self, playlist_id: str, provider_track_ids: list[str]) -> bool:
        """Remove tracks from a Plex playlist using ratingKeys."""
        if not self.ensure_connection() or not self.server:
            logger.error("Plex not connected for remove_tracks_from_playlist")
            return False

        if not provider_track_ids:
            logger.info("remove_tracks_from_playlist called with empty track list; nothing to do")
            return True

        try:
            try:
                try:
                    playlist = self.server.fetchItem(int(playlist_id))
                except (ValueError, TypeError):
                    playlist = self.server.playlist(playlist_id)
            except Exception as e:
                logger.error(f"Failed to find Plex playlist '{playlist_id}': {e}")
                return False

            if not playlist:
                logger.error(f"Playlist '{playlist_id}' not found on Plex server")
                return False

            removal_keys = {str(rk) for rk in provider_track_ids}
            existing_items = list(playlist.items())
            to_remove = [item for item in existing_items if str(_safe_getattr(item, "ratingKey", "")) in removal_keys]

            if not to_remove:
                logger.info(f"No matching tracks found to remove from Plex playlist '{playlist_id}'")
                return True

            playlist.removeItems(to_remove)
            logger.info(f"Removed {len(to_remove)} track(s) from Plex playlist '{playlist_id}'")
            return True
        except Exception as e:
            logger.error(
                f"Error removing tracks from Plex playlist '{playlist_id}': {e}",
                exc_info=True,
            )
            return False

    def delete_track(self, rating_key: str) -> bool:
        """Delete a track from Plex server by ratingKey."""
        base_url = self.config.get("base_url") or self.config.get("server_url")
        token = self.secrets.get("token") or self.accounts.get_metadata(self.account_id, "token")

        if not base_url or not token:
            logger.error("Plex not configured, cannot delete track")
            return False

        # Construct URL
        url = f"{base_url.rstrip('/')}/library/metadata/{rating_key}"

        # Headers
        headers = {"X-Plex-Token": token, "Accept": "application/json"}

        try:
            # Use self.http as mandated by PluginBase
            response = self.http.delete(url, headers=headers)

            if response.status_code == 200:
                logger.info(f"Successfully deleted track {rating_key} from Plex")
                return True
            elif response.status_code == 403:
                logger.warning(f"Plex server does not allow file deletion (403 Forbidden) for track {rating_key}")
                return False
            elif response.status_code == 404:
                logger.warning(f"Track {rating_key} not found on Plex (404)")
                return False
            else:
                logger.error(f"Failed to delete track {rating_key}: {response.status_code} {response.reason}")
                return False
        except Exception as e:
            logger.error(f"Exception deleting track {rating_key}: {e}")
            return False

    # ===== SYNC HELPERS =====
    def _find_managed_playlist(
        self,
        desired_name: str,
        marker: str = "⇄",
        management_tag: str = "managed by Echosync",
    ):
        """Find a managed playlist by name using the 3-step rule:

        1) Base name matches when stripping marker
        2) Accept if summary/description contains management_tag OR name contains marker
        Returns playlist or None
        """
        if not self.ensure_connection() or not self.server:
            return None

        try:
            for playlist in self.server.playlists():
                if not playlist:
                    continue
                title = _safe_getattr(playlist, "title", "") or ""
                summary = _safe_getattr(playlist, "summary", "") or ""

                base_title = title.replace(marker, "").strip()
                if base_title != desired_name:
                    continue

                cond_name_has_marker = marker in title
                cond_summary_managed = management_tag.lower() in summary.lower()

                if (cond_name_has_marker and base_title == desired_name) or (
                    cond_summary_managed and base_title == desired_name
                ):
                    return playlist
        except Exception as e:
            logger.debug(f"Error while scanning Plex playlists for managed match: {e}")
        return None

    @staticmethod
    def _normalize_plex_identity(value: Any) -> str | None:
        if value is None:
            return None
        normalized = str(value).strip()
        return normalized.casefold() if normalized else None

    def _is_admin_user(self, target_identity: str | None) -> bool:
        """Check if target identity matches the admin account."""
        if not self.server or not target_identity:
            return False
        try:
            myplex_account = self.server.myPlexAccount()
            admin_ids = {
                self._normalize_plex_identity(val)
                for val in [
                    _safe_getattr(myplex_account, "uuid", None),
                    _safe_getattr(myplex_account, "id", None),
                    _safe_getattr(myplex_account, "username", None),
                    _safe_getattr(myplex_account, "title", None),
                    _safe_getattr(myplex_account, "email", None),
                ]
                if val is not None
            }
            return self._normalize_plex_identity(target_identity) in admin_ids
        except Exception:
            return False

    def _resolve_managed_user(self, target_user_id: str | None = None, source_account_name: str | None = None):
        """Resolve a Plex managed user using stored IDs first, then explicit account mappings, then token-boundary fallbacks."""
        if not self.server:
            return None

        try:
            myplex_account = self.server.myPlexAccount()
        except Exception as e:
            logger.warning(f"Failed to load MyPlex account while resolving managed user: {e}")
            return None

        normalized_target_id = self._normalize_plex_identity(target_user_id)
        normalized_source_name = self._normalize_plex_identity(source_account_name)

        admin_ids = {
            normalized
            for normalized in [
                self._normalize_plex_identity(_safe_getattr(myplex_account, "uuid", None)),
                self._normalize_plex_identity(_safe_getattr(myplex_account, "id", None)),
                self._normalize_plex_identity(_safe_getattr(myplex_account, "username", None)),
                self._normalize_plex_identity(_safe_getattr(myplex_account, "title", None)),
                self._normalize_plex_identity(_safe_getattr(myplex_account, "email", None)),
            ]
            if normalized
        }
        if normalized_target_id and normalized_target_id in admin_ids:
            return None

        try:
            users = myplex_account.users() or []
        except Exception as e:
            logger.warning(f"Failed to enumerate managed Plex users: {e}")
            return None

        # Step 1: Match by direct target_user_id across user identities
        if normalized_target_id:
            for user in users:
                identities = {
                    normalized
                    for normalized in [
                        self._normalize_plex_identity(_safe_getattr(user, "id", None)),
                        self._normalize_plex_identity(_safe_getattr(user, "uuid", None)),
                        self._normalize_plex_identity(_safe_getattr(user, "username", None)),
                        self._normalize_plex_identity(_safe_getattr(user, "title", None)),
                        self._normalize_plex_identity(_safe_getattr(user, "email", None)),
                    ]
                    if normalized
                }
                if normalized_target_id in identities:
                    return user

        # Step 2: Query explicit account mappings via SDK storage facade
        if source_account_name:
            try:
                from core.nexus_framework.plugin_SDK import sdk

                storage = sdk.storage
                if storage:
                    plex_service_id = storage.get_service_id("plex")
                    all_accounts = storage.list_accounts(is_active=True)

                    source_account_ids = []
                    for acc in all_accounts:
                        if acc.get("service_id") != plex_service_id:
                            dname = (acc.get("display_name") or "").strip().lower()
                            aname = (acc.get("account_name") or "").strip().lower()
                            if normalized_source_name in (dname, aname):
                                source_account_ids.append(acc["id"])

                    for s_id in source_account_ids:
                        mappings = storage.get_account_mappings(source_account_id=s_id)
                        for m in mappings:
                            mapped_acc = storage.get_account(m["mapped_account_id"])
                            if mapped_acc and mapped_acc.get("service_id") == plex_service_id:
                                mapped_uid = self._normalize_plex_identity(mapped_acc.get("user_id"))
                                if mapped_uid:
                                    for user in users:
                                        u_identities = {
                                            self._normalize_plex_identity(_safe_getattr(user, attr, None))
                                            for attr in (
                                                "id",
                                                "uuid",
                                                "username",
                                                "title",
                                                "email",
                                            )
                                        }
                                        if mapped_uid in u_identities:
                                            logger.info(
                                                f"Resolved managed Plex user '{_safe_getattr(user, 'title', user)}' via explicit account mappings."
                                            )
                                            return user
            except Exception as map_err:
                logger.debug(f"Error querying explicit account mappings: {map_err}")

        # Step 3: Heuristic fallback using exact token boundary matching
        if normalized_source_name:
            for user in users:
                display_candidates = [
                    normalized
                    for normalized in [
                        self._normalize_plex_identity(_safe_getattr(user, "username", None)),
                        self._normalize_plex_identity(_safe_getattr(user, "title", None)),
                        self._normalize_plex_identity(_safe_getattr(user, "email", None)),
                    ]
                    if normalized
                ]
                for candidate in display_candidates:
                    pattern = r"(?:\b|_)" + re.escape(candidate) + r"(?:'s|\b|_)"
                    if re.search(pattern, normalized_source_name, re.IGNORECASE):
                        logger.info(
                            f"Resolved managed Plex user '{_safe_getattr(user, 'title', user)}' by token-boundary match for source account '{source_account_name}'"
                        )
                        return user

        return None

    def _switch_to_user_server(self, user: Any):
        """Switch Plex context to a managed user using the first working identity key."""
        if not self.server or not user:
            return None

        switch_candidates = []
        for value in [
            _safe_getattr(user, "username", None),
            _safe_getattr(user, "title", None),
            _safe_getattr(user, "email", None),
        ]:
            candidate = str(value).strip() if value is not None else ""
            if candidate and candidate not in switch_candidates:
                switch_candidates.append(candidate)

        last_error = None
        for candidate in switch_candidates:
            try:
                switched = self.server.switchUser(candidate)
                if switched:
                    logger.info(f"Switched Plex context using managed-user key '{candidate}'")
                    return switched
            except Exception as e:
                last_error = e
                logger.debug(f"Plex switchUser failed for candidate '{candidate}': {e}")

        if last_error:
            raise last_error
        return None

    def add_tracks_to_managed_playlist(
        self,
        playlist_name: str,
        rating_keys: list[str],
        marker: str = "⇄",
        overwrite: bool = True,
        source_account_name: str = None,
        target_user_id: str = None,
    ) -> bool:
        """Ensure managed playlist exists and overwrite with provided ratingKeys.

        Marker defaults to U+21C4 (⇄). Playlist is considered managed if either name contains marker
        or summary includes "managed by Echosync".
        """
        if not self.ensure_connection() or not self.server or not self.music_library:
            return False

        # --- Managed Account Routing Logic ---
        target_server = self.server
        if target_user_id or source_account_name:
            matched_user = self._resolve_managed_user(
                target_user_id=target_user_id,
                source_account_name=source_account_name,
            )

            if matched_user:
                logger.info(
                    f"Routing playlist '{playlist_name}' to managed user '{_safe_getattr(matched_user, 'title', matched_user)}' using Plex user_id '{target_user_id}'"
                )
                switched_server = self._switch_to_user_server(matched_user)
                if switched_server:
                    target_server = switched_server
                else:
                    raise RuntimeError(
                        f"Could not safely resolve Plex managed user for '{source_account_name}' (target ID: {target_user_id}). "
                        f"Server context switch failed. Sync aborted to prevent admin library pollution."
                    )
            elif self._is_admin_user(target_user_id):
                logger.info(
                    f"Target user ID '{target_user_id}' corresponds to primary/admin Plex account. Using main server."
                )
                target_server = self.server
            else:
                raise RuntimeError(
                    f"Could not safely resolve Plex managed user for '{source_account_name}' (target ID: {target_user_id}). "
                    f"Sync aborted to prevent admin library pollution."
                )

        management_tag = "managed by Echosync"
        if source_account_name:
            management_tag = f"managed by Echosync. Synced from {source_account_name}."
        create_name = f"{playlist_name} {marker}".strip()

        original_server = self.server

        try:
            # Update server reference for the rest of the method
            # We also need to re-find the playlist and library on the target_server
            self.server = target_server
            playlist = self._find_managed_playlist(playlist_name, marker=marker, management_tag=management_tag)

            items = []
            # Deduplicate rating keys while preserving order to avoid redundant fetches
            seen_rks = set()
            deduped_rating_keys = []
            for rk in rating_keys:
                if not rk:
                    continue
                if rk in seen_rks:
                    continue
                seen_rks.add(rk)
                deduped_rating_keys.append(rk)

            for rk in deduped_rating_keys:
                try:
                    # Ensure ratingKey is an integer
                    try:
                        rk_int = int(rk) if rk else None
                    except (ValueError, TypeError):
                        logger.warning(f"Invalid ratingKey format: {rk}")
                        continue

                    if not rk_int:
                        logger.warning("Empty or invalid ratingKey")
                        continue

                    item = self.server.fetchItem(rk_int)
                    logger.debug(f"fetchItem({rk_int}) returned: {type(item).__name__} - {item}")
                    if item:
                        items.append(item)
                        logger.debug(f"Added item to list, total items now: {len(items)}")
                    else:
                        logger.warning(f"fetchItem returned None or falsy value for ratingKey {rk_int}")
                except Exception as fe:
                    logger.error(
                        f"Exception fetching item for ratingKey {rk}: {fe}",
                        exc_info=True,
                    )
            logger.info(
                f"Fetched {len(items)} valid items from {len(deduped_rating_keys)} unique rating keys (requested {len(rating_keys)})"
            )

            if not items:
                logger.error(
                    f"No valid Plex items resolved for playlist sync - all {len(rating_keys)} ratingKeys failed to fetch"
                )
                return False

            if playlist is None:
                logger.debug(
                    f"Playlist not found, creating new one. Items list type: {type(items)}, length: {len(items)}"
                )
                if items:
                    logger.debug(f"First item type: {type(items[0])}, value: {items[0]}")

                from plexapi.playlist import Playlist

                try:
                    logger.debug(f"About to call Playlist.create with {len(items)} items")
                    created_playlist = Playlist.create(self.server, create_name, items=items)
                    logger.info(f"Playlist.create() succeeded, returned: {created_playlist}")
                    try:
                        if hasattr(created_playlist, "editSummary"):
                            created_playlist.editSummary(management_tag)
                    except Exception as tag_err:
                        logger.debug(f"Failed to add management tag: {tag_err}")
                except Exception as create_err:
                    logger.error(f"Playlist.create() failed: {create_err}", exc_info=True)
                    raise
                # Verify created playlist contents against requested rating keys
                try:
                    created_items = list(created_playlist.items()) if created_playlist else []
                    created_rks = set(str(_safe_getattr(i, "ratingKey", "")) for i in created_items)
                    requested_rks = set(str(rk) for rk in deduped_rating_keys)
                    missing = requested_rks - created_rks
                    if missing:
                        sample_missing = list(missing)[:10]
                        logger.warning(
                            f"Playlist created but {len(missing)} requested items are missing from Plex playlist (showing up to 10): {sample_missing}"
                        )
                    logger.info(
                        f"Created Plex playlist '{create_name}' with {len(created_items)} tracks (requested {len(deduped_rating_keys)})"
                    )
                except Exception as verify_err:
                    logger.debug(f"Failed to verify created playlist contents: {verify_err}")
                return True

            if overwrite:
                try:
                    existing_items = list(playlist.items())
                    if existing_items:
                        playlist.removeItems(existing_items)
                except Exception as clear_err:
                    logger.debug(f"Failed to clear playlist '{playlist.title}': {clear_err}")

            playlist.addItems(items)
            logger.info(f"Updated Plex playlist '{playlist.title}' with {len(items)} tracks (overwrite={overwrite})")
            try:
                if hasattr(playlist, "editSummary"):
                    playlist.editSummary(management_tag)
            except Exception:
                pass
            # Post-update verification: re-fetch playlist and compare rating keys
            try:
                refreshed = self.server.playlist(playlist.title)
                refreshed_items = list(refreshed.items()) if refreshed else []
                refreshed_rks = set(str(_safe_getattr(i, "ratingKey", "")) for i in refreshed_items)
                requested_rks = set(str(rk) for rk in deduped_rating_keys)
                missing = requested_rks - refreshed_rks
                if missing:
                    sample_missing = list(missing)[:10]
                    logger.warning(
                        f"After update, {len(missing)} requested items are missing from Plex playlist (showing up to 10): {sample_missing}"
                    )
            except Exception as verify_err:
                logger.debug(f"Failed to verify updated playlist contents: {verify_err}")
            return True
        except Exception as e:
            logger.error(f"Error syncing Plex playlist '{playlist_name}': {e}")
            return False
        finally:
            # Restore original server
            self.server = original_server

    # ===== CORE METHODS =====

    def search(self, query: str, type: str = "track", limit: int = 10) -> list[EchosyncTrack]:
        """Search for tracks in Plex library."""
        if not self.ensure_connection() or not self.music_library:
            logger.warning("Plex not connected or no music library")
            return []

        try:
            results = self.music_library.search(query, libtype=type, maxresults=limit)
            tracks = []

            for result in results:
                if isinstance(result, PlexTrack):
                    track = self._convert_track_to_echosync(result)
                    if track:
                        tracks.append(track)

            logger.debug(f"Search '{query}' returned {len(tracks)} tracks")
            return tracks

        except Exception as e:
            logger.error(f"Error searching Plex: {e}")
            return []

    def fetch_or_recover_track(
        self,
        cached_rating_key: str,
        track_meta: EchosyncTrack | None = None,
    ) -> tuple[Any | None, bool]:
        """Fetch track by ratingKey, falling back to a live search and disambiguation matrix on 404/NotFound.

        Returns (plex_item, is_recovered).
        """
        if not self.ensure_connection() or not self.server:
            return None, False

        # Step 1: Standard fetchItem fast-path
        if cached_rating_key:
            try:
                rk_int = int(cached_rating_key)
                item = self.server.fetchItem(rk_int)
                if item:
                    return item, False
            except Exception as e:
                logger.debug(f"Plex fetchItem({cached_rating_key}) failed: {e}")

        # Step 2: Live lookup fallback using search and verification matrix
        if not track_meta or not self.music_library:
            return None, False

        title = getattr(track_meta, "title", None) or getattr(track_meta, "raw_title", None)
        artist = getattr(track_meta, "artist", None) or getattr(track_meta, "artist_name", None)

        candidates = []
        if title:
            try:
                candidates = self.music_library.search(title, libtype="track", maxresults=50) or []
            except Exception as se:
                logger.debug(f"Plex search by title '{title}' failed: {se}")

            # Fallback: strip Spotify-style suffixes ('(feat. ...)', '- From "..."', '- 2005')
            if not candidates:
                clean_title = re.sub(r"\s*[\(\[].*?[\)\]]", "", str(title))
                clean_title = re.sub(r"\s+-\s+.*$", "", clean_title).strip()
                if clean_title and clean_title.lower() != str(title).strip().lower():
                    try:
                        candidates = self.music_library.search(clean_title, libtype="track", maxresults=50) or []
                    except Exception as se:
                        logger.debug(f"Plex search by cleaned title '{clean_title}' failed: {se}")

        if not candidates and artist:
            try:
                candidates = self.music_library.search(artist, libtype="track", maxresults=50) or []
            except Exception as se:
                logger.debug(f"Plex search by artist '{artist}' failed: {se}")

        if not candidates:
            return None, False

        best_cand = None
        best_score = 0.0

        for cand in candidates:
            cand_score = verify_plex_candidate(cand, track_meta)
            if cand_score > best_score:
                best_score = cand_score
                best_cand = cand

        if best_cand and best_score >= 70.0:
            new_rk = str(getattr(best_cand, "ratingKey", ""))
            logger.info(
                f"Plex live recovery matched '{title}' by '{artist}' (score: {best_score:.1f}): "
                f"old ratingKey {cached_rating_key} -> new ratingKey {new_rk}"
            )
            return best_cand, True

        return None, False

    def get_track(self, track_id: str) -> EchosyncTrack | None:
        """Fetch single track by Plex ratingKey.

        Plex identifies tracks by an integer ratingKey.  The int() cast lives
        here so that callers remain blind to Plex's integer requirement.
        """
        if not self.ensure_connection() or not self.music_library:
            return None

        try:
            rk_int = int(track_id)
        except (ValueError, TypeError):
            logger.warning(f"get_track: '{track_id}' is not a valid Plex ratingKey (expected integer string)")
            return None

        try:
            track = self.music_library.fetchItem(rk_int)
            if isinstance(track, PlexTrack):
                return self._convert_track_to_echosync(track)
        except Exception as e:
            logger.error(f"Error fetching Plex track ratingKey={rk_int}: {e}")

        return None

    def get_album(self, album_id: str) -> dict[str, Any] | None:
        """Fetch album by ID (stub - not typically needed)."""
        # Albums are accessed through search/playlist methods
        return None

    def get_artist(self, artist_id: str) -> dict[str, Any] | None:
        """Fetch artist by ID (stub - not typically needed)."""
        # Artists are accessed through search/playlist methods
        return None

    def get_user_playlists(self, user_id: str | None = None) -> list[dict[str, Any]]:
        """Get playlists from Plex server."""
        if not self.ensure_connection() or not self.server:
            return []

        try:
            playlists = []
            for playlist in self.server.playlists():
                # Filter for music playlists only (robustly handle None and alternate attribute names)
                if not playlist:
                    continue

                # Support both 'playlistType' and possible variants like 'playlist_type'
                playlist_type = ""
                if hasattr(playlist, "playlistType"):
                    playlist_type = _safe_getattr(playlist, "playlistType") or ""
                elif hasattr(playlist, "playlist_type"):
                    playlist_type = _safe_getattr(playlist, "playlist_type") or ""

                if str(playlist_type).lower() != "audio":
                    continue

                playlists.append(
                    {
                        "id": str(_safe_getattr(playlist, "ratingKey", None)),
                        "name": _safe_getattr(playlist, "title", None),
                        "description": _safe_getattr(playlist, "summary", None),
                        "track_count": _safe_getattr(playlist, "leafCount", 0),
                    }
                )

            logger.debug(f"Found {len(playlists)} music playlists")
            return playlists

        except Exception as e:
            logger.error(f"Error fetching playlists: {e}")
            return []

    def get_playlist_tracks(self, playlist_id: str) -> list[EchosyncTrack]:
        """Get all tracks from a playlist."""
        if not self.ensure_connection() or not self.server:
            return []

        try:
            playlist = self.server.playlist(int(playlist_id))
            tracks = []

            for item in playlist.items():
                if isinstance(item, PlexTrack):
                    track = self._convert_track_to_echosync(item)
                    if track:
                        tracks.append(track)

            logger.debug(f"Playlist {playlist_id} has {len(tracks)} tracks")
            return tracks

        except Exception as e:
            logger.error(f"Error fetching playlist {playlist_id}: {e}")
            return []

    # ===== LIBRARY METHODS =====

    def get_music_libraries(self) -> list[dict[str, str]]:
        """Get all music library sections from Plex server."""
        if not self.ensure_connection() or not self.server:
            return []

        try:
            libraries = []
            for section in self.server.library.sections():
                if section.type == "artist":
                    libraries.append({"title": section.title, "key": str(section.key)})

            logger.debug(f"Found {len(libraries)} music libraries")
            return libraries

        except Exception as e:
            logger.error(f"Error fetching libraries: {e}")
            return []

    def set_music_library(self, library_key: str) -> bool:
        """Set active music library by key."""
        if not self.ensure_connection() or not self.server:
            return False

        try:
            section = self.server.library.section(library_key)
            if section.type == "artist":
                self.music_library = section
                logger.info(f"Set music library to: {section.title}")
                return True
        except Exception as e:
            logger.error(f"Error setting music library: {e}")

        return False

    def get_identifier_mappings(self, limit: int | None = None):
        """
        Lightweight identifiers-only fetch: yields dicts of {file_path, plugin_source, plugin_item_id}
        without constructing full EchosyncTrack objects.

        Used by DatabaseUpdateWorker when identifiers_only=True so we can backfill
        ExternalIdentifier rows keyed off LocalMedia.file_path without re-running the
        full _convert_track_to_echosync() pipeline.
        """
        if not self.ensure_connection() or not self.music_library:
            logger.warning("get_identifier_mappings: no active music library")
            return

        chunk_size = 1000
        max_limit = limit if limit else 999999
        offset = 0

        while offset < max_limit:
            current_limit = min(chunk_size, max_limit - offset)
            try:
                chunk_tracks = self.music_library.searchTracks(container_start=offset, container_size=current_limit)
            except Exception as e:
                logger.error(f"get_identifier_mappings: Plex searchTracks failed at offset={offset}: {e}")
                break

            if not chunk_tracks:
                break

            for raw_track in chunk_tracks:
                if not isinstance(raw_track, PlexTrack):
                    continue
                try:
                    rating_key = str(_safe_getattr(raw_track, "ratingKey", None) or "")
                    if not rating_key or rating_key == "None":
                        continue

                    file_path = None
                    if hasattr(raw_track, "media") and raw_track.media:
                        media_obj = raw_track.media[0]
                        if hasattr(media_obj, "parts") and media_obj.parts:
                            file_path = _safe_getattr(media_obj.parts[0], "file", None)

                    if file_path:
                        file_path = PathMapper.to_local(file_path)

                    title = _safe_getattr(raw_track, "title", None)
                    artist = _safe_getattr(raw_track, "grandparentTitle", None) or _safe_getattr(
                        raw_track, "originalTitle", None
                    )

                    yield {
                        "file_path": file_path,
                        "plugin_source": "plex",
                        "plugin_item_id": rating_key,
                        "title": title,
                        "artist_name": artist,
                    }
                except Exception as e:
                    logger.debug(f"get_identifier_mappings: skipping track: {e}")

            offset += len(chunk_tracks)

    def get_all_tracks(self, limit: int | None = None):
        """Get all tracks from active music library iteratively to save RAM."""

        if not self.ensure_connection() or not self.music_library:
            logger.warning("No active music library")
            return

        try:
            # OPTIMIZATION: Fetch in chunks (pagination) to yield items and avoid huge allocations
            chunk_size = 1000
            max_limit = limit if limit else 999999
            offset = 0

            while offset < max_limit:
                current_limit = min(chunk_size, max_limit - offset)
                logger.info(f"Calling Plex searchTracks container_start={offset} container_size={current_limit}")
                chunk_tracks = self.music_library.searchTracks(container_start=offset, container_size=current_limit)

                if not chunk_tracks:
                    break

                for raw_track in chunk_tracks:
                    if isinstance(raw_track, PlexTrack):
                        try:
                            # PERF: deep=False avoids per-track HTTP calls to
                            # /metadata/{artistKey} and /metadata/{albumKey}.
                            # We rely on the cheap XML attributes already in
                            # the batch payload (grandparentTitle, parentTitle).
                            track = self._convert_track_to_echosync(raw_track, deep=False)
                            if track:
                                yield track
                        except Exception as e:
                            logger.error(f"Failed to convert Plex track: {e!s}")
                    else:
                        logger.warning(f"Skipping non-track item: {type(raw_track)}")

                offset += len(chunk_tracks)

        except Exception as e:
            logger.error(f"Error fetching tracks from Plex: {e!s}")

    def get_all_albums(self) -> list[dict[str, Any]]:
        """Get all albums from active music library."""
        if not self.ensure_connection() or not self.music_library:
            return []

        try:
            albums = self.music_library.searchAlbums(limit=99999)
            logger.info(f"Found {len(albums)} albums in Plex library")
            return [
                {
                    "id": str(album.ratingKey),
                    "title": album.title,
                    "artist": album.artist().title if album.artist() else "Unknown",
                }
                for album in albums
            ]
        except Exception as e:
            logger.error(f"Error fetching albums: {e}")
            return []

    def get_library_stats(self) -> dict[str, int]:
        """Get statistics about active library."""
        if not self.ensure_connection() or not self.music_library:
            return {}

        try:
            return {
                "total_tracks": self.music_library.totalSize if hasattr(self.music_library, "totalSize") else 0,
                "albums": len(self.music_library.searchAlbums(limit=99999)),
                "artists": len(self.music_library.searchArtists(limit=99999)),
            }
        except Exception as e:
            logger.error(f"Error getting library stats: {e}")
            return {}

    def get_all_artists(self) -> list[Any]:
        """Get all artists from the active music library."""
        if not self.ensure_connection() or not self.music_library:
            return []
        try:
            return self.music_library.searchArtists(limit=99999)
        except Exception as e:
            logger.error(f"Error fetching artists: {e}")
            return []

    def _trigger_scan_api(self, path: str | None = None) -> bool:
        """Trigger scan on the Plex server API."""
        if not self.ensure_connection() or not self.music_library:
            return False
        try:
            self.music_library.update()
            return True
        except Exception as e:
            logger.error(f"Error updating Plex library: {e}")
            return False

    def _get_scan_status_api(self) -> dict[str, Any]:
        """Poll scan status from the Plex server API."""
        if not self.ensure_connection() or not self.music_library:
            return {"scanning": False, "progress": 0.0}
        try:
            refreshing = self.music_library.refreshing if hasattr(self.music_library, "refreshing") else False
            return {
                "scanning": refreshing,
                "progress": 0.5 if refreshing else 0.0,
                "eta_seconds": None,
                "error": None,
            }
        except Exception:
            return {"scanning": False, "progress": 0.0}

    def get_content_changes_since(self, last_update: datetime | None = None):
        """Get content changes since last update using Plex-specific incremental detection."""
        from core.content_models import ContentChanges
        from time_utils import utc_now

        if not self.ensure_connection():
            logger.error("Not connected to Plex server")
            return ContentChanges()

        # If no last_update provided, return all content (full refresh)
        if last_update is None:
            logger.info("No last_update provided - performing full content retrieval")
            artists = self.get_all_artists()
            return ContentChanges(
                artists=artists,
                albums=[],
                tracks=[],
                full_refresh=True,
                last_checked=utc_now(),
            )

        try:
            logger.info(f"Getting Plex content changes since {last_update}")
            artists = self.get_all_artists()
            return ContentChanges(
                artists=artists,
                albums=[],
                tracks=[],
                full_refresh=True,
                last_checked=utc_now(),
            )
        except Exception as e:
            logger.error(f"Error getting Plex content changes: {e}")
            return ContentChanges()

    # ===== INTERNAL METHODS =====

    def _extract_version_suffix(self, text: str) -> tuple[str, str | None]:
        """Extract version suffix from text in parentheses or common edition suffixes.

        E.g., "Wake Me Up (Avicii by Avicii)" -> ("Wake Me Up", "Avicii by Avicii")
        E.g., "All the Things She Said" Music Video -> ("All the Things She Said", "Music Video")
        E.g., "True (Avicii by Avicii)" -> ("True", "Avicii by Avicii")
        """
        import re

        # First check for common edition suffixes (case-insensitive)
        edition_patterns = [
            r"\s+(?:Music\s+Video|Official\s+Video|Video|Live\s+Version|Acoustic\s+Version|Remix|Remaster|Extended\s+Version)\s*$",
            r"\s*\(([^)]*)\)\s*$",  # Then try parentheses
        ]

        for pattern in edition_patterns:
            if pattern == r"\s*\(([^)]*)\)\s*$":
                match = re.search(pattern, text)
                if match:
                    base = text[: match.start()].strip()
                    version = match.group(1).strip()
                    if base and version:
                        return base, version
            else:
                match = re.search(pattern, text)
                if match:
                    base = text[: match.start()].strip()
                    version = match.group(0).strip().lower()
                    return base, version

        return text, None

    def _convert_track_to_echosync(self, plex_track: PlexTrack, deep: bool = False) -> EchosyncTrack | None:
        """Convert Plex track to EchosyncTrack.

        Args:
            plex_track: The plexapi Track object.
            deep: When True, call plex_track.artist() and
                  plex_track.album() which each fire a /metadata/{key}
                  HTTP round-trip.  When False (default / bulk mode), use only
                  the cheap XML attributes already present in the batch
                  payload (grandparentTitle, parentTitle, originalTitle).
                  Deep metadata hydration is deferred to the Retroactive
                  Metadata Enhancer.
        """
        try:
            # Extract basic metadata
            title = _safe_getattr(plex_track, "title", None)

            # Handle artist and album gracefully.
            #
            # Plex data model for compilation/OST albums:
            #   plex_track.originalTitle  — the TRACK artist (TPE1); the specific
            #                               performer, e.g. 'Hu Xia'.
            #   plex_track.artist().title — the ALBUM artist (TPE2); typically
            #                               'Various Artists' for compilations.
            #   plex_track.grandparentTitle — same as artist().title but cheaper.
            #
            # We must prefer originalTitle (track artist) so that OST tracks
            # tagged as 'Various Artists' at the album level are stored with their
            # real performer rather than the generic compilation tag.
            artist = None

            # Step 1: track-specific performer (originalTitle = TPE1 in Plex)
            original_title = _safe_getattr(plex_track, "originalTitle", None)
            if original_title and original_title.strip():
                artist = original_title.strip()

            # Step 2: Extract album artist (TPE2)
            album_artist = None
            if deep:
                # Deep mode: HTTP round-trip to /metadata/{artistKey}
                try:
                    artist_obj = plex_track.artist()
                    album_artist = _safe_getattr(artist_obj, "title", None) if artist_obj else None
                except (NotFound, AttributeError, Exception) as e:
                    logger.debug(f"Failed to get artist via plex_track.artist() for '{title}': {e}")

            # Step 3: cheap XML attribute (always available in batch payload)
            if not album_artist:
                album_artist = _safe_getattr(plex_track, "grandparentTitle", None)

            # Fallback for track artist if missing
            if not artist:
                artist = album_artist

            album = None
            if deep:
                # Deep mode: HTTP round-trip to /metadata/{albumKey}
                try:
                    album_obj = plex_track.album()
                    album = _safe_getattr(album_obj, "title", None) or ""
                except (NotFound, AttributeError, Exception) as e:
                    logger.debug(f"Failed to get album for track '{title}': {e}")
                    album = _safe_getattr(plex_track, "parentTitle", None) or ""
            else:
                # Bulk mode: use cheap XML attribute, no HTTP call
                album = _safe_getattr(plex_track, "parentTitle", None) or ""

            if not title:
                logger.warning("Skipping track - missing title")
                return None

            if not artist:
                logger.warning(f"Skipping track '{title}' - missing artist (both artist() and grandparentTitle failed)")
                return None

            # Remove version suffix from title if it matches album version
            # E.g., if title is "Wake Me Up (Avicii by Avicii)" and album is "True (Avicii by Avicii)"
            # Extract "(Avicii by Avicii)" from both and remove from title if they match
            title_base, title_version = self._extract_version_suffix(title)
            album_base, album_version = self._extract_version_suffix(album)

            if title_version and album_version and title_version.lower() == album_version.lower():
                title = title_base
            elif album and title.lower().endswith(f"({album.lower()})"):
                title = title[: -(len(album) + 2)].strip()  # Remove " (Album Name)"

            # Extract other metadata
            duration_ms = _safe_getattr(plex_track, "duration", None)
            year = _safe_getattr(plex_track, "year", None)
            track_number = _safe_getattr(plex_track, "trackNumber", None)
            disc_number = _safe_getattr(plex_track, "discNumber", None)

            # Extract file metadata
            file_path = None
            file_format = None
            bitrate = None

            if hasattr(plex_track, "media") and plex_track.media:
                media = plex_track.media[0]
                bitrate = _safe_getattr(media, "bitrate", None)

                if hasattr(media, "container"):
                    file_format = _safe_getattr(media, "container", None)

                if hasattr(media, "parts") and media.parts:
                    file_path = _safe_getattr(media.parts[0], "file", None)

            if file_path:
                file_path = PathMapper.to_local(file_path)

            # Filter out rogue mount entries from becoming local media
            if file_path and not file_path.startswith("virtual://"):
                sanctioned_prefixes = tuple(config_manager.get("SANCTIONED_PATH_PREFIXES", ["/data/library/"]))
                if not file_path.startswith(sanctioned_prefixes):
                    file_path = None

            # Extract Plex track ID (ratingKey)
            plex_track_id = str(_safe_getattr(plex_track, "ratingKey", None))

            if not plex_track_id or plex_track_id == "None":
                logger.warning(f"Track '{title}' by '{artist}' has no ratingKey - cannot save to database")
                return None

            # Direct instantiation of EchosyncTrack
            # Extract technical metadata
            sample_rate = None
            bit_depth = None
            file_size_bytes = None

            if hasattr(plex_track, "media") and plex_track.media:
                media = plex_track.media[0]
                if hasattr(media, "parts") and media.parts:
                    part = media.parts[0]
                    file_size_bytes = _safe_getattr(part, "size", None)

                    if hasattr(part, "streams") and part.streams:
                        for stream in part.streams:
                            # streamType 2 is typically audio
                            if _safe_getattr(stream, "streamType", None) == 2 or _safe_getattr(stream, "codec", None):
                                sample_rate = _safe_getattr(stream, "samplingRate", None)
                                bit_depth = _safe_getattr(stream, "bitDepth", None)
                                break

            # Timestamps
            added_at = None
            if hasattr(plex_track, "addedAt") and plex_track.addedAt:
                try:
                    # Plex uses seconds for addedAt
                    added_at = datetime.fromtimestamp(int(plex_track.addedAt), tz=UTC)
                except (ValueError, TypeError):
                    pass
            if not added_at:
                added_at = datetime.now(UTC)

            identifiers = []
            if plex_track_id:
                identifiers.append(
                    {
                        "plugin_source": "plex",
                        "plugin_item_id": plex_track_id,
                        "raw_data": None,  # Avoid storing heavy object
                    }
                )

            from core.db.echo_sync_track import EchosyncMedia

            media = []
            if file_path and Path(file_path).exists():
                media.append(
                    EchosyncMedia(
                        file_path=file_path,
                        file_format=file_format,
                        bitrate=bitrate,
                        sample_rate=sample_rate,
                        bit_depth=bit_depth,
                        file_size_bytes=file_size_bytes,
                        added_at=added_at,
                    )
                )

            from core.matching_engine.track_parser import normalize_track_dto

            track = normalize_track_dto(EchosyncTrack(
                raw_title=title,
                title=title,
                artist_name=artist,
                album_artist=album_artist,
                album_title=album,
                # Optional fields
                sort_title=_safe_getattr(plex_track, "titleSort", None),
                artist_sort_name=_safe_getattr(plex_track, "grandparentSortTitle", None),
                album_sort_title=_safe_getattr(plex_track, "parentSortTitle", None),
                duration_ms=duration_ms,
                track_number=track_number,
                disc_number=disc_number,
                release_year=year,
                added_at=added_at,
                media=media,
                identifiers=identifiers,
            ))

            if track:
                logger.debug(
                    "Successfully created EchosyncTrack: '%s' by '%s' with identifiers=%s",
                    track.title,
                    track.artist_name,
                    track.identifiers,
                )
            else:
                logger.warning(f"create_echo_sync_track returned None for '{title}' by '{artist}'")

            return track

        except Exception as e:
            logger.error(
                f"Error converting Plex track '{_safe_getattr(plex_track, 'title', 'Unknown')}': {e}",
                exc_info=True,
            )
            return None

    def ensure_connection(self) -> bool:
        """Ensure connection to Plex server with lazy initialization."""
        # Test existing connection
        if self.server is not None:
            try:
                self.server.library.sections()
                return True
            except Exception:
                logger.info("Plex connection lost, reconnecting...")
                self.server = None

        # Avoid concurrent connection attempts
        if self._is_connecting:
            return False

        # Back off if recent attempt failed
        now = time.time()
        if self._connection_attempted and (now - self._last_connection_attempt < self._connection_check_interval):
            return self.server is not None

        self._is_connecting = True
        try:
            self._last_connection_attempt = now
            self._setup_connection()
            return self.server is not None
        finally:
            self._is_connecting = False
            self._connection_attempted = True

    def _setup_connection(self):
        """Establish connection to Plex server."""
        from core.security import decrypt_string

        # Load tokens from account_tokens securely using the SDK accounts manager
        token_data = None
        if self.account_id:
            try:
                token_data = self.accounts.get_token(self.account_id)
            except Exception:
                token_data = None

        if not token_data or not token_data.get("access_token"):
            try:
                accounts = self.accounts.get_all()
                for acc in accounts:
                    t = self.accounts.get_token(acc.get("id"))
                    if t and t.get("access_token"):
                        token_data = t
                        self.account_id = acc.get("id")
                        logger.info(f"Fallback to token-backed Plex account {self.account_id}")
                        break
            except Exception as e:
                logger.warning(f"Failed searching Plex accounts for token: {e}")

        token = None
        if token_data and token_data.get("access_token"):
            try:
                token = decrypt_string(token_data.get("access_token"))
            except Exception as de:
                logger.warning(f"Failed to decrypt Plex access token: {de}")
                token = token_data.get("access_token")

        if not token:
            # Fallback to service config / secrets / legacy storage
            token = self.config.get("token") or (hasattr(self, "secrets") and self.secrets.get("token"))
            if not token:
                from services.storage_service import get_storage_service

                try:
                    storage = get_storage_service()
                    token = storage.get_service_config("plex", "token")
                except Exception:
                    pass

        if not token:
            logger.error(f"Plex token not configured for account {self.account_id}")
            return

        # Fetch Settings from JSON (Hybrid Config approach)
        plex_config = self.config or {}

        base_url = (
            plex_config.get("base_url")
            or plex_config.get("plex.base_url")
            or plex_config.get("server_url")
        )
        if not base_url:
            base_url = _safe_getattr(self, "kvs", None) and (
                self.kvs.get("base_url") or self.kvs.get("plex.base_url") or self.kvs.get("server_url")
            )

        if not base_url:
            from services.storage_service import get_storage_service

            try:
                storage = get_storage_service()
                base_url = storage.get_service_config("plex", "base_url") or storage.get_service_config(
                    "plex", "server_url"
                )
            except Exception:
                pass

        if not base_url:
            logger.warning("Plex server URL not configured")
            return

        try:
            # 15 second timeout to prevent hangs on slow servers
            self.server = PlexServer(base_url, token, timeout=15)
            self._find_music_library()
            logger.debug(f"Connected to Plex: {self.server.friendlyName}")

        except Exception as e:
            logger.error(f"Failed to connect to Plex: {e}")
            self.server = None

    def list_accounts(self) -> list[dict[str, Any]]:
        """Discover the primary Plex owner account and all Plex Home / Managed Users."""
        accounts: list[dict[str, Any]] = []
        seen_ids: set[str] = set()

        def _append_account(
            *,
            raw_id: Any,
            username: Any,
            title: Any,
            is_managed: bool,
        ) -> None:
            clean_username = str(username).strip() if username is not None else ""
            clean_title = str(title).strip() if title is not None else ""
            str_id = str(raw_id).strip() if raw_id is not None else ""
            ext_id = clean_username or str_id
            if not ext_id or ext_id in seen_ids:
                return
            seen_ids.add(ext_id)
            display_name = clean_title or clean_username or f"Managed User {str_id or ext_id}"
            accounts.append(
                {
                    "id": str_id or ext_id,
                    "external_account_id": ext_id,
                    "username": clean_username,
                    "display_name": display_name,
                    "is_managed": bool(is_managed),
                    "provider": "plex",
                }
            )

        if self.server or self.ensure_connection():
            try:
                myplex_account = self.server.myPlexAccount()
                _append_account(
                    raw_id=_safe_getattr(myplex_account, "id", None),
                    username=_safe_getattr(myplex_account, "username", None),
                    title=_safe_getattr(myplex_account, "title", None),
                    is_managed=False,
                )
                try:
                    home_users = myplex_account.users() or []
                except Exception as users_err:
                    logger.warning(f"Failed to fetch Plex Home / Managed Users via myPlexAccount.users(): {users_err}")
                    home_users = []

                for user in home_users:
                    _append_account(
                        raw_id=_safe_getattr(user, "id", None),
                        username=_safe_getattr(user, "username", None),
                        title=_safe_getattr(user, "title", None),
                        is_managed=bool(_safe_getattr(user, "home", True)),
                    )
                if accounts:
                    return accounts
            except Exception as exc:
                logger.warning(f"Failed to query MyPlexAccount for Plex user discovery: {exc}")

        # Fallback: query https://plex.tv/api/home/users directly if a token is stored
        token = ""
        try:
            from core.nexus_framework.plugin_SDK import sdk
            from core.security import decrypt_string

            for acc in sdk.accounts.get_all() or []:
                tok_data = sdk.accounts.get_token(acc["id"])
                if tok_data and tok_data.get("access_token"):
                    token = decrypt_string(tok_data["access_token"])
                    if token:
                        break
        except Exception as tok_err:
            logger.warning(f"Failed to read Plex token for fallback discovery: {tok_err}")

        if token:
            try:
                import xml.etree.ElementTree as ET
                import httpx

                resp = httpx.get(
                    "https://plex.tv/api/home/users",
                    headers={"X-Plex-Token": token, "Accept": "application/xml"},
                    timeout=10.0,
                )
                if resp.status_code == 200:
                    root = ET.fromstring(resp.text)
                    for idx, elem in enumerate(root.findall(".//User")):
                        _append_account(
                            raw_id=elem.attrib.get("id"),
                            username=elem.attrib.get("username", ""),
                            title=elem.attrib.get("title", ""),
                            is_managed=(elem.attrib.get("admin", "0") != "1" and idx > 0),
                        )
                else:
                    logger.warning(f"Plex Home Users API returned HTTP {resp.status_code}")
            except Exception as http_err:
                logger.warning(f"Plex Home Users HTTP fallback failed: {http_err}")

        return accounts

    def get_managed_users(self) -> list[dict[str, Any]]:
        """Alias for list_accounts() for media server profile discovery."""
        return self.list_accounts()

    def import_managed_users(self) -> list[dict[str, Any]]:
        """Import the Plex admin account and managed users into settings database account rows."""
        if not self.ensure_connection() or not self.server:
            logger.error("Cannot import Plex managed users without an active Plex connection")
            return []

        from core.nexus_framework.plugin_SDK import sdk

        token_data = self.accounts.get_token(self.account_id) if self.account_id else None

        try:
            myplex_account = self.server.myPlexAccount()
        except Exception as e:
            logger.error(f"Failed to load MyPlex account details: {e}", exc_info=True)
            return []

        imported_ids: list[int] = []

        admin_user_id = (
            _safe_getattr(myplex_account, "uuid", None)
            or _safe_getattr(myplex_account, "id", None)
            or _safe_getattr(myplex_account, "username", None)
        )
        admin_account_name = (
            _safe_getattr(myplex_account, "username", None)
            or _safe_getattr(myplex_account, "title", None)
            or _safe_getattr(myplex_account, "email", None)
            or "Plex Admin"
        )
        admin_email = _safe_getattr(myplex_account, "email", None)

        admin_account_id = self.accounts.upsert_account(
            account_name=admin_account_name,
            display_name=admin_account_name,
            user_id=str(admin_user_id) if admin_user_id is not None else None,
            account_email=admin_email,
            is_active=True,
            is_authenticated=True,
            account_id=self.account_id,
        )
        if admin_account_id:
            imported_ids.append(int(admin_account_id))
            self.account_id = int(admin_account_id)

            if token_data and token_data.get("access_token"):
                sdk.accounts.save_token(
                    self.account_id,
                    token_data.get("access_token"),
                    token_data.get("refresh_token"),
                    None,
                )

        users = []
        try:
            users = myplex_account.users() or []
        except Exception as e:
            logger.warning(f"Failed to enumerate Plex managed users: {e}")

        for user in users:
            user_id = _safe_getattr(user, "id", None) or _safe_getattr(user, "uuid", None)
            username = _safe_getattr(user, "username", None) or _safe_getattr(user, "title", None)
            display_name = _safe_getattr(user, "title", None) or _safe_getattr(user, "username", None) or username
            email = _safe_getattr(user, "email", None)

            managed_account_id = self.accounts.upsert_account(
                account_name=username or display_name,
                display_name=display_name,
                user_id=str(user_id) if user_id is not None else None,
                is_active=True,
                is_authenticated=False,
            )
            if managed_account_id:
                imported_ids.append(int(managed_account_id))

        accounts = self.accounts.get_all() or []
        imported = [account for account in accounts if account.get("id") in set(imported_ids)]
        logger.info(f"Imported {len(imported)} Plex account rows (admin + managed users)")
        return imported

    def _find_music_library(self):
        """Automatically find and set active music library."""
        if not self.server:
            return

        try:
            self.music_library = self._find_music_library_for_server(self.server)
            if self.music_library:
                logger.info(f"Selected music library: {self.music_library.title}")

        except Exception as e:
            logger.error(f"Error finding music library: {e}")

    def _find_music_library_for_server(self, server: PlexServer) -> MusicSection | None:
        """Find the preferred music library for a specific Plex server context."""
        music_sections = [section for section in server.library.sections() if section.type == "artist"]

        if not music_sections:
            logger.warning("No music library found on Plex server")
            return None

        for priority_name in ["Music", "music", "Audio", "audio", "Songs", "songs"]:
            for section in music_sections:
                if section.title == priority_name:
                    return section

        return music_sections[0]

    def _resolve_history_context(self, account_id: int | None):
        """Resolve Plex server, library, and numeric Plex account ID for a history query.

        Returns a 3-tuple: ``(target_server, target_library, plex_account_id_int)``.
        ``plex_account_id_int`` is the integer Plex account ID required by
        ``PlexServer.history(accountID=...)``.  All three values are ``None`` when
        the context cannot be safely resolved — callers **must** treat that as a
        hard refusal rather than falling back to the admin server.
        """
        if not self.ensure_connection() or not self.server:
            return None, None, None

        target_server = self.server
        target_library = self.music_library

        if account_id is None:
            return None, None, None

        accounts = self.accounts.get_all() or []
        account = next((item for item in accounts if item.get("id") == account_id), None)
        if not account:
            logger.warning(f"No Plex account found for history sync account_id={account_id}")
            return None, None, None

        target_user_id = account.get("user_id")
        if not target_user_id:
            logger.warning(f"Account account_id={account_id} has no Plex user_id — cannot scope history")
            return None, None, None

        try:
            myplex_account = self.server.myPlexAccount()

            # Resolve admin's numeric Plex ID for the accountID filter.
            raw_admin_id = _safe_getattr(myplex_account, "id", None)
            try:
                admin_plex_id_int: int | None = int(raw_admin_id) if raw_admin_id is not None else None
            except (TypeError, ValueError):
                admin_plex_id_int = None

            admin_ids = {
                str(value)
                for value in [
                    _safe_getattr(myplex_account, "uuid", None),
                    _safe_getattr(myplex_account, "id", None),
                    _safe_getattr(myplex_account, "username", None),
                ]
                if value is not None
            }
            if str(target_user_id) in admin_ids:
                return target_server, target_library, admin_plex_id_int

            for user in myplex_account.users() or []:
                candidate_id = _safe_getattr(user, "id", None) or _safe_getattr(user, "uuid", None)
                if candidate_id is not None and str(candidate_id) == str(target_user_id):
                    switched_server = self.server.switchUser(user.title)
                    switched_library = self._find_music_library_for_server(switched_server)
                    try:
                        managed_plex_id_int: int | None = int(candidate_id)
                    except (TypeError, ValueError):
                        managed_plex_id_int = None
                    logger.info(
                        f"Resolved Plex history context for account_id={account_id} "
                        f"to managed user '{user.title}' (plex_id={managed_plex_id_int})"
                    )
                    return switched_server, switched_library, managed_plex_id_int
        except Exception as e:
            logger.warning(f"Failed to resolve Plex history context for account_id={account_id}: {e}")

        # Could not resolve — return (None, None, None) so the caller refuses to
        # execute an unscoped history() that would leak the admin's global history.
        logger.warning(
            f"Plex history context for account_id={account_id} could not be resolved; "
            "refusing to fall back to unscoped admin history."
        )
        return None, None, None

    def _coerce_datetime(self, value: Any) -> datetime | None:
        if value is None:
            return None
        if isinstance(value, datetime):
            return value if value.tzinfo else value.replace(tzinfo=UTC)
        try:
            return datetime.fromtimestamp(int(value), tz=UTC)
        except Exception:
            return None

    def _extract_user_rating(self, plex_item: Any) -> float | None:
        """Normalize Plex user rating to the 0-10 scale used in working DB.

        Plex uses 0 for "unrated" in some payloads, so that should remain None.
        """
        raw_rating = _safe_getattr(plex_item, "userRating", None)

        # Some payload shapes expose user state as a mapping-like object.
        if raw_rating in (None, ""):
            user_state = _safe_getattr(plex_item, "userState", None)
            if isinstance(user_state, dict):
                raw_rating = user_state.get("rating")

        if raw_rating in (None, ""):
            return None

        try:
            parsed = float(raw_rating)
        except Exception:
            return None

        if parsed <= 0.0:
            return None
        # Plex wire format: userRating is 2× the displayed star count (0.5 stars → 1.0,
        # 5 stars → 10.0).  Divide by 2 to normalise to display stars (0.5–5.0) so
        # stars_to_ten_point() in consensus.py receives the correct input scale.
        display_stars = parsed / 2.0
        return min(5.0, display_stars)

    def _enrich_interactions_with_user_ratings(
        self,
        interactions: list[UserTrackInteraction],
        target_server: Any,
    ) -> None:
        """Backfill missing ratings by resolving metadata items in user context."""
        if not interactions or not target_server:
            return

        rating_cache: dict[str, float | None] = {}
        enriched_count = 0

        for interaction in interactions:
            if interaction.rating is not None:
                continue

            provider_item_id = str(_safe_getattr(interaction, "plugin_item_id", "") or "").strip()
            if not provider_item_id:
                continue

            if provider_item_id in rating_cache:
                cached_rating = rating_cache[provider_item_id]
                if cached_rating is not None:
                    interaction.rating = cached_rating
                    enriched_count += 1
                continue

            resolved_rating: float | None = None
            try:
                try:
                    item = target_server.fetchItem(int(provider_item_id))
                except Exception:
                    item = target_server.fetchItem(f"/library/metadata/{provider_item_id}")

                if item is not None:
                    resolved_rating = self._extract_user_rating(item)
            except Exception as exc:
                logger.debug(f"Could not enrich rating for Plex item {provider_item_id}: {exc}")

            rating_cache[provider_item_id] = resolved_rating
            if resolved_rating is not None:
                interaction.rating = resolved_rating
                enriched_count += 1

        if enriched_count:
            logger.info(f"Enriched {enriched_count} Plex history interactions with user ratings")

    def _track_to_interaction(self, plex_track: Any) -> UserTrackInteraction | None:
        """Convert a Plex history or library item into a standardized interaction."""
        converted = self._convert_track_to_echosync(plex_track)
        if not converted:
            return None

        provider_item_id = str(_safe_getattr(plex_track, "ratingKey", None) or converted.identifiers.get("plex") or "")
        play_count = int(_safe_getattr(plex_track, "viewCount", 0) or 0)
        rating = self._extract_user_rating(plex_track)
        last_played_at = self._coerce_datetime(_safe_getattr(plex_track, "lastViewedAt", None))

        return UserTrackInteraction(
            plugin_item_id=provider_item_id,
            artist_name=converted.artist_name,
            track_title=converted.title,
            play_count=play_count,
            rating=rating,
            last_played_at=last_played_at,
        )

    def fetch_user_history(self, account_id: int | None = None, limit: int = 100) -> list[UserTrackInteraction]:
        """Fetch account-specific listening history from Plex using exact managed-user context when available."""
        # Guard 1: an explicit account_id is mandatory — an unscoped history() call
        # silently returns the admin's global history and would contaminate the database.
        if not account_id:
            logger.warning("fetch_user_history: account_id is required; refusing unscoped history fetch")
            return []

        # Guard 2: enforce int — PlexAPI silently drops the accountID filter when it
        # receives a string, falling back to global admin history with no error raised.
        try:
            account_id_int = int(account_id)
        except (TypeError, ValueError):
            logger.error(
                f"fetch_user_history: account_id={account_id!r} cannot be coerced to int "
                "— aborting to prevent admin history leak"
            )
            return []

        target_server, target_library, plex_account_id = self._resolve_history_context(account_id_int)
        if not target_server or not target_library or plex_account_id is None:
            logger.warning(
                f"fetch_user_history: could not resolve a scoped Plex context for "
                f"account_id={account_id_int} — refusing to fall back to unscoped admin history"
            )
            return []

        try:
            interactions: list[UserTrackInteraction] = []

            try:
                logger.debug(
                    f"Fetching Plex play history for account_id={account_id_int} plex_id={plex_account_id} (limit={limit})"
                )
                history_items = target_server.history(maxresults=limit, accountID=plex_account_id)
                for item in history_items or []:
                    # Strictly filter for audio tracks to avoid crashing on photos/extras
                    if _safe_getattr(item, "type", None) != "track":
                        continue
                    interaction = self._track_to_interaction(item)
                    if interaction:
                        # Plex history rows often omit viewCount; each history row still
                        # represents at least one play event for the selected account.
                        if int(_safe_getattr(interaction, "play_count", 0) or 0) <= 0:
                            interaction.play_count = 1
                        interactions.append(interaction)

                if interactions:
                    self._enrich_interactions_with_user_ratings(interactions, target_server)
                    logger.info(f"Fetched {len(interactions)} Plex history interactions for account_id={account_id}")
                    return interactions[:limit]
            except Exception as e:
                logger.warning(
                    f"Failed to fetch Plex history for account_id={account_id}: {e}. Falling back to lastViewedAt library query."
                )

            recent_tracks = target_library.searchTracks(maxresults=limit, sort="lastViewedAt:desc")
            for item in recent_tracks or []:
                interaction = self._track_to_interaction(item)
                if interaction:
                    interactions.append(interaction)

            self._enrich_interactions_with_user_ratings(interactions, target_server)

            logger.info(f"Fetched {len(interactions)} fallback Plex history interactions for account_id={account_id}")
            return interactions[:limit]

        except Exception as e:
            logger.error(f"Error fetching user history from Plex: {e}", exc_info=True)
            return []
